angular
    .module('livein')
    .controller('listPsCodeBilling',listPsCodeBilling)

function listPsCodeBilling(ProfileService,$ionicPopup,$filter,$scope,$ionicLoading) {

    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

    var selectedPsCode = null;
    $scope.isLoaded = false;
    $scope.units = [];

    $scope.toggleBody = (e,pscode) => {
        
        selectedPsCode = pscode[0]['PSCode'];

        $(e.currentTarget).next().toggle('slow')

        $(".selectedButton").each(function(item) {
            $(this).prop("checked", false)
        })

        $(".list.card").each(function(item) {
            $(this).css('border','none');
        })

        $(e.currentTarget).find(".row").find(".buttonSelected").find("input").prop("checked", true)

        $(e.currentTarget).parent().css('border','1px solid #55a5ff');
    }

    ProfileService.upgradeToResident(
        "samadhi.emaus@yahoo.com",
        function (response) {
            console.log(response)
            try {
                if(response.status) {
                    if(response.data.Site.length > 0) {

                        dataSites = {};

                        response.data.Site.forEach((data,index) => {
                            if(typeof dataSites[data.PSCode+""] === "undefined") {
                                dataSites[data.PSCode+""] = []
                            }

                            dataSites[data.PSCode+""].push(data)
                        })

                        $scope.units = dataSites;
                        console.log(dataSites);
                    }else{
                        $ionicPopup.alert({
                            template: $filter('translate')('checkEmail'),
                            okText: $filter('translate')('okay'),
                            cssClass: "alertPopup"
                        });
                        location.href = "#/app/main";
                    }
                }else{
                    $ionicPopup.alert({
                        template: $filter('translate')('checkEmail'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    location.href = "#/app/main";
                }
            }catch(error) {
                $ionicPopup.alert({
                    template: $filter('translate')('checkEmail'),
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
                location.href = "#/app/main";
            }
            $ionicLoading.hide();
            $scope.isLoaded = true;
        }
    )
}