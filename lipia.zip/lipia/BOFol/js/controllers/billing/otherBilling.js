angular
    .module('livein')
    .controller('otherBilling', otherBilling);

function otherBilling($rootScope, billingServices, $ionicHistory, $scope, $state, $ionicModal) {
    $scope.detailBillingStatement = detailBillingStatement;
    $scope.closeModalDetailBilling = closeModalDetailBilling;
    $scope.payNowBillingDetail = payNowBillingDetail;
    
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    email = $rootScope.emailres;
    $scope.fakelist = [1, 2, 3, 4];

    $scope.myGoBack = function () {
        $rootScope.loginOtherBilling = false;
        $ionicHistory.goBack();
    };

    getBillingStatement()
    function getBillingStatement() {
        billingServices.getbillingmultiside(email, function (response) {
            if (response) {
                if(response.status == 'success'){
                    // $scope.dataMultiSite = response.data['Site'];
                    var range  = [];
                    $scope.dataMultiSite=[];

                    angular.forEach(response.data['Site'], function (value, key) {
                        $scope.pushed = true;
                        for (var i = 0; i <= range.length; i += 1) {
                            if(value['@attributes'].SiteID==range[i]){
                                $scope.pushed = false;
                            }
                        }
            
                        if($scope.pushed==true){
                            range.push(value['@attributes'].SiteID);
                            $scope.dataMultiSite.push(value);
                        }
                    });

                    $scope.amountpaid = [];
                    $scope.dataMultiSite.forEach(function(obj){
                        $scope.atributeres = obj['@attributes'];
                        if($scope.atributeres.Name) $scope.billingName = $scope.atributeres.Name;
                        if(obj['@attributes'].BillingOutstandingBalance > 0){
                            $scope.amountpaid.push(obj['@attributes'].BillingOutstandingBalance);
                        }
                    })
                }
            } else {
                console.log(response);
            }
        });
    }

    $scope.doRefreshBillingStatement = function(){
        getBillingStatement();
        $scope.$broadcast('scroll.refreshComplete');
    }

    function detailBillingStatement(site) {
        $scope.titleUnit = site['@attributes'].SiteName;
        $rootScope.siteName = $scope.titleUnit;
        $scope.siteID = site['@attributes'].SiteID;
        $scope.billingOutstanding = currencyFormatDE(site['@attributes'].BillingOutstandingBalance.BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }).slice(0, -2));
        $scope.dataDetailBillingStatement = site.Periode;
        $scope.month = site.Periode[0]['@attributes'].Name;
        
        var i = 0;
        $scope.dataDetailBillingStatement.forEach(function (obj, idx) {
            $scope.dataDetailBillingStatement[idx].Unit.forEach(function (obj, idy) {
                $scope.dataDetailBillingStatement[idx].Unit[idy].id = i++;
                var btn_id = $scope.dataDetailBillingStatement[idx].Unit[idy].id;
                $scope['btn_unit_' + btn_id] = false;
                var bulan = $scope.dataDetailBillingStatement[idx]['@attributes'].Name;
                if(lang=='ina'){
                    bulan = bulan.replace("Januari", "JAN");
                    bulan = bulan.replace("Februari", "FEB");
                    bulan = bulan.replace("Maret", "MAR");
                    bulan = bulan.replace("April", "APR");
                    bulan = bulan.replace("Mei", "MEI");
                    bulan = bulan.replace("Juni", "JUN");
                    bulan = bulan.replace("Juli", "JUL");
                    bulan = bulan.replace("September", "SEP");
                    bulan = bulan.replace("Agustus", "AGU");
                    bulan = bulan.replace("Oktober", "OKT");
                    bulan = bulan.replace("November", "NOV");
                    bulan = bulan.replace("Desember", "DES");
                }else{
                    bulan = bulan.replace("Januari", "JAN");
                    bulan = bulan.replace("Februari", "FEB");
                    bulan = bulan.replace("Maret", "MAR");
                    bulan = bulan.replace("April", "APR");
                    bulan = bulan.replace("Mei", "MEI");
                    bulan = bulan.replace("Juni", "JUN");
                    bulan = bulan.replace("Juli", "JUL");
                    bulan = bulan.replace("September", "SEP");
                    bulan = bulan.replace("Agustus", "AUG");
                    bulan = bulan.replace("Oktober", "OCT");
                    bulan = bulan.replace("November", "NOV");
                    bulan = bulan.replace("Desember", "DEC");
                
                }
                $scope.dataDetailBillingStatement[idx]['@attributes'].NewName = bulan;
            });
        });

        $ionicModal.fromTemplateUrl('partials/tabs/billing/detailBillingStatementModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.modalMenu = modalMenu;
            $scope.modalMenu.show();
        });
    }

    $scope.varUnitDetails = function (id) {
        return $scope['btn_unit_' + id];
    }

    $scope.showHideUnitDetails = function (id) {
        $scope['btn_unit_' + id] = !$scope['btn_unit_' + id];
    }

    function closeModalDetailBilling() {
        $scope.modalMenu.remove();
    }

    function payNowBillingDetail(siteID) {
        closeModalDetailBilling();
        $state.go('app.detailPayment', { siteId: siteID });
    }
}
    
function currencyFormatDE(num) {
    return (
      num
        // .toFixed(2) // always two decimal digits
        .replace('.', ',') // replace decimal point character with ,
        .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
    ) // use . as a separator
}
