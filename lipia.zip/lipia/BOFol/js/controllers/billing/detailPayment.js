angular
    .module('livein')
    .controller('detailPayment',detailPayment);

    function detailPayment($scope, $rootScope,$ionicModal, $localStorage, $ionicHistory, $sce, $rootScope, $state, $filter, $location, billingServices, $ionicPopup, $ionicLoading, $stateParams) {
        $scope.haveReadTerm = false;
        $scope.type_payment=3;
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        // getPaymentCharge();
        
        
        $scope.myGoBack = function(){
            $ionicHistory.goBack();
        }

        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

        var email = '';
        if ($localStorage.currentUser) {
            if ($localStorage.currentUser.data) {
                if ($localStorage.currentUser.data[0]) {
                    if ($localStorage.currentUser.data[0].email) {
                        email = $localStorage.currentUser.data[0].email;
                    }
                }
            }
        }
        if($rootScope.loginOtherBilling) email = $rootScope.emailres;

        var siteId = $stateParams.siteId;
        billingServices.getbilling(email, siteId, function (response) {
            if (response) {
                    $scope.dataMultiSite = response.data;
                    $scope.atributeres = response.data['@attributes'];
                    $rootScope.attributpayment = $scope.atributeres;
                    $scope.month = response.data.Periode[0]['@attributes'].Name;
                    $scope.name = response.data['@attributes'].Name;
                    $scope.siteName = $rootScope.siteName;
                    // $scope.siteName = response.data.Periode[0].Unit[0]['@attributes'].UnitName;
                    $scope.BillingOustanding = response.data['@attributes'].BillingOutstandingBalance;
                    // $scope.BillingOutstandingBalance = currencyFormatDE(response.data['@attributes'].BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }).slice(0, -2));
                    $scope.Billingoutstandingbalance = response.data['@attributes'].BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
                    $rootScope.attributpayment.BillingOutstandingBalance = $scope.BillingOustanding = response.data['@attributes'].BillingOutstandingBalance;
                    // $scope.BillingOutstandingBalance = response.data['@attributes'].BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
                    
                    $scope.paymentTypeData = response.payment_type;
                    if (response != false) {
                        // $scope.paymentTypeData = response;
                        $scope.chargePayment = 0;
                        var idxOther = $scope.paymentTypeData.findIndex(x => x.payment_type == 4)
                        if(idxOther > -1){
                            $scope.chargePayment = $scope.paymentTypeData[idxOther].charge;
                        }
                        $ionicLoading.hide();
                    } else {
                        $ionicLoading.hide();
                    }
                    // $scope.amountpaid = [];
                    // $scope.dataMultiSite.forEach(function(obj){
                    //     $scope.atributeres = obj['@attributes'];
                    //     if($scope.atributeres.Name) $scope.billingName = $scope.atributeres.Name;
                    //     if(obj['@attributes'].BillingOutstandingBalance > 0){
                    //         $scope.amountpaid.push(obj['@attributes'].BillingOutstandingBalance);
                    //     }
                    // })
                    detailBillingStatement($scope.dataMultiSite);

               
            } else {
                console.log(response);
                $ionicLoading.hide();
            }
        });

        function getPaymentCharge() {         
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
               billingServices.getPaymentType(function (response) {
                   
                   if (response != false) {
                       $scope.paymentTypeData = response;
                       $scope.chargePayment = 0;
                       var idxOther = response.findIndex(x => x.payment_type == 4)
                       if(idxOther > -1){
                           $scope.chargePayment = response[idxOther].charge;
                       }
                       $ionicLoading.hide();
                   } else {
                       $ionicLoading.hide();
                   }
           });
       }
       
        $scope.selectPaymentMethod = function (val) {
            if (!val) {
                if($scope.paymentTypeData[0]==null||!$scope.paymentTypeData[0]){
                    $ionicPopup.alert({
                        template: $filter('translate')('payment_method_not_available'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                }else{
                    $ionicPopup.alert({
                        template: $filter('translate')('choose_payment'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                }
                return false;
            }
    
            if (!$scope.haveReadTerm) {
                $ionicPopup.alert({
                    template: $filter('translate')('read_term_condition'),
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
    
                return false;
            }

            if (val == 3) {
                goOvo();
            } else if (val == 4) {
                execMidtransPayment();
            } else {
                $ionicPopup.alert({
                    template: $filter('translate')('choose_payment'),
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
            }
        }
        
        function goOvo() {
            $location.path() == "/app/";
            $state.go("app.ovo_payment");
        } 

         

        function execMidtransPayment(){     
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });   
            loadTotalPay();
            loadMidtransPayment();
        }

        function loadTotalPay() {
            if ($rootScope.attributpayment) {
                $scope.totalAmount = parseFloat($rootScope.attributpayment.BillingOutstandingBalance);
                
                $scope.admin = parseFloat($scope.chargePayment);
                $scope.totalBayar = $scope.admin + $scope.totalAmount;
    
                $rootScope.transferPaymentChargeAdmin = $scope.admin;
                $rootScope.transferPaymentTotal = $scope.totalBayar;
            }
        }

        function loadMidtransPayment(){        
            billingServices.midtransPayment(
                $rootScope.attributpayment.Name,
                $rootScope.emailres,
                $rootScope.attributpayment.SiteID,
                $rootScope.transferPaymentTotal,
                $scope.chargePayment,
                function (response) {
                    $ionicLoading.hide();
                    if (response) {
                        if(response.status == "success"){
                            $scope.showUrl = true;
                            $rootScope.url_midtrans_payment = $sce.trustAsResourceUrl(response.redirect_url);
                            var language = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
                            if(localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina')  language = 'id';
                            snap.pay(response.token, {
                                onSuccess: function(result){
                                    console.log('success');
                                    console.log(result);
                                    showMessage(result.status_message, result.order_id, result.transaction_time, "success");
                                    analyticMidtrans(result);                             
                                    $ionicHistory.nextViewOptions({
                                        disableBack: true
                                    });
                                    // $state.go('app.loginebilling');
                                },
                                onPending: function(result){
                                    console.log('pending');
                                    console.log(result);
                                    if(result.payment_type == "gopay"){
                                        cekTransactionGojek(result);
                                    }else{
                                        showMessage(result.status_message, result.order_id, result.transaction_time, "pending");
                                        // $state.go('app.billing');
                                    }
                                    analyticMidtrans(result);
                                    $ionicHistory.nextViewOptions({
                                        disableBack: true
                                    });
                                },
                                onError: function(result){
                                    console.log('error');
                                    console.log(result);
                                    showMessage(result.status_message, result.order_id, result.transaction_time, "error");
                                    $ionicHistory.nextViewOptions({
                                        disableBack: true
                                    });
                                    // $state.go('app.loginebilling');
                                },
                                onClose: function(){
                                    console.log('customer closed the popup without finishing the payment');
                                    showMessage($filter('translate')('transaction_cancelled'), '', '', "error");
                                },
                                language:  language,
                                gopayMode: 'deeplink'
                              });
                        }else{
                            var message = response.message;
                             if(lang == 'ina'){
                                message = response.message_id;
                            } 
                            // $ionicPopup.alert({
                            //     title: "Payment Status",
                            //     template: message,
                            //     okText: $filter('translate')('okay'),
                            //     cssClass: "alertPopup"
                            // });
                            showMessage(message, '', '', "error");
                            $ionicHistory.nextViewOptions({
                                disableBack: true
                            });
                        }
                    } else {
                        $ionicPopup.alert({
                            template: $filter('translate')('there_has_been_an_error_our_system'),
                            okText: $filter('translate')('okay'),
                            cssClass: "alertPopup"
                        });
                    }
                });
        }

        function cekTransactionGojek(data){
            billingServices.detailhistory(data.order_id, function(response){
                console.log("cekTransactionGojek")
                console.log(response)
                if (response) {
                    if(response.data){
                        if(response.data.status == "success"){
                            showMessage($filter('translate')('payment_succeed'), data.order_id, response.data.transaction_date, response.data.status);
                        }else if(response.data.status == "pending"){
                            showMessage($filter('translate')('payment_has_been_canceled'));
                        }else{
                            showMessage($filter('translate')('there_has_been_an_error_our_system'));
                        }
                    }else{
                        showMessage($filter('translate')('there_has_been_an_error_our_system'));
                    }
                }else{
                    showMessage($filter('translate')('there_has_been_an_error_our_system'));
                }
                // $state.go('app.loginebilling');
            });
        }

        function detailBillingStatement(site) {
            // $scope.titleUnit = site['Periode'][0]['Unit'][0]['@attributes'].UnitCode + " | " + site['Periode'][0]['Unit'][0]['@attributes'].UnitNo;
            // if (site.Periode[0].Unit.length > 1) {
            //     $scope.titleUnit = site.Periode[0].Unit.length + " " + $filter('translate')('units');
            // }
               
            $scope.dataDetailBillingStatement = site.Periode;
            
            var i = 0;
            $scope.dataDetailBillingStatement.forEach(function (obj, idx) {
                $scope.dataDetailBillingStatement[idx].Unit.forEach(function (obj, idy) {
                    $scope.dataDetailBillingStatement[idx].Unit[idy].id = i++;
                    $scope['btn_unit_' + idy] = false;
                    var bulan = $scope.dataDetailBillingStatement[idx]['@attributes'].Name;
                    if(lang=='ina'){
                        bulan = bulan.replace("Januari", "JAN");
                        bulan = bulan.replace("Februari", "FEB");
                        bulan = bulan.replace("Maret", "MAR");
                        bulan = bulan.replace("April", "APR");
                        bulan = bulan.replace("Mei", "MEI");
                        bulan = bulan.replace("Juni", "JUN");
                        bulan = bulan.replace("Juli", "JUL");
                        bulan = bulan.replace("September", "SEP");
                        bulan = bulan.replace("Agustus", "AGU");
                        bulan = bulan.replace("Oktober", "OKT");
                        bulan = bulan.replace("November", "NOV");
                        bulan = bulan.replace("Desember", "DES");
                    }else{
                        bulan = bulan.replace("Januari", "JAN");
                        bulan = bulan.replace("Februari", "FEB");
                        bulan = bulan.replace("Maret", "MAR");
                        bulan = bulan.replace("April", "APR");
                        bulan = bulan.replace("Mei", "MEI");
                        bulan = bulan.replace("Juni", "JUN");
                        bulan = bulan.replace("Juli", "JUL");
                        bulan = bulan.replace("September", "SEP");
                        bulan = bulan.replace("Agustus", "AUG");
                        bulan = bulan.replace("Oktober", "OCT");
                        bulan = bulan.replace("November", "NOV");
                        bulan = bulan.replace("Desember", "DEC");
                    
                    }
                    $scope.dataDetailBillingStatement[idx]['@attributes'].NewName = bulan;
                });
            });

        }


        $scope.varUnitDetails = function (id) {
            return $scope['btn_unit_' + id];
        }

        $scope.showHideUnitDetails = function (id) {
            $scope['btn_unit_' + id] = !$scope['btn_unit_' + id];
        }

        $scope.changestatusRead = function () {
            if (!$scope.haveReadTerm) {
                $scope.haveReadTerm = true;
            } else {
                $scope.haveReadTerm = false;
            }
        }

        $scope.showTermConditionModal = function () {

            $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
            var ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran_en.html";
            if ($scope.lang == 'ina') {
                ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran_in.html";
            }
    
            $scope.ketentuanLink = $sce.trustAsResourceUrl(ketentuanLink);
    
            $ionicModal.fromTemplateUrl('partials/sides/termconditionModal.html', {
                scope: $scope
            }).then(function (modalTerms) {
                $scope.modalTerms = modalTerms;
    
                console.log($location.path())
    
                if ($location.path().substr(0, 18) == "/app/detailPayment") {
                    $scope.modalTerms.show();
                }
            });
        }

        $scope.closeModalSlider = function () {
            $scope.modalTerms.hide();
        };
    
    


        
        $scope.selectPaymentMethod = function () {
            var val = $scope.paymentType ;
            if (!val) {
                if($scope.paymentTypeData[0]==null||!$scope.paymentTypeData[0]){
                    $ionicPopup.alert({
                        template: $filter('translate')('payment_method_not_available'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                }else{
                    $ionicPopup.alert({
                        template: $filter('translate')('choose_payment'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                }
                return false;
            }
            
            if (!$scope.haveReadTerm) {
                $ionicPopup.alert({
                    template: $filter('translate')('read_term_condition'),
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
    
                return false;
            }
    
            if (val == 3) {
                goOvo();
            } else if (val == 4) {
                execMidtransPayment();
            } else {
                $ionicPopup.alert({
                    template: $filter('translate')('choose_payment'),
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
            }
        }

        function goOvo() {
            $location.path() == "/app/";
            $state.go("app.ovo_payment");
        } 

        
    function formattedDate(getTime){
        var d = moment(getTime, 'YYYY-MM-DD HH:mm:ss').toDate();
        
        var lang =  localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        if(lang=='ina'){
            var days = ["Min","Sen","Sel","Rab","Kam","Jum","Sab"];
            var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Agu","Sep","Oct","Nov","Dec"];
        }else{
            var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
            var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
        }
        var seconds = d.getSeconds();
        if(seconds.toString().length==1){
            seconds = "0"+seconds;
        }else{
            seconds = seconds;
        }
        var minutes = d.getMinutes();
        if(minutes.toString().length==1){
            minutes = "0"+minutes;
        }else{
            minutes = minutes;
        }
        var hours = d.getHours();
        if(hours>=12){
            if(hours>=13){
                hours = hours-12;
            }
            var aOp = 'PM';
        }else{
            var aOp = 'AM';
        }

        if(hours.toString().length==1){
            hours = "0"+hours;
        }else{
            hours = hours;
        }
        var day = days[d.getDay()];
        var date = d.getDate();
        if(date.toString().length==1){
            date = "0"+date;
        }else{
            date = date;
        }
        var month = months[d.getMonth()];
        var c = d.getYear();
        var year = c-100;
        
        return day+", "+date+" "+month+" "+year+", "+hours+":"+minutes+":"+seconds+" "+aOp;
        
    }

        $scope.showMessage = showMessage;
        function showMessage(payment, order_id = "", dateAndTime = "", status_payment){
            $scope.message = payment;
            var a = $scope.message.includes("sedang diproses");
            if(lang=='en' && a){
                $scope.message = "Transaction is being processed";
            }
            $scope.transaction_id = order_id;
            $scope.dateAndTime = formattedDate(dateAndTime);
            $scope.status_payment = status_payment;
            $ionicModal.fromTemplateUrl('partials/tabs/billing/popupPayment.html', {
                scope: $scope
            }).then(function (modal) {
                if($scope.modalSuccess!='' && $scope.modalSuccess!=undefined){
                    
                }else{
                    $scope.modalSuccess = modal;
                    $scope.modalSuccess.show();
                }
            });
        }
        
        $scope.closeSuccessModal = function(){
            $scope.modalSuccess.remove();
            $scope.modalSuccess = '';
            if($rootScope.loginOtherBilling) {
                $state.go('app.loginebilling');
            } else{
                $state.go('app.billing');
            }
        }

        $scope.onlyClose = function(){
            $scope.modalSuccess.remove();
            $scope.modalSuccess = '';
        }

        $scope.seePaymentDetail = function(transaction_id){
            $scope.modalSuccess.remove();
            $scope.modalSuccess = '';
            $state.go("app.detailHistoryBilling", { merchanttransactionid: transaction_id });
        }


        $scope.selectTypePayment = function(type_payment){
            $scope.paymentType = type_payment;
            console.log("tipe paymnet" + $scope.paymentType);
        }

    }
    
    function currencyFormatDE(num) {
        return (
          num
            // .toFixed(2) // always two decimal digits
            .replace('.', ',') // replace decimal point character with ,
            .replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
        ) // use . as a separator
    }
    