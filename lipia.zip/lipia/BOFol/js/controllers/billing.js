/**
 * Created by Lenovo on 08/12/2016.
 */
angular
    .module('livein')
    .controller('loginBilling', LoginBilling)
    .controller('getbillingCtrl', getbillingCtrl)
    .controller('transactionBilling', transactionBilling)
    .controller('paymentovo', paymentovo)
    .controller('payment', payment)
    .controller('paymentMidtransBankTransfer', paymentMidtransBankTransfer)
    .controller('paymentMidtransAmount', paymentMidtransAmount)
    .controller('paymentMidtransCreditCard', paymentMidtransCreditCard)
    .controller('paymentMidtransCreditCardOTP', paymentMidtransCreditCardOTP)
    .controller('paymentMidtransKodeBayar', paymentMidtransKodeBayar)
    .controller('paymentMidtransGoPay', paymentMidtransGoPay);


function LoginBilling($rootScope, $ionicHistory, $stateParams, $location, $scope, $state, billingServices, $ionicLoading, $ionicPopup, $filter, $cordovaNetwork) {
    $scope.isBack = true;
    if ($stateParams.isMenu) {
        $scope.isBack = "sidebar";
    }
    if ($stateParams.isMenu == "listCategory") $scope.isBack = "listCategory";
    
    // $ionicHistory.nextViewOptions({
    //     disableBack: true
    // });

    // $scope.GoBackScreen = function () {
    //     $location.path('/app/main');
    // };

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Login eBilling';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }


    $scope.GoBackScreen = function () {
        $state.go('app.billing');
    };

    $rootScope.loginOtherBilling = false;
    $scope.loginbilling = function (email) {

        // /if($cordovaNetwork.isOnline()) {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        $rootScope.emailres = email;

        billingServices.loginBillingServices(email, function (response) {
            if (response != false) {
                $scope.data = response.data;
                if ($scope.data) {
                    $ionicLoading.show({
                        template: response.message,
                        duration: 2000
                    });
                    getdata(response);
                    // $state.go('app.billing2'); 
                    $rootScope.loginOtherBilling = true;
                    $state.go('app.otherbilling'); 

                    $scope.master = '';

                    $scope.reset = function () {
                        $scope.email = angular.copy($scope.master);
                    };

                    $scope.reset();
                } else if (!response.status) {
                    $ionicLoading.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: $filter('translate')('login_failed'),
                        template: response.message,
                        okText: $filter('translate')('try_again'),
                        cssClass: "alertPopup"
                    });
                } else {
                    $ionicLoading.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: $filter('translate')('login_failed'),
                        template: $filter('translate')('check_email'),
                        okText: $filter('translate')('try_again'),
                        cssClass: "alertPopup"
                    });
                }
                $scope.data = response;
                // alert( $scope.data);
            } else {
                $ionicLoading.hide;
                console.log(response);
            }

        });
    }

    function getdata(data) {


        $rootScope.datasite = [];
        $scope.datares = data.data['@attributes'];


        angular.forEach(data.data.Site, function (value, key) {
            $scope.datasite.push(value);

        });
    }

}

function getbillingCtrl($window, $scope, $cordovaNetwork, $filter, $rootScope, billingServices, $ionicLoading, $ionicPopup, $ionicSlideBoxDelegate, $state, $ionicModal, $sce, $localStorage, $cordovaSocialSharing, $ionicHistory) {
    //draggable
    $scope.onDragStop = function (data, event) {
        var floatingButton = document.getElementById('floating_btn');
        var style = floatingButton.style;
        var bottom = style.bottom;
        var right = style.right;
        var newStyle = {
            // bottom: Math.abs(Math.round(event.y / $window.innerHeight * 100) - 100) + '%',
            bottom: (Math.abs(event.y - screen.height)) + 'px',
            right: (Math.abs(event.x - screen.width)) + 'px'
        }

        if (event.x <= 0 || event.x >= screen.width || event.y <= 0 || event.y >= screen.height) {
            console.log('out of screen');
            floatingButton.style.bottom = floatingButton.style.bottom;
            floatingButton.style.right = floatingButton.style.right;
        } else {
            floatingButton.style.bottom = newStyle.bottom;
            floatingButton.style.right = newStyle.right;
        }

        console.log(screen.height - event.y);
        // console.log($window.innerWidth);
    }

    //end_draggable

    $scope.siteidop = $rootScope.datasite;
    if ($scope.siteidop) {
        if ($scope.siteidop.length > 0) {
            $scope.selected = $scope.siteidop[0];
            $scope.siteid = $scope.siteidop[0].SiteID;
        }
    }

    getdatabilling();

    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.slidechange = function (index) {
        $scope.periodname = $scope.periodes[index]['@attributes'].Name;
        console.log(index);
    }

    $scope.selectedsiteid = function (elected) {
        $scope.selected = elected.SiteID;
        getdatabilling();
    }

    $scope.paynow = function () {
        // if ($cordovaNetwork.isOnline()) {
        $rootScope.unitno = [];
        $rootScope.unitCode = [];
        $rootScope.datares = $scope.atributeres;

        angular.forEach($scope.periodes, function (value, key) {
            angular.forEach(value.Unit, function (valueunit, keyunit) {
                $scope.unitno.push(valueunit['@attributes'].UnitNo)
                $scope.unitCode.push(valueunit['@attributes'].UnitCode)
                console.log("console valueunit", valueunit);
            })
        })

        console.log($scope.unitno);
        $rootScope.unitnofilter = [];
        $rootScope.unitCodefilter = [];
        $rootScope.attributpayment = $scope.atributeres;
        $scope.unitno.filter(function (item, index, inputArray) {
            var findUnit = inputArray.indexOf(item) == index;
            if (findUnit == true) {
                $rootScope.unitnofilter = $rootScope.unitnofilter + item + ',';
            }
        });

        $scope.unitCode.filter(function (item, index, inputArray) {
            var findUnit = inputArray.indexOf(item) == index;
            if (findUnit == true) {
                $rootScope.unitCodefilter = $rootScope.unitCodefilter + item + ',';
            }
        });

        var confirmPopup = $ionicPopup.confirm({
            template: $filter('translate')('confirm_payment'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                $state.go('app.payment');
            } else {
                $state.go('app.loginebilling');
            }
        });
    }

    function getdatabilling() {
        $scope.ShowSpinnerStatus = true;

        billingServices.getbilling($rootScope.emailres, $scope.siteid, function (response) {
            // $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

            if (response != false) {
                $scope.btnAmountpaid = 'amount';
                $scope.atributeres = response.data['@attributes'];
                if (($scope.atributeres.BillingOutstandingBalance).toString().toLowerCase().includes("proccess")) {
                    $scope.btnAmountpaid = 'proccess';
                } else if ($scope.atributeres.BillingOutstandingBalance == "0") {
                    $scope.btnAmountpaid = 0;
                }

                $scope.periodes = response.data.Periode;
                if ($scope.periodes) {
                    if ($scope.periodes.length > 0) {
                        $scope.cek = $scope.periodes[0].Unit.length;
                    }
                }

                $scope.billingoutstandingbalance = $scope.atributeres.BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
                // $scope.amountpaid = $scope.billingoutstandingbalance.slice(0, -5);
                $scope.amountpaid = $scope.billingoutstandingbalance;

                if ($scope.cek > 1) {
                    var alertPopup = $ionicPopup.alert({
                        template: $filter('translate')('more_unit'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    $ionicSlideBoxDelegate.update();

                } else {
                    $ionicSlideBoxDelegate.update();
                }
                // $ionicLoading.hide();
                $scope.ShowSpinnerStatus = false;
            } else {
                // $ionicLoading.hide()
                console.log('else respon: ' + response);
                // $scope.atributeres = response.data['@attributes'];
                // $scope.periode = response.data.periode;
                // console.log($scope.atributeres);
            }

            if ($scope.periodes) {
                $scope.periodname = $scope.periodes[0]['@attributes'].Name;
            }            // $scope.ShowSpinnerStatus = false; //close loading
        });
    }

    $ionicModal.fromTemplateUrl('partials/sides/menuButtonComplaint.html', {
        scope: $scope
    }).then(function (modalMenu) {
        $scope.modalMenu = modalMenu;
    });

    $scope.openMenu = function () {
        $scope.modalMenu.show();
    }

    $scope.closeModalSlider = function () {
        $scope.modalMenu.hide();
    };

    $scope.shareemail = function () {
        $cordovaSocialSharing
            .shareViaEmail("Note : This complaint sent from LippoCikarang.com mobile apps.", "Complaint/Report", ['CS@lippo-cikarang.com'], ['', ""], [' ', ""], null)
            .then(function (result) {
                // Success!
            }, function (err) {
                alert("Cannot share on Email" + error);
            });
        $scope.modalMenu.hide();
    }

    //clear cache
    var success = function (status) {
        console.log('Success: ' + status);
    };
    var error = function (status) {
        console.log('Error: ' + status);
    };
    // window.CacheClear(success, error);
    //end of clear cache

    // $ionicHistory.clearHistory();
    // $ionicHistory.clearCache().then(function() {
    //     console.log('yes berhasil coi')
    //     deferred.resolve();
    //   });
}

function payment($scope, $location, $cordovaNetwork, billingServices, $rootScope, $state, $ionicPopup, $filter, $ionicHistory, $ionicModal, $sce, $localStorage, $ionicLoading) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

    getPaymentCharge();
    $scope.status = 0;

    $scope.unitno = $rootScope.unitnofilter;
    $scope.unitCode = $rootScope.unitCodefilter;
    $scope.atribute = $rootScope.attributpayment;
    $scope.haveReadTerm = false;

    $scope.showTermConditionModal = function () {

        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        var ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran_en.html";
        if ($scope.lang == 'ina') {
            ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran_in.html";
        }

        $scope.ketentuanLink = $sce.trustAsResourceUrl(ketentuanLink);

        $ionicModal.fromTemplateUrl('partials/sides/termconditionModal.html', {
            scope: $scope
        }).then(function (modalTerms) {
            $scope.modalTerms = modalTerms;

            console.log($location.path())

            if ($location.path() == "/app/payment") {
                $scope.modalTerms.show();
            }
        });
    }

    $scope.changestatusRead = function () {
        if (!$scope.haveReadTerm) {
            $scope.haveReadTerm = true;
        } else {
            $scope.haveReadTerm = false;
        }
    }

    $scope.closeModalSlider = function () {
        $scope.modalTerms.hide();
    };

    $scope.selectPaymentMethod = function (val) {
        if (!$scope.haveReadTerm) {
            $ionicPopup.alert({
                template: $filter('translate')('read_term_condition'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });

            return false;
        }
        if (!val) {
            $ionicPopup.alert({
                template: $filter('translate')('choose_payment'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
            return false;
        }

        if (val == 'ovo') {
            goOvo();
        } else if (val.payment_type == 4) {
            execMidtransPayment();
        } else {
            $ionicPopup.alert({
                template: $filter('translate')('choose_payment'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
        }
    }

    function goOvo() {
        $location.path() == "/app/";
        $state.go("app.ovo_payment");
    }

    function getPaymentCharge() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.getPaymentType(function (response) {

            if (response != false) {
                $scope.paymentTypeData = response;
                $scope.chargePayment = 0;
                var idxOther = response.findIndex(x => x.payment_type == 4)
                if (idxOther > -1) {
                    $scope.chargePayment = response[idxOther].charge;
                }
                $ionicLoading.hide();
            } else {
                $ionicLoading.hide();
            }
        });
    }

    function execMidtransPayment() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        loadTotalPay();
        loadMidtransPayment();
    }

    function loadTotalPay() {
        if ($rootScope.attributpayment) {
            $scope.totalAmount = parseFloat($rootScope.attributpayment.BillingOutstandingBalance);

            $scope.admin = parseFloat($scope.chargePayment);
            $scope.totalBayar = $scope.admin + $scope.totalAmount;

            $rootScope.transferPaymentChargeAdmin = $scope.admin;
            $rootScope.transferPaymentTotal = $scope.totalBayar;
        }
    }

    function analyticMidtrans(response) {
        // ----- Analytic Screen
        if (window.ga) {
            var payment_type = "Others Bank";
            if (response.payment_type == "gopay" || response.payment_type == "credit_card") {
                payment_type = response.payment_type;
            } else if (response.payment_type == "echannel") {
                payment_type = "Mandiri";
            } else if (response.hasOwnProperty("permata_va_number")) {
                payment_type = "Permata";
            } else if (response.hasOwnProperty("va_number")) {
                payment_type = response.va_number[0].bank;
            }

            var analyticView = 'Payment ' + payment_type;
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Payment', analyticView);
            console.log("Analytic - Payment - " + analyticView);
        }
    }

    function cekTransactionGojek(data) {
        billingServices.detailhistory(data.order_id, function (response) {
            console.log("cekTransactionGojek")
            console.log(response)
            if (response) {
                if (response.data) {
                    if (response.data.status == "success") {
                        showMessage($filter('translate')('payment_succeed'));
                    } else if (response.data.status == "pending") {
                        showMessage($filter('translate')('payment_has_been_canceled'));
                    } else {
                        showMessage($filter('translate')('there_has_been_an_error_our_system'));
                    }
                } else {
                    showMessage($filter('translate')('there_has_been_an_error_our_system'));
                }
            } else {
                showMessage($filter('translate')('there_has_been_an_error_our_system'));
            }
            $state.go('app.loginebilling');
        });
    }


    function showMessage(message) {
        $ionicPopup.alert({
            template: message,
            okText: $filter('translate')('okay'),
            cssClass: "alertPopup"
        });
    }

    function loadMidtransPayment() {
        billingServices.midtransPayment(
            $rootScope.attributpayment.Name,
            $rootScope.emailres,
            $rootScope.attributpayment.SiteID,
            $rootScope.transferPaymentTotal,
            $scope.chargePayment,
            function (response) {
                $ionicLoading.hide();
                if (response) {
                    if (response.status == "success") {
                        $scope.showUrl = true;
                        $rootScope.url_midtrans_payment = $sce.trustAsResourceUrl(response.redirect_url);
                        var language = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
                        if (localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina') language = 'id';
                        snap.pay(response.token, {
                            onSuccess: function (result) {
                                console.log('success');
                                console.log(result);
                                showMessage(result.status_message);
                                analyticMidtrans(result);
                                $ionicHistory.nextViewOptions({
                                    disableBack: true
                                });
                                $state.go('app.loginebilling');
                            },
                            onPending: function (result) {
                                console.log('pending');
                                console.log(result);
                                if (result.payment_type == "gopay") {
                                    cekTransactionGojek(result);
                                } else {
                                    showMessage(result.status_message);
                                    $state.go('app.loginebilling');
                                }
                                analyticMidtrans(result);
                                $ionicHistory.nextViewOptions({
                                    disableBack: true
                                });
                            },
                            onError: function (result) {
                                console.log('error');
                                console.log(result);
                                showMessage(result.status_message);
                                $ionicHistory.nextViewOptions({
                                    disableBack: true
                                });
                                $state.go('app.loginebilling');
                            },
                            onClose: function () {
                                console.log('customer closed the popup without finishing the payment');
                                showMessage($filter('translate')('transaction_cancelled'));
                            },
                            language: language,
                            gopayMode: 'deeplink'
                        });
                    } else {
                        var message = response.message;
                        if (localStorage.getItem('NG_TRANSLATE_LANG_KEY' == 'ina')) {
                            message = response.message_id ? response.message_id : response.message;
                        }
                        $ionicPopup.alert({
                            title: "Payment Status",
                            template: message,
                            okText: $filter('translate')('okay'),
                            cssClass: "alertPopup"
                        });
                    }
                } else {
                    $ionicPopup.alert({
                        template: $filter('translate')('there_has_been_an_error_our_system'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                }
            });
    }
}

function transactionBilling($rootScope, $scope) {
    nameres = $rootScope.attributpayment.Name;
    $scope.totalamount = $rootScope.attributpayment.BillingOutstandingBalance;
    $scope.siteid = $rootScope.attributpayment.SiteID;

    $scope.nameurl = nameres.replace(' ', '%20');

    if ($rootScope.type_payment.match('Cimb Clicks')) {
        $scope.selectpayment = 2

    } else if ('Credit Card') {
        $scope.selectpayment = 1

    }

    $scope.url = "http://innodev.vnetcloud.com/liveinpayment/payment?name=" + $scope.nameurl +
        "&email=" + $rootScope.emailres +
        "&siteid=" + $scope.siteid +
        "&orgid=1" +
        "&amount=" + $scope.totalamount +
        "&paymenttype=" + $scope.selectpayment;

    console.log($scope.url);
}

function paymentovo($scope, $filter, $rootScope, $localStorage, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory) {
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    $scope.changeStatusSaveOVO  = function(){
        if (!$scope.haveOvoId) {
            $scope.haveOvoId = true;
        } else {
            $scope.haveOvoId = false;
        }
    }

    $scope.phonenumberOVO = null;
    if ($localStorage.ovoID) {
        $scope.phonenumberOVO = $localStorage.ovoID;
        $scope.haveOvoId = true;
    }

    $scope.myGoBack = function () {
        var confirmPopup = $ionicPopup.confirm({
            template: $filter('translate')('cancel_ovo'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                $ionicHistory.goBack();
            } else { }
        });
    }

    $scope.submtpayment = function (phonenumber) {
        if (!phonenumber) {
            $ionicPopup.alert({
                title: $filter('translate')('failed'),
                template: $filter('translate')('phonenumber_cant_empty'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
            return false;
        }
        if ($scope.haveOvoId) {
            $localStorage.ovoID = phonenumber;
        } else {
            $localStorage.ovoID = null;
        }

        if ($cordovaNetwork.getNetwork() != Connection.NONE) {
            $ionicLoading.show({
                template: 'Loading...',
            })

            billingServices.ovopaymet_service(
                $rootScope.attributpayment.Name,
                $rootScope.emailres,
                $rootScope.attributpayment.SiteID,
                $rootScope.attributpayment.BillingOutstandingBalance,
                phonenumber, getdataresponse
            )
        } else {
            var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('failed'),
                template: "check your connection",
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
        }

        function getdataresponse(response) {

            if (response != false) {
                status = response.status;
                console.log("ini status: " + status);

                if (status == '200' || status == 200) {
                    console.log("masuk 200");
                    if(lang=='ina'){
                        message = response.message_id;
                    }else{
                        message = response.message;
                    }
                    if(message==''){
                        message = response.message;
                    }
                    showalertpopup(message, 200);

                } else if (status == '103' || status == 103) {
                    console.log("masuk 103");
                    if(lang=='ina'){
                        message = response.message_id;
                    }else{
                        message = response.message;
                    }
                    if(message==''){
                        message = response.message;
                    }
                    showalertpopup(message, 103);

                } else if (status == 500 || status == '500') {
                    console.log("masuk 500");
                    if(lang=='ina'){
                        message = response.message_id;
                    }else{
                        message = response.message;
                    }
                    if(message==''){
                        message = response.message;
                    }
                    showalertpopup(message, 500);
                } else {
                    if(lang=='ina'){
                        message = response.message_id;
                    }else{
                        message = response.message;
                    }
                    if(message==''){
                        message = response.message;
                    }
                    showalertpopup(message, 200);
                }
            } else {
                $ionicPopup.alert({
                    title: $filter('translate')('there_has_been_an_error_our_system'),
                    template: "check your connection",
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
            }
        }

        function showalertpopup(message, status) {
            console.log("masuk alertnya dong");
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.alert({
                title: "Payment Status",
                template: message,
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });


            alertPopup.then(function (res) {
                if (status == 103 || status == 500) {
                    // $state.go("app.billing");
                    // $ionicHistory.nextViewOptions({
                    //     disableBack: true
                    // });
                }else if (status == 200) {
                    $state.go("app.billing");
                    $ionicHistory.nextViewOptions({
                        disableBack: true
                    });
                } else
                    console.log('Thank you for not eating my delicious ice cream cone');
            });

            // ----- Analytic Screen
            if (window.ga) {
                var analyticView = 'Payment OVO';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Payment', analyticView);
                console.log("Analytic - Payment - " + analyticView);
            }

        }

    }

}


function paymentMidtransBankTransfer($scope, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory) {

    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    getPaymentMethod();

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    $scope.selectPaymentMethod = function (val) {
        $state.go("app.midtrans_payment_amount");
        $rootScope.selectedPaymentType = val;
        $rootScope.isCreditCard = false;
    }

    function getPaymentMethod() {
        billingServices.getPaymentType(function (response) {
            $timeout(function () {
                if (response != false) {
                    $scope.paymentTypeData = [];
                    angular.forEach(response, function (val) {
                        if (val.payment_type >= 5 && val.payment_type <= 8) {
                            $scope.paymentTypeData.push(val);
                        }
                    });
                    $ionicLoading.hide();
                } else {
                    $ionicLoading.hide();
                }
            }, 1000);
        });
    }
}


function paymentMidtransAmount($scope, $ionicPlatform, $cordovaAppAvailability, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory, $cordovaFile, $cordovaFileTransfer, $cordovaFileTransfer, $cordovaFile, $timeout, $cordovaFileOpener2, $window) {

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    loadTotalPay();

    function loadTotalPay() {

        if ($rootScope.attributpayment) {
            $scope.totalAmount = parseFloat($rootScope.attributpayment.BillingOutstandingBalance);

            $scope.admin = parseFloat($rootScope.selectedPaymentType.charge);
            if ($rootScope.selectedPaymentType.isPct) {
                $scope.admin = $scope.admin / 100 * $scope.totalAmount;
            }

            $scope.totalBayar = $scope.admin + $scope.totalAmount;

            $rootScope.transferPaymentChargeAdmin = $scope.admin;
            $rootScope.transferPaymentTotal = $scope.totalBayar;
        }

    }

    $scope.payNow = function () {
        if ($rootScope.isCreditCard) payWithCreditCard();
        else payMidtransPayment();
    };

    $scope.downloadGuideFile = function () {
        if ($rootScope.selectedPaymentType.guide_file) {
            window.open($rootScope.selectedPaymentType.guide_file, "_system", "location=yes,enableViewportScale=yes,hidden=no");
        } else {
            $ionicPopup.alert({
                template: $filter('translate')('guide_file_not_exist'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            })

        }
    };

    function payWithCreditCard() {
        $state.go("app.midtrans_payment_creditcard");
    }

    function payWithGoPay(deeplink) {
        $rootScope.deeplinkGoPay = deeplink;

        var scheme;

        // Don't forget to add the cordova-plugin-device plugin for `device.platform`
        if (device.platform === 'iOS') {
            scheme = 'gojek://';
        }
        else if (device.platform === 'Android') {
            scheme = 'com.gojek.app';
        }
        // don't forget to add  on golder platforms/ios/<appname>/<appname>-Info.plist
        // <key>LSApplicationQueriesSchemes</key>
        // <array>
        //   <string>gojek</string>
        // </array>  

        // this function invokes the plugin:    
        appAvailability.check(
            scheme,
            function onSucces(result) {
                gotoApps();
            },
            function onError(error) {
                gotoAppStore();
            }
        );

        function gotoApps() {
            window.open(deeplink, '_system', 'location=no');
            // window.open('ovo://', '_system', 'location=no'); -- example
            console.log('Gojek Installed');
            $state.go('app.loginebilling');
        }

        function gotoAppStore() {
            if (device.platform === 'iOS') {
                window.open('https://itunes.apple.com/id/app/go-jek/id944875099?l=id&mt=8', '_system', 'location=no');
            } else {
                window.open('https://play.google.com/store/apps/details?id=com.gojek.app', '_system', 'location=no');
            }

            console.log('Gojek Not Installed');
        }


        //Jika fungsi ini akan dia rehkan memakai web view maka uncomment state dibawah ini
        // $state.go("app.payment_midtrans_gopay");
    }

    function payMidtransPayment() {
        $scope.loadPayment = true;
        if ($rootScope.selectedPaymentType.payment_type == 9) {
            var scheme;
            // Don't forget to add the cordova-plugin-device plugin for `device.platform`
            if (device.platform === 'iOS') {
                scheme = 'gojek://';
            }
            else if (device.platform === 'Android') {
                scheme = 'com.gojek.app';
            }
            // don't forget to add  on golder platforms/ios/<appname>/<appname>-Info.plist
            // <key>LSApplicationQueriesSchemes</key>
            // <array>
            //   <string>gojek</string>
            // </array>  

            // this function invokes the plugin:    
            appAvailability.check(
                scheme,
                function onSucces(result) {
                    nextApps();
                },
                function onError(error) {
                    gotoAppStore();
                }
            );

            function nextApps() {
                console.log('Gojek Installed');
                $scope.loadPayment = true;
            }

            function gotoAppStore() {
                if (device.platform === 'iOS') {
                    window.open('https://itunes.apple.com/id/app/go-jek/id944875099?l=id&mt=8', '_system', 'location=no');
                } else {
                    window.open('https://play.google.com/store/apps/details?id=com.gojek.app', '_system', 'location=no');
                }
                console.log('Gojek Not Installed');
                $scope.loadPayment = false;
                return false;
            }
        }

        if (!$scope.loadPayment) {
            return false;
        }

        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.midtransPayment(
            $rootScope.attributpayment.Name,
            $rootScope.emailres,
            $rootScope.attributpayment.SiteID,
            $rootScope.transferPaymentTotal,
            $rootScope.selectedPaymentType.payment_type,
            $rootScope.transferPaymentChargeAdmin,
            function (response) {
                if (response != false) {
                    var alertPopup = $ionicPopup.alert({
                        title: $filter('translate')('payment_status'),
                        template: response.message,
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    $ionicLoading.hide();
                    alertPopup.then(function (res) {
                        if (res) {
                            $ionicHistory.nextViewOptions({
                                disableBack: true
                            });

                            if (response.status == "success" || response.status == "capture" || response.status == "pending") {
                                if ($rootScope.selectedPaymentType.payment_type == 9) {
                                    if (response.deeplink) payWithGoPay(response.deeplink);
                                } else if ($rootScope.selectedPaymentType.payment_type >= 5 && $rootScope.selectedPaymentType.payment_type <= 8) {
                                    $rootScope.dataVirtualTransaction = response;
                                    $state.go("app.midtrans_payment_kode_bayar");
                                } else {
                                    $state.go('app.loginebilling');
                                }
                            } else {
                                $state.go('app.loginebilling');
                            }
                        }

                        // ----- Analytic Screen
                        if (window.ga) {
                            var analyticView = 'Payment ' + $rootScope.selectedPaymentType.name;
                            window.ga.trackView(analyticView);
                            window.ga.trackEvent('Payment', analyticView);
                            console.log("Analytic - Payment - " + analyticView);
                        }
                    });
                    $ionicLoading.hide();
                } else {
                    $ionicPopup.alert({
                        template: $filter('translate')('there_has_been_an_error_our_system'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    $ionicLoading.hide();
                }
            });
    }

}

function paymentMidtransCreditCard($scope, $localStorage, $ionicModal, $sce, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory) {
    var phone = null;
    if ($localStorage.currentUser) {
        if ($localStorage.currentUser.data[0].phone) {
            var str = $localStorage.currentUser.data[0].phone;
            phone = parseInt(str.replace(/\D+/g, ''));
        }
    }

    $scope.userCC = {
        email: $rootScope.emailres,
        phone: phone,
        card_number: null,
        card_cvv: null,
        card_exp_date: null,
    };
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    $scope.showTermConditionModal = function (redirect_url) {
        $scope.ketentuanLink = $sce.trustAsResourceUrl(redirect_url);

        $ionicModal.fromTemplateUrl('partials/sides/payment_midtrans_creditcard_otp.html', {
            scope: $scope
        }).then(function (modal) {
            $scope.modalCreditCardOTP = modal;
            $scope.modalCreditCardOTP.show();
        });
    }

    $scope.closeModalSlider = function () {
        $scope.modalCreditCardOTP.hide();
        payMidtransPaymentCreditCard($scope.userCC, $rootScope.tokenIdCreditCard);
        // payMidtransPaymentCreditCard(dataUser, $rootScope.tokenIdCreditCard);
    };

    $scope.payNow = function (dataUser) {
        if (!dataUser.phone || !dataUser.email || !dataUser.card_number || !dataUser.card_cvv || !dataUser.card_exp_date) {
            var message = "Input is required";
            if (!dataUser.email) {
                message = "email is required";
            }
            $ionicPopup.alert({
                // title: "Required input",
                template: message,
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
            return false;
        }
        // var dataUser = $scope.userCC;
        // ----- Analytic Screen
        if (window.ga) {
            var analyticView = 'Payment Credit Card';
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Payment', analyticView);
            console.log("Analytic - Payment - " + analyticView);
        }

        var card_number_input = (dataUser.card_number).toString();
        var card_number_int = parseInt(card_number_input.replace(/\s+/g, ''));

        //january is 0 -> so we should add 1 to make january value be 1
        var card_exp_month = dataUser.card_exp_date.getMonth() + 1;
        var card_exp_year = dataUser.card_exp_date.getFullYear();

        $rootScope.paramsCreditCardData = null;
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.getTokenMidtransPaymentCreditCard(
            $rootScope.transferPaymentTotal,
            card_number_int,
            card_exp_month,
            card_exp_year,
            dataUser.card_cvv,
            function (response) {
                if (response) {
                    if (response.redirect_url) {
                        $rootScope.paramsCreditCardData = {
                            input: dataUser,
                            token_id: response.token_id,
                            redirect_url: response.redirect_url
                        }
                        // $state.go('app.midtrans_payment_creditcard_otp');
                        $scope.showTermConditionModal(response.redirect_url);

                        // window.open(response.redirect_url, '_system', 'location=no');
                        // payMidtransPaymentCreditCard(dataUser, $rootScope.tokenIdCreditCard);
                        $rootScope.tokenIdCreditCard = response.token_id;
                    } else {
                        var msg = $filter('translate')('transaction_failed');
                        if (response.message) {
                            msg = response.message;
                        }
                        $ionicPopup.alert({
                            template: msg,
                            okText: $filter('translate')('okay'),
                            cssClass: "alertPopup"
                        });

                        $ionicHistory.nextViewOptions({
                            disableBack: true
                        });
                        $state.go('app.loginebilling');
                    }
                    $ionicLoading.hide();
                } else {
                    $ionicPopup.alert({
                        template: $filter('translate')('transaction_failed'),
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    $ionicLoading.hide();
                }
            });


    };

    function payMidtransPaymentCreditCard(dataUser, tokenIdCreditCard) {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.midtransPaymentCreditCard(
            tokenIdCreditCard,
            $rootScope.attributpayment.Name,
            dataUser.phone,
            dataUser.email,
            $rootScope.attributpayment.SiteID,
            $rootScope.transferPaymentTotal,
            $rootScope.selectedPaymentType.payment_type,
            $rootScope.transferPaymentChargeAdmin,

            function (response) {
                if (response != false) {
                    $ionicLoading.hide();
                    var alertPopup = $ionicPopup.alert({
                        title: "Payment Status",
                        template: response.message,
                        okText: $filter('translate')('okay'),
                        cssClass: "alertPopup"
                    });
                    alertPopup.then(function (res) {
                        if (res) {
                            $ionicHistory.nextViewOptions({
                                disableBack: true
                            });

                            if (response.status != "error") {
                                $state.go('app.loginebilling');
                            }
                        }
                    });
                    $ionicLoading.hide();
                } else {
                    $ionicLoading.hide();
                }

            });
    }
}

function paymentMidtransCreditCardOTP($scope, $sce, $localStorage, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory) {
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    // filecontainer
    if ($rootScope.paramsCreditCardData) {
        $scope.redirect_url = $rootScope.paramsCreditCardData.redirect_url
    }
    $scope.trustSrc = function (src) {
        return $sce.trustAsResourceUrl(src);
    }

}

function paymentMidtransKodeBayar($scope, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory) {
    $scope.myGoBack = function () {
        // $ionicHistory.goBack();
        $state.go('app.loginebilling');
    };

    $ionicHistory.nextViewOptions({
        disableBack: true
    });

    // format va number
    function getFormattedAccountNo(accountNo) {
        var formattedAccountNo = '';
        for (var i = 0; i < accountNo.toString().length; i++) {
            if (formattedAccountNo.length % 5 == 0) {
                formattedAccountNo += ' ';
            }
            formattedAccountNo += accountNo.toString().charAt(i);
        }
        return formattedAccountNo;
    }

    getData();

    function getData() {
        if ($rootScope.dataVirtualTransaction['va_number']) {
            $scope.virtualTrNo = getFormattedAccountNo($rootScope.dataVirtualTransaction['va_number']);
        }
        $scope.bill_key = $rootScope.dataVirtualTransaction['bill_key'];
        $scope.biller_code = $rootScope.dataVirtualTransaction['biller_code'];
        $scope.paymentTypeName = $rootScope.selectedPaymentType.name;
        $scope.totalTransfer = $rootScope.transferPaymentTotal;
    }

}

function paymentMidtransGoPay($scope, $sce, $sceDelegate, $timeout, $filter, $rootScope, $cordovaNetwork, billingServices, $state, $ionicLoading, $ionicPopup, $ionicHistory, $cordovaAppAvailability) {
    $scope.deeplink = $rootScope.deeplinkGoPay;
    $scope.myGoBack = function () {
        $state.go('app.loginebilling');
    };

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Payment Go-Pay';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Payment', analyticView);
        console.log("Analytic - Payment - " + analyticView);
    }

    $scope.trustSrc = function (src) {
        return $sce.trustAsResourceUrl(src);
    }
    // var ref = window.open(deeplink, '_blank', 'location=no');
}