angular
    .module('livein', ['ionic', 'ngDraggable', 'ngCordovaOauth', 'ngCordova', 'ionic-toast', 'ngStorage', 'ngCookies', 'angularMoment', 'pascalprecht.translate', 'ionic.contrib.drawer.vertical', 'ds.clock', 'ngOpenFB', 'ionic.service.core', 'ionic.service.push', 'clickAndWait', 'base64', "ngSanitize",
        "com.2fdevs.videogular",
        "com.2fdevs.videogular.plugins.controls",
        "com.2fdevs.videogular.plugins.overlayplay",
        "com.2fdevs.videogular.plugins.poster", , 'angular-intro'
    ])
    .directive('ngEnter', ngEnter)
    .directive('repeatDone', repeatDone)
    .filter('trustAsResourceUrl', trustAsResourceUrl)
    .config(config)
    .run(run)

function config($stateProvider, $cordovaFacebookProvider, $urlRouterProvider, $translateProvider, $sceDelegateProvider, $ionicConfigProvider, $ionicAppProvider, $httpProvider) {

    var api_link_complaint = "https://lkapi.vnetcloud.com/EcomplaintSmartCityAPIDev/";
    var api_link = "https://innodev.vnetcloud.com/LiveIn/";
    var api_link_payment = "https://innodev.vnetcloud.com/liveinpayment/";
    var api_link_livein_web = "http://innodev.vnetcloud.com/LiveInWeb/";
    
    //Dont forget to check snap js
    // Sandbox : https://app.sandbox.midtrans.com/snap/snap.js
    var api_link_midtrans = "https://app.sandbox.midtrans.com/snap/snap.js";

    // Production : https://app.midtrans.com/snap/snap.js
    // var api_link_midtrans = "https://app.midtrans.com/snap/snap.js";
    var site_id_apps = "5";

    var link_apps_store = "https://itunes.apple.com/us/app/lippo-cikarang/id1191438061?mt=8";
 
    // Identify app 
    $ionicAppProvider.identify({
        // The App ID (from apps.ionic.io) for the server
        app_id: '62a7483e', //app_id: 'd0478393',
        // The public API key all services will use for this app
        api_key: '525ce14c728a8686fd3b1246cf85c2374a84958ebaad29bc', //api_key: 'bc00cfa0b603379dcb68106900d0286c7bc80768f8878d04',
        // Set the app to use development pushes
        //dev_push: true,
        //gcm_id: '999348773193'
    }); 

    //uncommenting the following line makes GET requests fail as well
    //$httpProvider.defaults.headers.common['Access-Control-Allow-Headers'] = '*';
    delete $httpProvider.defaults.headers.common['X-Requested-With'];

    $ionicConfigProvider.navBar.alignTitle('center');
    $ionicConfigProvider.tabs.position('bottom');

    $stateProvider
        .state('splashScreen', {
            url: '/',
            templateUrl: 'partials/splashScreen.html',
            controller: 'splashScreen'
        })
        .state('login', {
            url: "/login",
            templateUrl: "partials/login.html",
            controller: 'login'
        })
        .state('register', {
            url: "/register",
            templateUrl: "partials/register.html",
            controller: 'register'
        })
        .state('forget', {
            cache: false,
            url: "/forget",
            templateUrl: "partials/forgetPassword.html",
            controller: 'forget'
        })
        .state('reset', {
            //cache: false,
            url: "/reset",
            templateUrl: "partials/resetPassword.html",
            controller: 'forget'
        })

        /* start : side menu */

        .state('app', {
            url: "/app",
            cache: false,
            abstract: true,
            templateUrl: "templates/menu.html",
            controller: 'app'
        })
        .state('app.category', {
            url: "/category/:idcategory",
            cache: false,
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenant.html",
                     controller: 'category'
                }
            }
        })
        .state('app.tenantCategory', {
            url: "/tenantCategory/:idcategory",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenantCategory.html",
                    controller: 'tenantCategory'
                }
            }
        })
        .state('app.categories', {
            url: "/categories",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/listCategory.html",
                    controller: 'categoryList'
                }
            }
        })

        .state('app.recomended', {
            url: "/recomended/:idcategory",
            cache: false,
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/recomended.html",
                    controller: 'categoryRecomended'
                }
            }
        })
        .state('app.recommended', {
            url: "/recommended/:idcategory",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/recommended.html",
                    controller: 'recommended'
                }
            }
        })
        .state('app.tenant', {
            url: "/tenantDetail/:idtenant",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenantDetail.html",
                    controller: "sportDetail"
                }
            }
        })
        .state('app.tenantDetailImage', {
            url: "/tenantDetailImage/:idtenant/{index}",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenantDetailImage.html",
                    controller: "sportDetailImage"
                }
            }
        })
        .state('app.tenantHome', {
            url: "/tenantHome/:idtenant",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenantHome.html",
                    controller: "tenantHome"
                }
            }
        })
        .state('app.cityInfo', {
            url: "/aboutUs",
            views: {
                'menu-content': {
                    templateUrl: "partials/aboutus.html",
                    controller: 'aboutUs'
                }
            }
        })
        .state('app.gallery', {
            url: "/gallery",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/gallery.html",
                    controller: "gallery"
                }
            }
        })
        .state('app.detailGallery', {
            cache: false,
            url: "/detailGallery/{index}",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/detailGallery.html",
                    controller: "detailGallery"
                }
            }
        })
        .state('app.getSearchGallery', {
            cache: false,
            url: "/getSearchGallery/:name",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/getSearchGallery.html",
                    controller: "searchGalleryDetail"
                }
            }
        })
        .state('app.detailGallerySearch', {
            cache: false,
            url: "/detailGallerySearch/:gall/{index}",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/detailGallerySearch.html",
                    controller: "searchGalleryDetailImage"
                }
            }
        })
        .state('app.callCenter', {
            url: "/callCenter",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/callCenter.html",
                    controller: "callCenter"
                }
            }
        })
        .state('app.aboutHelp', {
            url: "/aboutHelp",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/aboutHelp.html",
                    controller: "aboutHelp"
                }
            }
        })
        .state('app.helpfulNumber', {
            url: "/helpfulNumber",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/helpfulNumber.html",
                    controller: "useful"
                }
            }
        })
        .state('app.talkToUs', {
            url: "/talkToUs",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/talktoUs.html",
                    controller: "talkToUs"
                }
            }
        })
        .state('app.whatsNew', {
            url: "/whatsNew",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/whatsNew.html",
                    controller: "whatsNew"
                }
            }
        })
        .state('app.whatsNewDetail', {
            url: "/whatsNewDetail/:idnews",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/whatsNewDetail.html",
                    controller: 'whatsNewDetail'
                }
            }
        })
        .state('app.cctvList', {
            url: "/cctvList",
            views: {
                'menu-content': {
                    // templateUrl: "partials/sides/soon.html"
                    templateUrl: "partials/sides/cctvList.html",
                    controller: "cctv"
                }
            }
        })
        .state('app.cctvDetail', {
            url: "/cctvDetail/{index}",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/cctvDetail.html",
                    controller: "cctvDetail"
                }
            }
        })
        .state('app.cctvFull', {
            url: "/cctvFull/:port",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/cctvFull.html",
                    controller: "cctvFull"
                }
            }
        })
        .state('app.forum', {
            //cache: false,
            url: "/forum",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/forum.html",
                    controller: 'forum'
                }
            }
          })
        .state('app.forumdetail', {
            cache: false,
            url: "/forumdetail/:idforum/:idaccount",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/forumdetail.html",
                    controller: 'forumdetail'
                }
            }
        })
        .state('app.forumDetailImage', {
            url: "/forumDetailImage/:idforum/:idx",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/forumDetailImage.html",
                    controller: 'forumdetail'
                }
            }
        })
        .state('app.newforum', {
            url: "/newforum",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/newforum.html",
                    controller: 'topic'
                }
            }
        })
        .state('app.forumupdate', {
            url: "/forumupdate/:idforum",
            views: {
                'menu-content': { 
                    templateUrl: "partials/sides/forumupdate.html",
                    controller: 'forumdetail'
                }
            }
        })
        .state('app.forumComment', {
            url: "/forumComment/:idforum",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/forumComment.html",
                    controller: 'forumComment'
                }
            }
        })

        /* end : side menu */
        /* start : navigation tabs */

        .state('app.main', {
            url: "/main",
            cache: false,
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/main.html",
                    controller: 'mainTabs'
                }
            }
        })
        .state('app.coupon', {
            url: "/coupon",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/coupon.html",
                    controller: 'coupon'
                }
            }
        })
        .state('app.couponDetail', {
            url: "/couponDetail/:idcoupon/:idtenant",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/detailCoupon.html",
                    controller: 'detailCoupon'
                }
            }
        })
        .state('app.searchGlobal', {
            url: "/search/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/search.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchTenants', {
            url: "/searchTenants/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchTenants.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchProperty', {
            url: "/searchProperty/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchProperty.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchDiscount', {
            url: "/searchDiscount/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchDiscount.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchGallery', {
            url: "/searchGallery/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchGallery.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchGalleryDetail', {
            url: "/searchGalleryDetail/:name/{index}",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchGalleryDetail.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.searchNews', {
            url: "/searchNews/:name",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/searchNews.html",
                    controller: 'searchGlobal'
                }
            }
        })
        .state('app.profile', {
            cache: false,
            url: "/profile",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile.html",
                    controller: 'profile'
                }
            }
        })
        /*.state('app.history', {
            url: "/history",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/history.html",
                    controller: "history"
                }
            }
        })*/
        .state('app.myhistory', {
            cache: false,
            url: "/myhistory/:idaccount",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/myhistory.html",
                    controller: "myhistory"
                }
            }
        })
        .state('app.history', {
            url: "/history",
            cahce: false,
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/newhistory.html",
                    controller: "history"
                }
            }
        })
        .state('app.tenantMap', {
            cache: false,
            url: "/tenantMap",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/tenantMapDetail.html",
                    controller: 'tenantMap'
                }
            }
        })
        .state('app.currency', {
            url: "/currency",
            views: {
                'main-content': {
                    templateUrl: "partials/tabs/currency.html",
                    controller: 'currency'
                }
            }
        })
        .state('app.inivitefriend', {
            url: "/inivitefriend",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/invitefriend.html",
                    controller: 'invitefriend'
                }
            }
        })
        .state('app.map', {
            cache: false,
            url: "/map",
            views: {
                'map-content': {
                    templateUrl: "partials/tabs/map.html",
                    controller: 'mainmap'
                }
            }
        })
        .state('app.download', {
            cache: false,
            url: "/download",
            views: {
                'download-content': {
                    templateUrl: "partials/tabs/download.html",
                    controller: 'download'
                }
            }
        })
        .state('app.downloadDetail', {
            url: "/downloadDetail/:iddownload",
            views: {
                'download-content': {
                    templateUrl: "partials/tabs/downloadDetail.html",
                    controller: 'detaildownload'
                }
            }
        })
        .state('app.rate', {
            url: "/rate",
            views: {
                'more-content': {
                    templateUrl: "partials/tabs/profile/rating.html",
                    controller: 'tenant'
                }
            }
        })
        .state('app.bookmark', {
            url: "/bookmark",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/bookmark.html",
                    controller: 'tenant'
                }
            }
        })
        .state('app.listbookmark', {
            cache: false,
            url: "/listbookmark",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/listbookmark.html",
                    controller: 'bookmark'
                }
            }
        })
        .state('app.notification', {
            cache: false,
            url: "/notification",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/notification.html",
                    controller: 'notification'
                }
            }
        })
        .state('app.point', {
            cache: false, 
            url: "/point",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/profile/point.html",
                    controller: 'point' 
                }
            }
        })
        .state('app.historyPoint', {
            url: "/historyPoint",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/profile/historyPoint.html",
                    controller: "historyPoint"
                }
            }
        })
        .state('app.historyVoucher', {
            url: "/historyVoucher",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/profile/historyVoucher.html",
                    controller: "historyVoucher"
                }
            }
        })
        .state('app.newsearchPoint', {
            cache: false,
            url: "/newsearchPoint",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/searchMyPoint.html",
                    controller: "searchMyPoint"
                }
            }
        })
        .state('app.settingVoucher', {
            url: "/settingVoucher",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/profile/settingVoucher.html",
                    controller: "settingVoucher"
                }
            }
        })
        .state('app.listVoucher', {
            url: "/listVoucher/:id_category",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/listVoucher.html",
                    controller: "listVoucher"
                }
            }
        })
        .state('app.voucherDetail', {
            url: "/voucherDetail/:id",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/voucher_detail.html",
                    controller: "voucherDetail"
                }
            }
        })
        .state('app.notificationDetail', {
            url: "/notificationDetail/:idnotif/:bookmarked",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/notificationDetail.html",
                    controller: 'notificationDetail'
                }
            }
        })
        .state('app.editprofile', {
            url: "/editprofile",
            views: {
                'profile-content': {
                    templateUrl: "partials/tabs/profile/editprofile.html",
                    controller: 'editProfile'
                }
            }
        })
        .state('app.more', {
            url: "/more",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/more.html",
                    controller: 'more'
                }
            }
        })
        .state('app.property', {
            url: "/property",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/property.html",
                    controller: 'homeProperty'
                }
            }
        })
        .state('app.propertyEmail', {
            url: "/propertyEmail/:idproperty/:agentemail",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/propertyEmail.html",
                    controller: 'sendEmail'
                }
            }
        })
        .state('app.propertylist', {
            url: "/property/:status",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/propertylist.html",
                    controller: 'property'
                }
            }
        })
        .state('app.propertyDetail', {
            url: "/propertyDetail/:idproperty",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/propertyDetail.html",
                    controller: 'propertyDetail'
                }
            }
        })
        .state('app.propertyDetailImage', {
            url: "/propertyDetailImage/:idproperty/{index}",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/propertyDetailImage.html",
                    controller: 'propertyDetail'
                }
            }
        })
        .state('app.propertysearch', {
            url: "/propertysearch/:searchval/:status",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/propertylistsearch.html",
                    controller: 'property'
                }
            }
        })
        .state('app.bus', {
            cache: false,
            url: "/bus",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/busSchedule.html",
                    controller: 'busSchedule'
                }
            }
        })
        .state('app.worldclock', {
            url: "/worldclock",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/worldclock.html",
                    controller: 'worldclock'
                }
            }
        })
        .state('app.eComplaint', {
            url: "/eComplaint",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/eComplaint.html",
                    controller: 'eComplaint'
                }
            }
        })
        .state('app.loginebilling', {
            url: "/loginebilling:isMenu",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/billing/login.html",
                    controller: "loginBilling"
                }
            }
        })
        .state('app.eComplaintList', {
            cache: false,
            url: "/eComplaintList",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/eComplaintList.html",
                    controller: 'eComplaintList'
                }
            }
        })
        .state('app.eComplaintDetail', {
            url: "/eComplaintDetail/:CaseNumber",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/eComplaintDetail.html",
                    controller: 'eComplaintDetail'
                }
            }
        })
        .state('app.eComplaintAdd', {
            url: "/eComplaintAdd",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/eComplaintAdd.html",
                    controller: 'eComplaintAdd'
                }
            }
        })
        .state('app.billing2', {
            cache: false,
            url: "/billing2",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/billing.html",
                    controller: 'getbillingCtrl' 
                }
            }
        })
        .state('app.billing', {
            url: "/billing",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/billing/main.html",
                    controller: 'mainBilling'
                }
            }
        })
        .state('app.detailHistoryBilling', {
            cache: false,
            url: "/detailHistoryBilling/:merchanttransactionid",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/billing/detailHistory.html",
                    controller: 'detailHistoryBilling'
                }
            }
        })
        .state('app.payment', {
            cache: false,
            url: "/payment",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment.html",
                    controller: 'payment'
                }
            }
        }) 
        .state('app.detailPayment', {
            cache: false,
            url: "/detailPayment/:siteId",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/billing/detailPayment.html",
                    controller: 'detailPayment'
                }
            }
        }) 
        .state('app.otherbilling', {
            url: "/otherbilling",
            views: {
                'menu-content': {
                    templateUrl: "partials/tabs/billing/otherBilling.html",
                    controller: 'otherBilling'
                }
            }
        })
        .state('app.transaction', {
            url: "/transaction",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/transactionBilling.html",
                    controller: 'transactionBilling'
                }
            }
        })
        .state('app.ovo_payment', {
            url: "/paymentovo",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_ovo.html",
                    controller: 'paymentovo'
                }
            }
        })
        .state('app.publictransportation', {
            url: "/publictransportation",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/publictransportation.html",
                    controller: 'publictransportation'
                }
            }
        })
        .state('app.midtrans_payment_bank', {
            url: "/paymentmidtransbanktransfer",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_bank.html",
                    controller: 'paymentMidtransBankTransfer'
                }
            }
        })
        .state('app.midtrans_payment', {
            url: "/paymentmidtrans",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans.html",
                    controller: 'paymentMidtrans'
                }
            }
        })
        .state('app.midtrans_payment_amount', {
            url: "/paymentmidtranstotaltransfer",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_amount.html",
                    controller: 'paymentMidtransAmount'
                }
            }
        })
        .state('app.midtrans_payment_creditcard', {
            url: "/paymentmidtranscreditcard",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_creditcard.html",
                    controller: 'paymentMidtransCreditCard'
                }
            }
        })
        .state('app.midtrans_payment_creditcard_otp', {
            url: "/paymentmidtranscreditcardotp",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_creditcard_otp.html",
                    controller: 'paymentMidtransCreditCardOTP'
                }
            }
        })
        .state('app.midtrans_payment_kode_bayar', {
            url: "/paymentMidtransKodeBayar",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_kode_pembayaran.html",
                    controller: 'paymentMidtransKodeBayar'
                }
            }
        })
        .state('app.payment_midtrans_gopay', {
            url: "/paymentMidtransGoPay",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/payment_midtrans_gopay.html",
                    controller: 'paymentMidtransGoPay'
                }
            }
        })
        .state('app.adsDetail', {
            url: "/adsDetail/:idAds",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/adsDetail.html",
                    controller: 'adsDetail'
                }
            }
        })
        .state('app.needhelp', {
            url: "/needhelp",
            views: {
                'menu-content': {
                    templateUrl: "partials/sides/needHelp.html",
                    controller: 'needhelp'
                }
            }
        });
        

    /* end : navigation tabs */

    //translate
    $translateProvider.translations('en', {
        apilink: api_link,
        apilinkpayment: api_link_payment,
        apilinkcomplaint: api_link_complaint,
        apilinkliveinweb: api_link_livein_web,
        apilinkmidtrans: api_link_midtrans,
        siteidapps: site_id_apps,
        link_apps_store: link_apps_store,
        app_name: 'LippoCikarang.com', //{{'app_name' | translate}}
        app__name: 'Lippo Cikarang',
        // Menuuu
        home_nav: 'Home',
        categories_nav: 'Categories',
        my_complaint_nav: 'My Complaint',
        my_billing_nav: 'My Billing',
        forum_nav: 'Forum',
        cctv_nav: 'CCTV',
        about_us_nav: 'About Us',
        call_center_nav: 'Call Center',
        settings_nav: 'Settings',
        sign_out_nav: 'Sign Out',
        // End of menu
        openDrawer: 'Open Drawer',
        closeDrawer: 'Close Drawer',
        search_title: 'Search',
        eComplaint: 'Do you have any concern? ',
        eComplaint2: 'Just tell us and solved your concern easily.',
        take_pic: 'Take a picture',
        import_gal: 'Select image from gallery',
        choose_img: 'Choose an Images',
        btn_eC: 'Yes, I Have.',
        installed: 'installed',
        not_installed: 'not installed',
        confirm_install_sos: 'Do You want to download Ambulance Siloam 1health mobile apps ?',
        confirm_install_ovo: 'Do You want to download Ovo mobile apps ?',
        desc_empty: 'Description are required!',
        unit_empty: 'Unit are required!',
        concern_empty: 'Concern are required!',
        limit_image: 'Sorry, max images size is 15MB',
        //asline
        sound: 'Sound',
        loading: 'Loading',
        loginmessage: 'Logging in',
        logoutmessage: 'Logging out',
        soon: 'Available Soon',
        Minimum_8_character: 'Password of at least 8 characters',
        about: 'About',
        not_register: 'Your Account is not register',
        accomodation: 'Accomodation',
        action_bookmark: 'Bookmark',
        action_call: 'Call',
        action_map: 'Map',
        action_review: 'Review',
        add_your_photo: 'Add Your Photo',
        address: 'Address',
        apartment: 'Apartments',
        Apartment: 'Apartments',
        with: 'with',
        orange_county: 'Orange County',
        are_resident: 'Are you a resident? Create your account with registered email address in our database to enjoy special feature',
        are_alreadyaccount: 'Already have an account ?',
        resend_email: 'Resend Activation Email',
        art: 'Art & Culture',
        atm_gallery: 'ATM Gallery',
        ATM_Gallery: 'ATM Gallery',
        automotive: 'Automotive',
        Automotive: 'Automotive',
        bakery: 'Bakery & Dessert',
        BAKERY___DESERT: 'Bakery & Dessert',
        bakery___dessert: 'Bakery & Dessert',
        bank: 'Bank',
        Bank: 'Bank',
        bar_cafe_club: 'Bar/Cafe/Club',
        CAFE___LOUNGE___BAR: 'Bar/Cafe/Club',
        cafe___lounge___bar: 'Bar/Cafe/Club',
        cafe_lounge_bar: 'Cafe & Lounge Bar',
        Fast_Food: 'Fast Food',
        fast_food: 'Fast Food',
        beauty: 'Beauty',
        Beauty: 'Beauty',
        book_stationety: 'Book & Stationery',
        Book___Stationery: 'Book & Stationery',
        book___stationery: 'Book & Stationery',
        bookmarked: 'Bookmarked',
        all_bookmarked: 'Already Bookmarked',
        success_bookmark: 'Success Bookmark',
        btn_lets_go: 'Let\'s Go',
        bus: 'Bus',
        buy: 'Buy',
        send_email: 'Send Message',
        captcha_true: 'Email has been sent',
        captcha_false: 'Wrong Captcha',
        new_forum: 'Succeed submitting post! Please wait for admin approval for your post to be published.',
        call_agent: 'Call Agent',
        call: 'Call',
        center: 'Center',
        call_center_html: '<b>Call</b>Center',
        cancel: 'Cancel',
        cctv: 'CCTV',
        chinese: 'Chinese',
        chinese_food: 'Chinese Food',
        close: 'CLOSE',
        close_complaint: 'Close',
        clothes: 'Clothes',
        condominiums: 'Condominiums',
        Condominiums: 'Condominiums',
        cosmetic: 'Cosmetic',
        create_account: 'Create new account',
        create_ur_account: 'CREATE YOUR ACCOUNT',
        daily: 'MONDAY - FRIDAY',
        weekly: 'SATURDAY - SUNDAY',
        expand: 'Expand',
        session: 'SESSION',
        delete: 'Delete',
        deparment_store: 'Department Store',
        department_store: 'Department Store',
        Department_Store: 'Department Store',
        dialog_signout: 'Are you sure want to sign out your mobile apps ?',
        dialog_success_upgrade: 'Your email is registered, <br/> <b>Congratulations</b> <br/>Now you\'re resident!',
        dialog_fail_upgrade: 'Sorry, your email isn\’t registered, <br/> Please contact our Customer service <br/>to register your email',
        dialog_delete: 'Are you sure \n to delete?',
        blm_login: 'Sorry, you are not logged in. Please login from Profile to access this menu.',
        blm_rate: 'Sorry, you are not logged in. Please login from Profile to rate.',
        blm_emailAgen: 'Sorry you are not logged in. Please login from Profile to send an email to agent.',
        intro1: 'Register to experience more <br> <p style="font-size:8px;font-style:italic;margin:0;">special features for residents!</p>',
        intro2: 'Enjoy Special Discount, <br> Register Now!',
        intro3: 'Discover More',
        next: 'Next',
        previous: 'Previous',
        thanks: 'Thanks',
        dining: 'Dining',
        coupon: 'Coupon',
        discount: 'Discount',
        discount_coupon: 'Discount Coupon',
        Kupon: 'Discount',
        download: 'Downloads',
        download_more: 'Download for more',
        ebilling: 'eBilling',
        e_billing: 'e-Billing',
        edit: 'Edit',
        edit_profile: 'Edit Profile',
        education: 'Education',
        Education: 'Education',
        electronic: 'Electronic',
        Electronic_: 'Electronic',
        electronic_: 'Electronic',
        email_agent: 'Email Agent',
        entertaiment: 'Entertainment',
        entertainment: 'Entertainment',
        events: 'Events',
        Acara: 'Events',
        eyewear: 'Eyewear',
        fastfood: 'Fast Food',
        forgot_password: 'Forgot password ?',
        forgot_password_placeholder: 'Email or mobile phone',
        forum: 'Forum',
        gallery: 'Gallery',
        pro_gallery: 'Property Gallery',
        gallery_confirm: 'Are you sure you want to delete gallery forum ?',
        games: 'Games',
        gender: 'Gender',
        get_started: 'GET STARTED',
        golfing: 'Golf',
        gym: 'Gym',
        health: 'Health',
        Kesehatan: 'Health',
        health_care: 'Health Care',
        Health_Care: 'Health Care',
        hello: 'Hello',
        help: 'Help',
        needhelp: 'Need Help',
        help_feedback: 'Help & feedback',
        helpful_number: 'Helpful Number',
        number: 'Date Created',
        what_c: 'What is your concern?',
        desc_c: 'Your concern ...',
        CC: 'Client Code',
        hint_confirm_password: 'Confirm Password',
        hint_email: 'Email',
        hint_pass: 'Password',
        hint_password: 'Password',
        hint_phone: 'Phone',
        hint_topic_desc: 'Discussion Description',
        hint_topic_title: 'Discussion Title',
        hist_cont_1: 'Explore Your Timeline',
        hist_cont_2: 'Location History helps you get useful information - automatic commute predictions and improved search results.',
        hist_cont_3: 'Rediscover the places you\'ve been search and the routes you\'ve traveled in your timeline',
        hist_cont_4: 'Only you can see your timeline',
        home_improvement: 'Home Improvement',
        Home_Improvement: 'Home Improvement',
        hi_home: 'Hi,',
        hospital: 'Hospital',
        hotel: 'Hotel',
        hours_today: 'Hours Today',
        what_new: 'What\'s New',
        indoor_sports: 'Indoor Sports',
        industry: 'Industry',
        Industry: 'Industry',
        industries: 'Industries',
        unit: ' unit',
        insurance: 'Insurance',
        Insurance: 'Insurance',
        invitation_msg: 'Share with your friends',
        invite_friend: 'Invite Friend',
        inviteFriend: 'Share With Your Friends',
        duration_jam: 'hrs',
        duration_mnt: 'mins',
        japanese: 'Japanese',
        Japanese_Food: 'Japanese',
        japanese_food: 'Japanese Food',
        jewelry: 'Jewelry',
        join_us: 'Join us with your social media account',
        karaoke: 'Karaoke',
        leisure: 'Leisure',
        Leisure: 'Leisure',
        login: 'Login',
        login_with: 'Login with',
        login_success: 'Login successfully',
        login_failed: 'Failed!',
        failed: 'Failed!',
        more_unit: 'The payment made from mobile apps will include the payment from ALL UNITS. Please visit Customer Service for any inquiries.',
        facebook_login_failed: 'Facebook login failed',
        must_choose_1: 'You must choose 1 type payment',
        check_email: 'Check your billing email or call Customer Service',
        check_email_login: 'Check your email for activation',
        email2: 'Email is already exist',
        email_exist2: 'Sorry, email is already exist',
        phone_exist2: 'Sorry, phone is already exist',
        cannot_put_email: 'We cannnot put email for verification',
        wrong_email: 'Email or Phone Number not valid',
        enter_credential: 'Please enter the credentials!',
        main: 'Main',
        map: 'Map',
        tenant_map: 'Tenant Map',
        mark: 'Mark as read',
        mart: 'Mart',
        more: 'More',
        exchange: 'Exchange Rates',
        currency: 'Currency',
        language: 'Language',
        success_language: 'You have selected ',
        minimarket: 'Minimarket',
        Minimarket: 'Mart',
        msg_deleted: 'Deleted',
        msg_marked: 'Marked',
        msg_update: 'Update',
        msg_update_failed: 'Update Failed',
        msg_update_success: 'Update Succesfully',
        msg_upgrade_success: 'Update Resident Succesfully',
        msg_delete_success: 'Delete Success',
        msg_delete_failed: 'Delete Failed',
        music: 'Music',
        my_history: 'My History',
        my_notification: 'My Notification',
        my_location: 'My Location',
        mybookmark: 'My Bookmark',
        name: 'Name',
        newton_techno_park: 'Newton Techno Park',
        no: 'No',
        gps_on: 'GPS is active',
        gps_off: 'GPS not active',
        gps_set: 'Location set by GPS',
        no_connection: 'No internet connection!',
        retry: 'RETRY',
        no_item: 'No More Items Available !',
        no_gallery: 'This tenant doesn\'t have photo gallery',
        no_image_available: 'No Image Available',
        no_phone_agent: 'This agent doesn\'t have phone number',
        no_phone_tenant: 'This tenant doesn\'t have phone number',
        no_review_tenant: 'This tenant doesn\'t have review',
        not_empty: 'Can\'t Empty',
        not_equal: 'Password does not match',
        notaris: 'Notary',
        Notaris: 'Notary',
        notification: 'Turn On Notification',
        notification_info: 'Get update, latest information and special offers.',
        notification_push: 'You have a new notification',
        number_not_valid: 'Your code is not valid',
        cbe_fullname: 'Fullname cannot be empty',
        cbe_phone: 'Phone number is not valid',
        cbe_email: 'Invalid email',
        cbe_pass: 'Empty password',
        cbe_pass_min: 'Password minimal 8 characters',
        cbe_check: 'Please check your input',
        cbe_check1: "You're need to agree terms of use!",
        number_null: 'Number is empty',
        open: 'OPEN',
        others: 'Others',
        OTHERS: 'Others',
        Others: 'Others',
        outdoor_sports: 'Outdoor Sports',
        outdoor_sport: 'Outdoor Sports',
        pelase_wait: 'Please wait ...',
        phone: 'Phone',
        photo_gallery: 'Photo Gallery',
        post_rating_success: 'Thank you for giving rating',
        profile: 'Profile',
        type: 'Type',
        property_agents: 'Property Agents',
        Property_Agent: 'Property Agents',
        property_agent: 'Property Agents',
        property_market: 'Property Market',
        property_start: 'This app offers you property search for properties in Lippo Cikarang. Find properties for sale and for rent, including houses, apartments, shops, commercial properties and land.',
        property_finding: 'Finding the property of your dreams.',
        pscode: 'PSCODE',
        pscode_correct: 'PsCode is correct',
        public_services: 'Public Services',
        public_transportation: 'Public Transportation',
        public_transportation_bottom: 'Public Transportation which is entering Beverli area and Ventura, Lippo Cikarang only untill 9.00 WIB',
        no_schedule: 'No Schedule',
        rate_title: 'Tenant Rate',
        rate_this_tenant: 'Rate this tenant',
        tenant: 'Tenants',
        tenant_gallery: 'Gallery Tenant',
        rate_dialog: 'Are you sure want to rate this tenant ?',
        rate_text: 'Rate this place',
        recommended: 'Recommended',
        recreational_sites: 'Recreational Sites',
        registration_success: 'Registration Success',
        registration_failed: 'Registration Failed',
        registration_cancel: 'Registration Cancelled',
        activate_account: 'Please check your email to activate your account!',
        rent: 'Rent',
        rental_cars: 'Rental Cars',
        Rental_Cars: 'Rental Cars',
        resend_code: 'Resend code',
        resend_text: 'Please wait, the code has been sent',
        code_sent: 'Please wait, the activation email has been sent',
        reset: 'Reset',
        reset_password: 'Reset Password',
        reset_password_sub1: 'You are changing the password for',
        resident: 'Resident',
        employment: 'Employment',
        jobs: 'Jobs',
        information: 'Information',
        time_zone: 'Time Zone',
        tree: 'Tree',
        roads: 'Roads',
        vehicle_registration: 'Vehicle registration',
        shop: 'Shop House',
        salon: 'Salon',
        service_apartment: 'Service Apartment',
        area_code: 'Area code(s)',
        save: 'Save',
        save_profile: 'Save Profile',
        school: 'School',
        international_schools: 'International Schools',
        search_hint: 'Search',
        search_title: 'Search',
        send_code: 'Enter the code we sent \nto your email / mobile phone',
        send_email_agent: 'Message',
        send_email_success: 'Send email success',
        send_message: 'Send email success',
        shoes: 'Shoes',
        newCase: 'Are you sure you want to submit this concern?',
        shopping: 'Shopping',
        sign_start: 'Sign in and start exploring',
        sign_start2: 'Sign up and join<br>our smart community',
        signout: 'Sign Out',
        signup: 'Sign Up',
        goMain: 'Go to Main Page',
        signup_lippo: 'Sign up for LippoCikarang.com',
        lippo_cikarang: 'Lippo Cikarang',
        skip: 'Skip',
        skin_care: 'Skin Care',
        sound_info: 'Activate notiﬁcation sound',
        spa___treatment: 'Spa & Treatment',
        spbu: 'SPBU',
        version: 'Version',
        splash_welcome: 'Welcome',
        splash_tagline: 'to 1st Smart City in Eastern Corridor',
        splash_promo: 'Find latest information,<br>promo & pay your billing<br>anytime from anywhere',
        splash_g1_1: 'Discover What You Needed',
        splash_g2_1: 'The best way',
        splash_g2_2: 'to keep in touch',
        splash_g2_3: 'With your community',
        splash_g3_1: 'Start your profile',
        splash_g3_2: 'Find your favorite places',
        splash_g3_3: 'your favorite',
        sport: 'Sport',
        Sport: 'Sport',
        sports: 'Sports',
        start_now: 'Start Now',
        Art___Culture: 'Art & Culture',
        art___culture: 'Art & Culture',
        sub2_forget_password: 'We will send you an email shortly to reset your password',
        sub_forget_password: 'Enter your e-mail address or phone number\nbelow to reset your password',
        reset_success: 'Reset Password success!',
        cannot_send_code: 'Cannot send code',
        email_not_exist: 'Email or phone doesn\'t exist',
        email_exist: 'Phone or email alredy exist!',
        submit: 'Submit',
        submit_forgotpass: 'Submit',
        supermarket: 'Supermarket',
        Talk_to_Us : 'Talk to Us',
        taxi: 'Taxi',
        terms_privacy: 'I agree to the Term of Use',
        terms_privacy_next: 'and Privacy Policy',
        terms_of_use: 'Terms of use',
        title: 'Title',
        title_activity_detail_maps: 'Map',
        title_activity_transportation_public: 'Map',
        tour_travel: 'Tour & Travel',
        Tour___Travel: 'Tour & Travel',
        tour___travel: 'Tour & Travel',
        traditional: 'Traditional',
        Traditional_Food: 'Traditional',
        traditional_food: 'Traditional Food',
        train: 'Train',
        transportation: 'Transportation',
        try_again: 'Back',
        tutor: 'Tutor',
        upgrade_resident: 'Upgrade to resident',
        upload_image_success: 'Upload image success',
        useful_information: 'Useful Information',
        workshop_services: 'Workshop Services',
        Workshop_Service: 'Workshop Services',
        workshop_service: 'Workshop Services',
        world_clock: 'World Clock',
        today: 'Today',
        yes: 'Yes',
        btn_discount_coupon: '<b>Discount</b>Coupon',
        welcome_dialog: 'You are registered \n as',
        okay: 'Okay',
        about_us: 'About Us',
        terms: 'Terms & Conditions',
        privacy: 'Privacy Policy',
        privacy_policy: 'Privacy Policy',
        rate: 'Rate us',
        emergency_call_1: 'Emergency',
        emergency_call_2: 'Call',
        emergency_service_1: 'Emergency',
        emergency_service_2: 'Services',
        ttu_services: 'Services',
        ttu_billing: 'Billing',
        ttu_water: 'Water',
        ttu_environment: 'Environment',
        reach_us: 'Reach us at',
        sort: 'Sort',
        sort_distance: 'Distance',
        sort_name: 'Name',
        population: 'Population',
        sort_popularity: 'Popularity',
        category_all: 'All',
        accessories___toys: 'Accessories & Toys',
        accessories_toys: 'Accessories & Toys',
        // resend email
        email_empty: 'Email is empty',
        account_isactive: 'Your account has been activated',
        account_issend: 'Activation email already sent',
        account_limit: 'Resend activation email already exceeding limit',
        title_email: 'Resend Email Activation',
        subtitle_email: 'Type your email below',
        footer_email: 'We will resend the activation email to your shortly. Please check your mail inbox and spam.',
        no_account: 'Your email is not registered',
        // end
        //child property
        house_property: 'House',
        apartment_property: 'Apartment',
        kavling_property: 'Kavling',
        commercial_property: 'Commercial',
        industry_property: 'Industry',
        house: 'House',
        unit: 'Units',
        apartment: 'Apartment',
        kavling: 'Kavling',
        cinema: 'Cinema',
        commercial: 'Commercial',
        industry: 'Industry',
        e_success: 'Add complaint success',
        e_failed: 'Add complaint failed',
        //Industry: 'Industry',

        //Sort Property
        sort_harga: 'Price ( Low - High )',
        sort_harga_high: 'Price ( High - Low )',
        sort_new: 'New',
        sort_popular: 'Popular (High - Low )',
        sort_caption: 'Caption',
        leght_password: 'Please enter a new password \n Password must be at least 8 character in length.',
        avoid_pasword: 'Avoid password that are easy \n to guess or used with other website.',
        verify: 'Verify',
        //forum
        post_a_comment: 'Post a Comment',
        send_a_comment: 'Comment',
        comment_here: 'Comment here...',
        views: 'views',
        new_topic: 'New Topic',
        new_comment: '+ New Comment',
        discussion_title: 'Discussion Title',
        upload: 'Upload',
        post: 'Post',
        edit_topic: 'edit',
        edit_post: 'Edit Post',
        delete_discussion: 'Delete Discussion',
        comment: 'comments',
        Comment: 'Comment',
        Comments: 'Comments',
        latest_forum: 'Latest Forum',
        oldest_forum: 'Oldest Forum',
        forum_comment: 'Forum Comment',
        comment_success: 'Success!',
        comment_failed: 'Failed!',
        date: 'Date',
        desc_bil: 'Description',
        amount: 'Amount',
        edit_comment: 'Edit Comment',
        delete_comment: 'Delete Comment',
        stared_a_thread: 'START A THREAD',
        acces_billing: 'Now access, download\n and pay your billing is easy!',
        amount_to_be_paid: 'Amount to be paid',
        total_amount: 'Total Amount',
        description: 'Description',
        cant_acces_billing: 'I can\'t access my billing',
        payment: 'Payment',
        confirm_payment: 'Are you sure to pay your<br><b>Resident eBilling</b><br>on your mobile apps?',
        cancel_ovo: 'Are you sure to cancel pay your<br><b>Resident eBilling</b><br>on your mobile apps?',
        hint_email_phone: 'Email or mobile phone',
        hint_email: 'Email',
        let_acces_billing: 'Let me access my billing',
        pay_now: 'Pay Now',
        select_payment: 'Please select your payment method:',
        total_bill: 'Total bill',
        unit_no: 'Unit no',
        client_code: 'Client Code',
        client_name: 'Client Name',
        read_condition: 'I have read and agree to the Term and Condition',
        must_check_term: 'You Must Check Terms of Service',
        check_term: 'You Must Check Terms of Service',
        category: 'Category',
        category_property: 'Property',
        property: 'Property',
        category_events: 'Events',
        category_competition: 'Competition',
        competition: 'Competition',
        category_city: 'City',
        city: 'City',
        category_discount: 'Discount',
        general: 'General',
        Umum: 'General',
        download2: 'Download',
        no_file_download: 'There are no file download',
        no_category: 'There are no category',
        no_property: 'There are no property',
        there_no_gallery: 'There are no gallery',
        success_favorite: 'Succesfully Added to Favorites',
        failed_favorite: 'Failed Added to Favorites',
        no_user: 'There are no user',
        user_cancelled: 'Login cancelled.',
        no_news: 'There are no news',
        news: 'News',
        no_data: 'There are no data',
        no_data_my_voucher: 'There is no data to display',
        are_you_download: 'Are you sure you want to download this file?',
        downloaded: 'Downloaded',
        discount_information: 'Discount Information',
        no_application_found: 'No Application Found',
        download_from_android_market: 'Download one from Android Market?',
        yes_please: 'Yes, Please',
        no_thanks: 'No, Thanks',
        download_dialog1: 'Do you want to download',
        download_dialog2: 'on your mobile apps?',
        downloading: 'Downloading',
        downloading_complete: 'Downloading complete',
        file_not_found: 'File not found',
        file_downloaded: 'File downloaded',
        download_error: 'Download error',
        select: 'select',
        set_to_main: 'set to main',
        must_choice_2: 'Choose 2 option',
        Calculator: 'Calculator',
        succes_set_to_main: 'Success to set in main page',
        exchange_rate: 'Exchange Rates',
        korean: 'Korean',
        Korean_Food: 'Korean Food',
        korean_food: 'Korean Food',
        dialog_title_gps: '<b>Allow "LippoCikarang.com"\n to access your location while \n you use the app ?</b>',
        dialog_content_gps: 'Enable location service to explore spots \n near by',
        allow: 'Allow',
        dont_allow: 'Don\'t Allow',
        male: 'Male',
        female: 'Female',
        fashion: 'Fashion',
        Fashion_: 'Fashion',
        fashion_: 'Fashion',
        Batik: 'Batik',
        batik: 'Batik',
        post_topic_success: 'Post topic success',
        delete_topic_success: 'Delete topic success',
        delete_topic_failed: 'Delete topic failed',
        edit_topic_success: 'Edit topic success',
        post_topic_empty: 'Discussion title and description can\'t be empty',
        delete_image_success: 'Delete image success',
        post_comment_success: 'Post comment success',
        delete_comment_success: 'Delete comment success',
        edit_comment_success: 'Edit comment success',
        hint_comment: 'Comment',
        post_comment_empty: 'Comment can\'t be empty',
        post_bookmark_property_success: 'Added to favorites',
        delete_bookmark_property_success: 'Remove from favorites',
        remove_favorite_success: 'Succesfully remove form favorites',
        remove_favorite_failed: 'Failed remove form favorites',
        hint_fullname: 'Fullname',
        ovo: 'OVO',
        connect: 'Connect with Us',
        affiliates: 'Affiliates',
        featured: 'Featured',
        bookmark: 'Bookmarks',
        load_from_library: 'Load from Library',
        use_camera: 'Use Camera',
        select_image_source: 'Select Image Source',
        failed_get_data: 'Failed Get Data',
        oke: 'Okay',
        code_name: 'Code Name',
        code_no: 'Code No',
        //
        entertaiment: 'Entertainment',
        entertainment: 'Entertainment',
        transportation: 'Transportation',
        dining: 'Dining',
        westren_food: 'Western',
        WESTREN_FOOD: 'Western Food', 
        western_food: 'Western Food', 
        shopping: 'Shopping',
        gallery: 'Gallery',
        city_gallery: 'City Gallery',
        load_from_library: 'Load From Library',
        of: ' of ',
        Gas_Station: 'Gas Station',
        gas_station: 'Gas Station',
        track: 'Track Your Complaint',
        add_new: '+ Add New',
        ds1: 'DS1',
        ds2: 'DS2',
        ds3: 'DS3',
        ds4: 'DS4',
        ds5: 'DS5',
        ds6: 'DS6',
        version: 'Version',
        version_uptodate: 'The app is not up to date, Please download latest version!',
        //button
        BUTTON_TEXT_EN: 'English',
        BUTTON_TEXT_DE: 'Indonesia',
        upgrade_resident: 'Upgrade to Resident',
        //
        contact: 'Contact',
        total: 'Total',
        payment_amount: 'Payment Amount',
        unit_code: 'Unit Code',
        recommended: 'Recommended',
        places: 'Places',
        PLACES: 'PLACES',
        photo: 'Photo',
        hint_card_number: 'Card Number',
        choose_payment: 'Select payment method',
        bank_transfer: 'ATM/Bank Transfer',
        admin: 'Admin',
        expiry_date: 'Expiry Date',
        pay: 'Pay',
        virtual_account_number: 'Virtual Account Number',
        continue: 'Continue',
        finish: 'Finish', 
        please_ss_this_screen: 'Please screenshoot this page!',
        read_term_condition: 'Read and agree to the Term and Condition',
        billing_not_exist: 'not exist, Coming Soon',
        see_instruction: 'SEE INSTRUCTION',
        guide_file_not_exist: "Guide File is not exist !!!",
        search_here: 'Search Here',
        status: 'Status',
        city_info: 'City Information',
        bus_schedule: 'Bus Schedule',
        view_all: 'View All',
        send: 'Send',
        menu: 'Menu',
        bill_key: 'Bill Key',
        biller_code: 'Biller Code',
        settings: 'Settings',
        retry: 'Retry',
        no_internet_message: 'You\'re not connected to the internet. Please connect and retry',
        payment_via_ovo : 'Online Payment',
        see_all_promos : 'See All Promos',
        popular_dinings: 'Popular Dinings',
        popular_entertainments: 'Popular Entertainments',
        popular_accomodations: 'Popular Accommodations',
        popular_shopping: 'Popular Shopping',
        add_image: 'Add Image',
        update_comment: 'Update Comment',
        customer_service: 'Customer Service',
        ongoing_promos: 'Ongoing Promos',
        lc_recommendation: 'Lippo Cikarang Recommendation',
        some_popular_dinings: 'Some popular dinings',
        some_popular_entertainments: 'Some popular entertainments',
        some_popular_accommodations: 'Some popular accommodations',
        some_popular_shopping: 'Some popular shopping',
        phone_validation: 'Phone minimal 8 character and maximal 14 character',
        max_image: 'Can\'t add image, max 2 image',
        add_complaint: 'Add Complaint',
        concern: 'Concern',
        desc_concern: 'Let us know more...',
        attachment: 'Attachment',
        submit_complaint: 'Submit',
        capture_photo: 'Capture Photo',
        item_not_found: 'Item not found',
        industrial_info: 'Industrial Info',
        popular_categories: 'Popular Categories',
        all_categories: 'All Categories',
        ticket_history: 'Ticket History',  
        side_menu_welcome: 'Welcome',
        error_upload_image: 'There was an error uploading the file, please try again!',
        my_point: "My Points",
        new_voucher: "New Voucher",
        last_chance: "Last Chance to Redeem",        
        other_voucher: "Other Voucher",        
        filter: 'Filter',        
        history_point: 'History Points',
        history_voucher: 'History Voucher',
        see_details : 'See Details',
        get_points: 'Get Points',
        explore_voucher: 'Explore Vouchers',
        my_voucher: 'My Vouchers',
        browse_voucher: 'Browse Voucher',
        redirect_billing: 'Redirect to Billing Payment',
        customize_vouchers: 'Costumize Vouchers',
        search_voucher: 'Search for voucher here...',
        redeem: 'Redeem',
        use_this_voucher: 'Use This Voucher',
        load_more: 'Load More',
        overview: 'Overview',
        how_to_use: 'How to use',
        t_and_c: 'T&C',
        redeem_now: 'Redeem Now',
        sufficient_point: 'You don\'t have sufficient point to redeem this voucher.',
        points: 'Points',
        valid_until: 'Valid Until',
        outstanding: 'Outstanding',
        outstandings: 'Outstandings',
        learn_more: 'Learn More',
        outstanding_text: 'Your point may be decreased because of this transaction is need point from your point, so your point will be reduced.',
        you_have: 'You have',
        have_outstanding: 'You have outstanding',
        available: 'Available',
        from: 'from',
        save_ovoid: 'Save your OVO account phone number and connect account for the next transaction.',
        phonenumber_cant_empty: 'Please fill your OVO account phone number',
        your_ovoid: 'OVO Account Phone Number',
        there_has_been_an_error_our_system: 'There has been an error in our system, <br> please try again later',    
        ovo_info1: 'Make sure you are logged in to the OVO application',
        ovo_info2: 'Payments with the OVO application will expire in 30 seconds after you click "Pay using OVO"',
        ovo_info3: 'Open OVO notifications to make payments',
        ovo_info4: 'Choose a payment method with "OVO Cash" or "OVO Point" or a combination of both, then click "Pay"',
        info_payment_ovo: 'Payment Info with the OVO application',
        payment_ovo: 'Payment OVO',
        transaction_failed: 'Transaction Failed',
        others_desc_billing: '(Bank Transfer, Credit Card and Go-Pay)',
        transaction_cancelled: 'Transaction Cancelled',
        worth: 'Worth',
        redeem_for_various: 'Redeem for various vouchers from our merchants',
        lowest_point: 'Lowest Points',
        highest_point: 'Highest Points',
        availability: 'Availability',
        distance: 'Distance',
        voucher_status : 'Vouchers Status', 
        quick_filter : 'Quick Filter',       
        expiring : 'Expiring',
        expired : 'Expired',
        voucher_with_my_point: 'Eligible vouchers with ',
        voucher_expiring: 'Vouchers Expiring',
        scan_qrcode: 'Scan QR Code',
        scan_qrcode_desc: 'Get points by scanning QR code on the event',
        scan_now: 'Scan Now',        
        learn_more_get_point: 'Learn More Get Point',
        qrcode_scanned: 'QR Code Scanned',
        qrcode_limit: 'QR code is not available',
        qrcode_scanned_desc: 'Share this event and get additional points',
        share_now: 'Share Now',
        how_do_earn_points: 'How do I earn Points?',
        read_more: 'Read More',        
        msg_have_checkin: 'Yay! I Have check in at event',
        go_back: 'Go Back',
        qr_invalid: 'QR Code Invalid',
        point: 'Point',
        available_points: 'Available Points',
        pts: 'pts',
        cancel_share_event: 'Cancel share event',
        customize_voucher: 'Customize Vouchers',
        customize_voucher_desc: 'View and set your voucher preferences.',
        available_until: 'Available Until',
        use: 'Use',
        used: 'Used',
        used_date: 'Used Date',
        expiring_this_month: 'Expiring this month',        
        redeem_voucher: 'Redeem Voucher',
        use_point_to_redeem_desc : 'Use your points to redeem this voucher',
        Ooopss : 'Ooopss......',
        apply_clp: 'Apply',
        outstanding_not_found: 'Your outstanding data isn\'t found',
        please_input_merchant: 'Please input merchant code',
        please_input_ovo : 'Please input OVO id or OVO Number',
        how_get_merchant: 'How do I get merchant code',
        see_my_voucher : 'See My Vouchers',
        transaction_id: 'Transaction ID',
        submit_by: 'Submit By',
        date_time: 'Date and Time',
        redeemed: 'Redeemed',
        submit_voucher: 'Submit',
        title_deleted: 'Automatically Delete',
        title_deleted_desc: 'Delete expired by system, 7 (seven) days after the voucher has been expired.',
        title_reminder: 'Reminder Notif Expiring',
        title_reminder_desc: 'Setting up notification on expiring voucher. Turn on notification to get information when voucher(s) is expiring.',
        payment_succeed: 'Payment Succeed',
        payment_status: 'Payment Status',
        payment_has_been_canceled: 'Pembayaran dibatalkan',
        km_desc_tenant : 'Km from your location',
        second: 'second',
        minutes: 'minutes',
        hours: 'hours',
        days: 'days',
        ago: 'ago',
        will_be_expiring_at: 'this voucher will be expiring at',
        billing_info: 'Proof of payment will be sent separately via email. If within 1 hour the customer has not received proof of payment, please contact CS.',
        billing_statement: 'Billing Statement',
        payment_history: 'Payment History',
        time: 'time',
        user_details: 'User Details',
        payment_details: 'Payment Details',
        payment_method: 'Payment Method',
        total_payment: 'Total Payment',
        va_number: 'Virtual Account Number',
        credit_card: 'Card Number',
        unit_details: 'Unit Details',
        download_pdf: 'Download PDF',
        download_payment_history: 'Download Payment History',
        from_input: 'From',
        to_input: 'To',
        download_text: 'Download',
        filter: 'Filter',
        i_want_to_pay : 'I want to pay',
        other_bill: 'Other Bill',
        unpaid: 'Unpaid',
        paid: 'Paid',
        apply: 'Apply',
        with_ovo: 'With OVO',
        with_midtrans: 'With Midtrans',
        payment_unit: 'Payment Unit',
        my_unit: 'My Unit',
        number_of_unit: 'Number Of Unit',
        dialog_pay_other_bill: 'Are you sure want to pay Other Bill ?',
        confirmation: 'Confirmation',
        units : 'Units',
        needhelp_our: 'Our Customer Service team is ready to assist you if you have any questions or problems.',
        needhelp_for: 'For immediate response, please contact our Customer Services team through Customer Service Center',
        needhelp_csc: 'Customer Service Center',
        needhelp_reach: 'Reach out to our team for further information',
        hours_24: '24 Hour',
        telephone: 'Telephone',
        detail_history: "Detail History",
        billing_has_been_paid: "You don't have outstanding billing",
        bukti_pembayaran: "Your billing statement will be sent separately to your email. If you have not received your billing statement in an hour, please contact CS.",
        see_payment_detail: "See Payment Detail",
        no_payment_method: 'This payment method is not available',
        date_and_time: "Date and Time",
        transaction_id: "Transaction ID",
        have_agree: "I have read and agree to the ",
        terms_and_condition: "Terms & Conditions",
        pay_bills: "Pay Bills",
        type_search_point: "Type at least 3 character",
        result_for: "Result for",
        no_result_found_for: "No result found for",
        make_sure_your_words: 'Oopsss.... Please make sure your words are spelled correctly, or please use different keywords',
        barcode_scanner_info: 'Place a barcode inside the scan area',
    })
        .translations('ina', {
            apilink: api_link,
            apilinkpayment: api_link_payment,
            apilinkcomplaint: api_link_complaint,
            apilinkliveinweb: api_link_livein_web,
            apilinkmidtrans: api_link_midtrans,
            siteidapps: site_id_apps,
            link_apps_store: link_apps_store,
            // resend email
            email_empty: 'Email kosong',
            account_isactive: 'Akun Anda telah aktif',
            account_issend: 'Email aktivasi telah dikirimkan',
            account_limit: 'Kirim ulang email aktivasi melebihi batas',
            title_email: 'Kirim Ulang Email Aktivasi',
            subtitle_email: 'Ketik email Anda dibawah ini',
            footer_email: 'Kami akan segera mengirimkan email aktivasi . Mohon cek kotak masuk dan spam email Anda.',
            no_account: 'Email Anda belum terdaftar',
            // end
            ds1: 'DS1',
            ds2: 'DS2',
            ds3: 'DS3',
            ds4: 'DS4',
            ds5: 'DS5',
            ds6: 'DS6',
            app_name: 'LippoCikarang.com',
            app__name: 'Lippo Cikarang',
            // Menuuu
            home_nav: 'Beranda',
            categories_nav: 'Kategori',
            my_complaint_nav: 'Keluhan',
            my_billing_nav: 'Tagihan',
            forum_nav: 'Forum',
            cctv_nav: 'CCTV',
            about_us_nav: 'Tentang Kami',
            call_center_nav: 'Pusat Panggilan',
            settings_nav: 'Pengaturan',
            sign_out_nav: 'Keluar',
            // End of menu
            sound: 'Suara',
            desc_empty: 'Deskripsi harus diisi!',
            unit_empty: 'Unit harus diisi!',
            concern_empty: 'Keluhan harus diisi!',
            limit_image: 'Maaf, maksimal ukuran gambar 15MB',
            eComplaint: 'Apakah Anda memiliki keluhan?',
            eComplaint2: 'Sampaikan pada kami dan kami akan menuntaskannya.',
            take_pic: 'Ambil foto',
            import_gal: 'Pilih gambar dari album',
            choose_img: 'Pilih Gambar',
            btn_eC: 'Ya, lanjutkan.',
            installed: 'tersedia',
            not_installed: 'belum tersedia',
            confirm_install_sos: 'Apakah Anda ingin mengunduh aplikasi Ambulance Siloam 1health ?',
            confirm_install_ovo: 'Apakah Anda ingin mengunduh aplikasi Ovo ?',
            loading: 'Memuat',
            loginmessage: 'Mencoba masuk',
            logoutmessage: 'Mencoba keluar',
            soon: 'Segera Tersedia',
            Minimum_8_character: 'Kata sandi minimal 8 karakter',
            about: 'Tentang',
            not_register: 'Akun anda belum terdaftar',
            accomodation: 'Akomodasi',
            action_bookmark: 'Tandai',
            action_call: 'Hubungi',
            action_map: 'Peta',
            action_review: 'Ulasan',
            add_your_photo: 'Tambahkan Foto Anda',
            address: 'Alamat',
            apartment: 'Apartemen',
            Apartment: 'Apartemen',
            kavling: 'Kavling',
            with: 'dengan',
            orange_county: 'Orange County',
            are_resident: 'Apakah Anda seorang warga ? Daftarkan alamat email di database kami untuk menikmati ﬁtur khusus',
            are_alreadyaccount: 'Telah memiliki akun ? ',
            resend_email: 'Kirim Aktivasi Email',
            art: 'Seni & Budaya',
            atm_gallery: 'Galeri ATM',
            ATM_Gallery: 'Galeri ATM',
            automotive: 'Otomotif',
            Automotive: 'Otomotif',
            bakery: 'Roti & Pencuci Mulut',
            BAKERY___DESERT: 'Roti & Pencuci Mulut',
            bakery___dessert: 'Roti & Pencuci Mulut',
            bank: 'Bank',
            Bank: 'Bank',
            bar_cafe_club: 'Bar/Cafe/Club',
            CAFE___LOUNGE___BAR: 'Bar/Cafe/Club',
            cafe___lounge___bar: 'Bar/Cafe/Club',
            cafe_lounge_bar: 'Cafe & Lounge Bar',
            Fast_Food: 'Cepat Saji',
            fast_food: 'Cepat Saji',
            eyewear: 'Kacamata',
            beauty: 'Kecantikan',
            Beauty: 'Kecantikan',
            clothes: 'Pakaian',
            book_stationety: 'Buku & Alat Tulis',
            Book___Stationery: 'Buku & Alat Tulis',
            book___stationery: 'Buku & Alat Tulis',
            bookmarked: 'Tertandai',
            all_bookmarked: 'Sudah Tertandai',
            bookmark: 'Tandai',
            btn_lets_go: 'Mulai',
            bus: 'Bis',
            buy: 'Beli',
            captcha_true: 'Email sudah terkirim',
            captcha_false: 'Captcha Salah',
            new_forum: 'Sukses mengirimkan post! Mohon tunggu persetujuan admin sebelum post Anda dipublikasikan.',
            Batik: 'Batik',
            batik: 'Batik',
            send_email: 'Kirim Pesan',
            call_agent: 'Hubungi Agen',
            call: 'Pusat',
            center: 'Panggilan',
            call_center_html: '<b>Pusat</b>Panggilan',
            cancel: 'Batal',
            cctv: 'CCTV',
            chinese: 'China',
            chinese_food: 'Makanan China',
            close: 'TUTUP',
            close_complaint: 'Tutup',
            clothes: 'Pakaian',
            condominiums: 'Kondominium',
            Condominiums: 'Kondominium',
            cosmetic: 'Kosmetik',
            create_account: 'Buat Akun Baru',
            create_ur_account: 'Buat Akun Anda',
            daily: 'SENIN - JUMAT',
            weekly: 'SABTU - MINGGU',
            expand: 'Perluas',
            session: 'SESI',
            delete: 'Hapus',
            deparment_store: 'Pusat Perbelanjaan',
            department_store: 'Pusat Perbelanjaan',
            Department_Store: 'Pusat Perbelanjaan',
            dialog_signout: 'Apakah anda yakin \n ingin keluar dari akun ini?',
            dialog_success_upgrade: 'Email Anda Telah Terdaftar, <br/> <b>Selamat</b> <br/>Sekarang anda sudah<br/>menjadi warga',
            dialog_fail_upgrade: 'Maaf, email tidak dapat terdaftar, <br/> Silahkan menghubungi Customer Service <br/>untuk mendaftarkan email anda',
            dialog_delete: 'Apakah anda yakin \n ingin menghapus?',
            blm_login: 'Maaf, Anda belum login. Mohon login dari Profil untuk mengakses menu ini.',
            blm_rate: 'Maaf, Anda belum login. Mohon login dari Profil untuk memberikan rating.',
            blm_emailAgen: 'Maaf Anda belum login. Mohon login dari Profil untuk mengirimkan email pada agen.',
            intro1: 'Daftarkan diri untuk pengalaman lebih <br> <p style="font-size:8px;font-style:italic;margin:0;">fitur khusus untuk residents!</p>',
            intro2: 'Nikmati Diskon Khusus, <br> Daftar Sekarang!',
            intro3: 'Temukan <br> Lebih Banyak <br>',
            next: 'Lanjut',
            previous: 'Kembali',
            thanks: 'Terimakasih',
            dining: 'Kuliner',
            westren_food: 'Makanan Barat',
            WESTREN_FOOD: 'Makanan Barat',
            western_food: 'Makanan Barat',
            coupon: 'Diskon',
            discount: 'Kupon',
            discount_coupon: 'Diskon Kupon',
            Kupon: 'Kupon',
            download: 'Unduhan',
            download_more: 'Unduh',
            ebilling: 'eBilling',
            e_billing: 'e-Billing',
            edit: 'Ubah',
            edit_profile: 'Ubah Profile',
            education: 'Edukasi',
            Education: 'Edukasi',
            electronic: 'Elektronik',
            Electronic_: 'Elektronik',
            electronic_: 'Elektronik',
            email_agent: 'Email Agen',
            entertaiment: 'Hiburan',
            entertainment: 'Hiburan',
            events: 'Acara',
            Acara: 'Acara',
            eyewear: 'Kacamata',
            fastfood: 'Cepat Saji',
            fashion: 'Fashion',
            Fashion_: 'Fashion',
            fashion_: 'Fashion',
            forgot_password: 'Lupa Sandi ?',
            forgot_password_placeholder: 'Email atau nomor telepon',
            forum: 'Forum',
            gallery: 'Galeri',
            city_gallery: 'Galeri Kota',
            pro_gallery: 'Galeri Properti',
            gallery_confirm: 'Yakin ingin menghapus galeri forum ?',
            games: 'Permainan',
            gender: 'Jenis Kelamin',
            get_started: 'Mulai',
            golfing: 'Golf',
            gym: 'Kebugaran',
            health: 'Kesehatan',
            Kesehatan: 'Kesehatan',
            health_care: 'Kesehatan',
            Health_Care: 'Kesehatan',
            hello: 'Halo',
            help: 'Bantuan',
            needhelp: 'Butuh Bantuan',
            help_feedback: 'Bantuan & umpan balik',
            helpful_number: 'Nomor Bantuan',
            number: 'Tanggal Dibuat',
            what_c: 'Apakah keluhan anda?',
            desc_c: 'Keluhan Anda ...',
            CC: 'Klien Kode',
            hint_confirm_password: 'Konfirmasi Kata Sandi',
            hint_email: 'Email',
            hint_pass: 'Kata Sandi',
            hint_password: 'Kata Sandi',
            hint_phone: 'No Handphone',
            hint_topic_desc: 'Isi Diskusi',
            hint_topic_title: 'Judul Diskusi',
            hist_cont_1: 'Jelajahi Timeline Anda',
            hist_cont_2: 'Riwayat Lokasi membantu Anda mendapatkan informasi yang berguna - secara otomatis akan meningkatkan hasil pencarian.',
            hist_cont_3: 'Temukan kembali tempat yang sudah Anda temukan dan sudah kunjungi.',
            hist_cont_4: 'Hanya Anda yang dapat melihat Timeline Anda',
            home_improvement: 'Perbaikan Rumah',
            Home_Improvement: 'Perbaikan Rumah',
            hi_home: 'Hai,',
            hospital: 'Rumah Sakit',
            hotel: 'Hotel',
            hours_today: 'Jam Operasional',
            what_new: 'Berita Baru',
            indoor_sports: 'Dalam Ruangan',
            industry: 'Industri',
            date: 'Tanggal',
            desc_bil: 'Deskripsi',
            amount: 'Total',
            Industry: 'Industri',
            e_success: 'Tambahkan keluhan sukses',
            e_failed: 'Gagal menambahkan keluhan',
            industries: 'Industri',
            unit: ' unit',
            must_check_term: 'Tandai syarat dan ketentuan',
            check_term: 'Tandai syarat dan ketentuan',
            insurance: 'Asuransi',
            Insurance: 'Asuransi',
            invitation_msg: 'Berbagi dengan teman anda',
            invite_friend: 'Undang Teman',
            inviteFriend: 'Berbagi dengan teman anda',
            duration_jam: 'jam',
            duration_mnt: 'menit',
            japanese: 'Jepang',
            japanese_food: 'Makanan Jepang',
            Japanese_Food: 'Makanan Jepang',
            jewelry: 'Perhiasan',
            join_us: 'Bergabung dengan menggunakan akun \n media sosial anda',
            karaoke: 'Karaoke',
            leisure: 'Hiburan',
            Leisure: 'Hiburan',
            login: 'Masuk',
            login_with: 'Masuk dengan',
            login_failed: 'Gagal!',
            facebook_login_failed: 'Gagal login Facebook',
            more_unit: 'Pembayaran dilakukan dari aplikasi seluler akan mencakup pembayaran dari SEMUA UNIT. Silakan kunjungi Layanan Pelanggan untuk pertanyaan lebih lanjut.',
            failed: 'Gagal!',
            failed_get_data: 'Gagal dapatkan data',
            oke: 'Oke',
            must_choose_1: 'Harus memilih 1 tipe pembayaran',
            check_email: 'Periksa kembali email Anda atau hubungi Customer Service',
            check_email_login: 'Periksa kembali email untuk aktivasi',
            email2: 'Email sudah terdaftar',
            email_exist2: 'Maaf, email sudah ada sebelumnya',
            phone_exist2: 'Maaf, nomor telepon sudah ada sebelumnya',
            cannot_put_email: 'Tidak dapat menempatkan email untuk verifikasi',
            wrong_email: 'Email atau Nomor Telfon tidak benar',
            enter_credential: 'Silakan masukkan kredensial!',
            main: 'Utama',
            map: 'Peta',
            tenant_map: 'Peta Penyewa',
            mark: 'Tandai sudah dibaca',
            mart: 'Mart',
            more: 'Lainnya',
            exchange: 'Nilai Tukar',
            currency: 'Mata Uang',
            language: 'Bahasa',
            success_language: 'Anda memilih Bahasa ',
            minimarket: 'Minimarket',
            Minimarket: 'Mart',
            msg_deleted: 'Terhapus',
            msg_marked: 'Tertandai',
            msg_update: 'Update',
            msg_update_failed: 'Update Gagal',
            msg_update_success: 'Update Berhasil',            
            msg_upgrade_success: 'Update Residen Berhasil',
            msg_delete_success: 'Berhasil terhapus',
            msg_delete_failed: 'Gagal menghapus',
            music: 'Musik',
            my_history: 'Riwayat',
            my_notification: 'Pemberitahuan',
            my_location: 'Lokasi',
            mybookmark: 'Penanda',
            name: 'Nama',
            newton_techno_park: 'Newton Techno Park',
            no: 'Tidak',
            gps_on: 'GPS aktif',
            gps_off: 'GPS tidak aktif',
            gps_set: 'GPS mendapatkan lokasi',
            no_connection: 'Tidak ada koneksi Internet !',
            retry: 'ULANG',
            no_item: 'Tidak ada item tersedia',
            no_gallery: 'Tenant ini tidak mempunyai galeri foto',
            no_image_available: 'Gambar tidak tersedia',
            no_phone_agent: 'Agen ini tidak mempunyai nomor telepon',
            no_phone_tenant: 'Tenant ini tidak mempunyai nomor telepon',
            no_review_tenant: 'Tenant ini tidak mempunyai ulasan',
            not_empty: 'Tidak boleh kosong',
            not_equal: 'Kata sandi tidak cocok',
            notaris: 'Notaris',
            Notaris: 'Notaris',
            notification: 'Nyalakan notifikasi',
            notification_info: 'Dapatkan informasi terbaru',
            notification_push: 'Kamu mempunyai pemberitahuan baru',
            number_not_valid: 'Kode anda tidak valid',
            cbe_fullname: 'Nama tidak boleh kosong',
            cbe_phone: 'Nomor ponsel tidak valid',
            cbe_email: 'Email tidak valid',
            cbe_pass: 'Kata sandi kosong',
            cbe_pass_min: 'Kata sandi minimal 8 karakter',
            cbe_check: 'Tolong cek inputan',
            cbe_check1: "Anda harus menyetujui Syarat dan Ketentuan yang berlaku!",
            number_null: 'Nomor anda kosong',
            open: 'BUKA',
            others: 'Lainnya',
            OTHERS: 'Lainnya',
            Others: 'Lainnya',
            outdoor_sports: 'Luar Ruangan',
            outdoor_sport: 'Olahraga di Luar Ruangan',
            pelase_wait: 'Silakan tunggu...',
            phone: 'Telpon',
            photo_gallery: 'Galeri',
            post_rating_success: 'Terimakasih telah memberi rating',
            profile: 'Profil',
            type: 'Tipe',
            property_agents: 'Agen Properti',
            Property_Agent: 'Agen Properti',
            property_agent: 'Agen Properti',
            property_market: 'Properti Market',
            property_start: 'Aplikasi ini menawarkan pencarian properti di Lippo Cikarang. Temukan properti yang dijual, disewa, termasuk rumah, apartemen, ruko, komersial dan tanah.',
            property_finding: 'Temukan properti impian Anda.',
            pscode: 'PSCODE',
            pscode_correct: 'PsCode Benar',
            public_services: 'Pelayanan Publik',
            public_transportation: 'Transportasi Umum',
            public_transportation_bottom: 'Transportasi umum yang memasuki Beverly dan Ventura , Lippo Cikarang hanya sampai 09.00 WIB',
            no_schedule: 'Tidak ada jadwal',
            rate_title: 'Rating Penyewa',
            rate_this_tenant: 'Nilai tempat ini',
            tenant: 'Penyewa',
            tenant_gallery: 'Galeri Tenant',
            rate_dialog: 'Apakah Anda yakin ingin menilai penyewa ini ?',
            rate_text: 'Nilai tempat ini',
            recommended: 'Rekomendasi',
            recreational_sites: 'Rekreasi',
            registration_success: 'Pendaftaran Berhasil',
            registration_failed: 'Pendaftaran Gagal',
            registration_cancel: 'Pendaftaran Batal',
            activate_account: 'Silahkan cek email Anda untuk mengaktifkan akun Anda!',
            rent: 'Sewa',
            rental_cars: 'Rental Mobil',
            Rental_Cars: 'Rental Mobil',
            resend_code: 'Kirim Ulang Kode',
            resend_text: 'Silakan tunggu, kode sudah dikirimkan ulang',
            code_sent: 'Silakan tunggu, email aktivasi telah dikirimkan',
            reset: 'Reset',
            reset_password: 'Atur Ulang Kata Sandi',
            reset_password_sub1: 'Anda mengubah kata sandi untuk',
            resident: 'Resident',
            employment: 'Karyawan',
            jobs: 'Pekerjaan',
            house: 'Rumah',
            unit: 'Unit',
            information: 'Informasi',
            tree: 'Pohon',
            roads: 'Jalan',
            time_zone: 'Zona Waktu',
            area_code: 'Kode Area',
            vehicle_registration: 'Daftar Kendaraan',
            shop: 'Toko',
            salon: 'Salon',
            service_apartment: 'Layanan Apartemen',
            save: 'Simpan',
            save_profile: 'Simpan Profil',
            school: 'Sekolah',
            international_schools: 'Sekolah Internasional',
            search_hint: 'Cari',
            search_title: 'Cari',
            send_code: 'Masukkan kode yang kami kirimkan email / telepon seluler Anda',
            send_email_agent: 'Pesan',
            send_email_success: 'Email berhasil dikirim',
            send_message: 'Kirim Pesan',
            shoes: 'Sepatu',
            newCase: 'Apakah anda yakin akan mengirim masalah ini?',
            shopping: 'Belanja',
            sign_start: 'Daftar dan mulai menjelajah',
            sign_start2: 'Daftar dan mulai menjelajah',
            signout: 'Keluar',
            signup: 'Daftar',
            goMain: 'Kembali ke Halaman Utama',
            signup_lippo: 'Daftar ke LippoCikarang.com',
            lippo_cikarang: 'Lippo Cikarang',
            skip: 'Lewati',
            skin_care: 'Skin Care',
            sound_info: 'Nyalakan suara',
            spbu: 'SPBU',
            version: 'Versi',
            version_uptodate: 'Versi aplikasi telah kadaluarsa, Harap unduh aplikasi terbaru',
            splash_welcome: 'Selamat Datang',
            splash_tagline: 'di Kota Pintar Pertama Koridor Timur',
            splash_promo: 'Temukan informasi terbaru,<br>promo & bayar tagihan Anda<br>kapan saja dari mana saja',
            splash_g1_1: 'Temukan apa yang Anda perlukan',
            splash_g2_1: 'Cara terbaik',
            splash_g2_2: 'untuk berhubungan',
            splash_g2_3: 'dengan lingkungan anda',
            splash_g3_1: 'Mulai Profil Anda',
            splash_g3_2: 'Temukan tempat',
            splash_g3_3: 'favorit anda',
            sport: 'Olahraga',
            Sport: 'Olahraga',
            sports: 'Olahraga',
            start_now: 'Mulai Sekarang',
            Art___Culture: 'Seni & Budaya',
            art___culture: 'Seni & Budaya',
            sub2_forget_password: 'Kami akan mengirim email Anda segera untuk mereset Kata sandi Anda',
            sub_forget_password: 'Masukkan alamat email atau nomor telepon bawah untuk mereset sandi Anda',
            reset_success: 'Berhasil mereset Kata sandi',
            cannot_send_code: 'Tidak bisa mengirim kode',
            email_not_exist: 'Email atau nomor telepon tidak ada',
            email_exist: 'Nomor atau email telah ada!',
            submit: 'Masuk',            
            submit_forgotpass: 'Kirim',
             supermarket: 'Supermarket',
            Talk_to_Us : 'Hubungi Kami',
            taxi: 'Taksi',
            terms_privacy: 'Saya Setuju dengan Syarat',
            terms_privacy_next: 'dan Ketentuan yang berlaku',
            terms_of_use: 'Syarat Penggunaan',
            title: 'Judul',
            title_activity_detail_maps: 'Peta',
            title_activity_transportation_public: 'Peta',
            tour_travel: 'Wisata & Perjalanan',
            Tour___Travel: 'Wisata & Perjalanan',
            tour___travel: 'Wisata & Perjalanan',
            traditional: 'Tradisional',
            Traditional_Food: 'Tradisional',
            traditional_food: 'Makanan Tradisional',
            train: 'Kereta',
            transportation: 'Transportasi',
            try_again: 'Kembali',
            tutor: 'Lembaga Khusus',
            upgrade_resident: 'Menjadi Warga',
            upload_image_success: 'Mengunggah gambar berhasil',
            useful_information: 'Informasi',
            workshop_services: 'Bengkel',
            Workshop_Service: 'Bengkel',
            workshop_service: 'Bengkel',
            world_clock: 'Jam Dunia',
            today: 'Hari Ini',
            yes: 'Ya',
            btn_discount_coupon: '<b>Kupon</b>Diskon',
            welcome_dialog: 'Anda terdaftar sebagai ',
            okay: 'Oke',
            about_us: 'Tentang kami',
            code_name: 'Nama Kode',
            code_no: 'No Kode',
            terms: 'SYARAT & KETENTUAN',
            privacy: 'KEBIJAKAN PRIVASI',
            privacy_policy: 'Kebijakan Privasi',
            rate: 'NILAI KAMI',
            emergency_call_1: 'Panggilan',
            emergency_call_2: 'Darurat',
            emergency_service_1: 'Layanan',
            emergency_service_2: 'Darurat',
            ttu_services: 'Layanan',
            ttu_billing: 'Tagihan',
            ttu_water: 'Air',
            ttu_environment: 'Lingkungan',
            reach_us: 'Hubungi kami di',
            sort: 'Atur',
            sort_distance: 'Jarak',
            sort_name: 'Nama',
            population: 'Populasi',
            sort_popularity: 'Popularitas',
            category_all: 'Semua',
            accessories___toys: 'Aksesoris & Mainan',
            //child property
            house_property: 'Rumah',
            apartment_property: 'Apartemen',
            kavling_property: 'Kavling',
            commercial_property: 'Komersial',
            cinema: 'Bioskop',
            commercial: 'Komersial',
            industry_property: 'Industri',
            //Sort Property
            sort_harga: 'Harga(Rendah - Tinggi)',
            sort_harga_high: 'Harga(Tinggi - Rendah)',
            sort_new: 'Baru',
            sort_caption: 'Caption',
            sort_popular: 'Popularitas(Tinggi-Rendah)',
            leght_password: 'Silahkan masukkan kata sandi baru, \n Kata sandi minimal terdiri dari 8 karater.',
            avoid_pasword: 'Hindari kata sandi yang mudah ditebak \n atau digunakan dengan website lain',
            verify: 'Verifikasi',
            //forum
            post_a_comment: 'Komentar',
            send_a_comment: 'Komentar',
            comment_here: 'Komentar di sini',
            give_your_comment: 'Berikan Komentarmu',
            views: 'dilihat',
            new_topic: '+ TOPIK BARU',
            new_comment: '+ Komen Baru',
            discussion_title: 'Judul Diskusi',
            upload: 'Unggah',
            post: 'Pasang',
            edit_topic: 'edit',
            edit_post: 'Ubah',
            delete_discussion: 'Hapus Diskusi',
            comment: 'komentar',
            Comment: 'Komentar',
            Comments: 'Komentar',
            latest_forum: 'Forum Terbaru',
            oldest_forum: 'Forum Terlama',
            forum_comment: 'Komentar Forum',
            comment_success: 'Berhasil!',
            comment_failed: 'Gagal!',
            edit_comment: 'Ubah Komentar',
            delete_comment: 'Hapus Komentar',
            stared_a_thread: 'MEMULAI BAHASAN',
            acces_billing: 'Akses sekarang! Mengunduh dan membayar tagihan Anda semakin mudah',
            amount_to_be_paid: 'Total pembayaran',
            total_amount: 'Jumlah Total',
            description: 'Deskripsi',
            cant_acces_billing: 'Tidak dapat membuka tagihan',
            payment: 'Pembayaran',
            confirm_payment: 'Apakah Anda yakin akan membayar<br><b>Tagihan Perumahan</b><br>pada aplikasi Anda?',
            cancel_ovo: 'Apakah Anda yakin akan membatalkan pembayaran<br><b>Tagihan Perumahan</b><br>pada aplikasi Anda?',
            hint_email_phone: 'Email or Nomer Ponsel',
            hint_email: 'Email',
            let_acces_billing: 'Melihat Tagihan',
            pay_now: 'Bayar Sekarang',
            select_payment: 'Silahkan memilih metode pembayaran:',
            total_bill: 'Total Pembayaran',
            unit_no: 'No Unit',
            client_code: 'Kode Klien',
            client_name: 'Nama Klien',
            read_condition: 'Saya sudah membaca dan menyetujui \n Syarat & Ketentuan yang berlaku',
            must_check_term: 'You Must Check Terms of Service',
            check_term: 'Tandai syarat dan ketentuan',
            category: 'Kategori',
            category_property: 'Properti',
            property: 'Properti',
            category_events: 'Acara',
            category_competition: 'Kompetisi',
            competition: 'Kompetisi',
            category_city: 'Kota',
            city: 'Kota',
            category_discount: 'Diskon',
            general: 'Umum',
            Umum: 'Umum',
            download2: 'Unduh',
            no_file_download: 'Tidak ada file yang diunduh',
            are_you_download: 'Apakah Anda ingin mengunduh file ini?',
            no_category: 'Tidak ada kategori',
            no_property: 'Tidak ada properti',
            there_no_gallery: 'Tidak ada galeri',
            success_favorite: 'Berhasil ditambahkan ke favorit',
            failed_favorite: 'Gagal ditambahkan ke favorit',
            no_user: 'Tidak ada pengguna',
            user_cancelled: 'Login dibatalkan.',
            no_news: 'Tidak ada berita',
            news: 'Berita',
            no_data: 'Tidak ada data',
            no_data_my_voucher: 'Belum ada data untuk ditampilkan',
            downloaded: 'Sudah Diunduh',
            discount_information: 'Informasi Diskon',
            no_application_found: 'Tidak ada aplikasi ditemukan',
            download_from_android_market: 'Mengunduh satu melalui Android Market?',
            yes_please: 'Ya, Silahkan',
            no_thanks: 'Tidak, terima kasih',
            download_dialog1: 'Anda ingin mengunduh',
            download_dialog2: 'di aplikasi Anda?',
            downloading: 'Mengunduh',
            downloading_complete: 'Mengunduh berhasil',
            file_not_found: 'File tidak ditemukan',
            file_downloaded: 'File terunduh',
            download_error: 'Mengunduh gagal',
            select: 'Pilih',
            set_to_main: 'Pengaturan Utama',
            must_choice_2: 'Pilih 2 opsi',
            Calculator: 'Kalkulator',
            succes_set_to_main: 'Berhasil mengatur di halaman utama',
            exchange_rate: 'Nilai Tukar',
            korean: 'Korea',
            Korean_Food: 'Korea',
            korean_food: 'Makanan Korea',
            dialog_title_gps: 'Ijinkan "LippoCikarang.com" \n untuk mengakses lokasi \n anda selama menggunakan \n aplikasi?',
            dialog_content_gps: 'Aktifkan layanan lokasi untuk menjelajahi tempat-tempat terdekat',
            allow: 'Ijinkan',
            dont_allow: 'Tidak',
            male: 'Laki-laki',
            female: 'Perempuan',
            login_success: 'Berhasil login',
            post_topic_success: 'Berhasil menambahkan topik',
            delete_topic_success: 'Berhasil menghapus topik',
            delete_topic_failed: 'Gagal menghapus topik',
            edit_topic_success: 'Berhasil mengubah topik',
            post_topic_empty: 'Judul diskusi dan deskripsi tidak boleh kosong',
            remove_favorite_success: 'Berhasil menghapus dari favorit',
            remove_favorite_failed: 'Gagal menghapus dari Favorit',
            delete_image_success: 'Berhasil menghapus gambar',
            post_comment_success: 'Berhasil menambahkan komentar',
            delete_comment_success: 'Berhasil menghapus komentar',
            edit_comment_success: 'Berhasil mengubah komentar',
            hint_comment: 'Komentar',
            post_comment_empty: 'Komentar tidak boleh kosong',
            post_bookmark_property_success: 'Ditambahkan ke favorit',
            delete_bookmark_property_success: 'Dihapus dari favorit',
            success_bookmark: 'Berhasil menandai',
            hint_fullname: 'Nama Lengkap',
            spa___treatment: 'Spa & Perawatan',
            ovo: 'OVO',
            connect: 'Terhubung dengan Kami',
            affiliates: 'Afiliasi',
            featured: 'Fitur',
            load_from_library: 'Ambil Dari Perpustakaan',
            use_camera: 'Gunakan Kamera',
            select_image_source: 'Pilih Sumber Gambar',
            of: ' dari ',
            Gas_Station: 'SPBU',
            gas_station: 'SPBU',
            track: 'Lacak Komplain Anda',
            add_new: '+ Tambahkan',
            version: '+ Versi',
            //button
            BUTTON_TEXT_EN: 'Inggris',
            BUTTON_TEXT_DE: 'Indonesia',
            //
            contact: 'Kontak',
            total: 'Total',
            payment_amount: 'Total Pembayaran',
            unit_code: 'Kode Unit',
            recommended: 'Rekomendasi',
            places: 'Tempat',
            PLACES: 'TEMPAT',
            photo: 'Foto',
            all: 'Semua',
            unread: 'Belum Dibaca',
            hint_card_number: 'Nomor Kartu',
            choose_payment: 'Pilih metode pembayaran',
            bank_transfer: 'ATM/Bank Transfer',
            admin: 'Admin',
            expiry_date: 'Tanggal batas maksimal',
            pay: 'Bayar',
            virtual_account_number: 'Virtual Account Number',
            continue: 'Continue',
            finish: 'Selesai',
            please_ss_this_scresen: 'Mohon screenshoot halaman ini!',
            read_term_condition: 'Baca dan Setujui \n Syarat & Ketentuan yang berlaku',
            billing_not_exist: 'belum tersedia, Segera hadir',
            see_instruction: 'LIHAT INSTRUKSI',
            guide_file_not_exist: "File Panduan Tidak ada !!!",
            search_here: 'Cari disini',
            status: 'Status',
            city_info: 'Informasi Kota',
            bus_schedule: 'Jadwal Bus',
            view_all: 'Lihat Semua',
            send: 'Kirim',
            menu: 'Menu',
            bill_key: 'Bill Key',
            biller_code: 'Biller Code',
            settings: 'Setelan',
            retry: 'Ulangi',
            no_internet_message: 'Anda tidak terhubung ke internet. Harap sambungkan dan coba lagi',
            payment_via_ovo : 'Pembayaran Online',
            see_all_promos : 'Lihat semua promo',
            popular_dinings: 'Kuliner Populer',
            popular_entertainments: 'Hiburan Populer',
            popular_accomodations: 'Akomodasi Populer',
            popular_shopping: 'Belanja Populer',
            add_image: 'Tambah Gambar',
            update_comment: 'Update Comment',
            customer_service: 'Pelayanan Pelanggan',
            ongoing_promos: 'Promo',
            lc_recommendation: 'Rekomendasi Lippo Cikarang',
            some_popular_dinings: 'Beberapa kuliner populer',
            some_popular_entertainments: 'Beberapa hiburan populer',
            some_popular_accommodations: 'Beberapa akomodasi populer',
            some_popular_shopping: 'Beberapa belanja populer',
            phone_validation: 'Telepon minimal 8 karakter dan maksimal 14 karakter',
            max_image: 'Tidak dapat menambah gambar, max 2 gambar',
            add_complaint: 'Tambah Keluhan',
            concern: 'Keluhan',
            desc_concern: 'Beritahu lebih banyak...',
            attachment: 'Lampiran',
            submit_complaint: 'Kirim',
            capture_photo:  'Ambil Gambar',
            item_not_found: 'Item tidak ditemukan',
            industrial_info: 'Info Industrial',
            popular_categories: 'Kategori Populer',
            all_categories: 'Semua Kategori',
            ticket_history: 'Riwayat Tiket',  
            side_menu_welcome: 'Selamat Datang',
            error_upload_image: 'Gagal upload foto, mohon coba lagi!',
            my_point: "Poin Saya",
            new_voucher: "Voucher Baru",
            last_chance: "Peluang Terakhir untuk Ditukar",        
            other_voucher: "Voucher Lainnya",
            filter: 'Filter',
            history_point: 'Riwayat Poin',    
            history_voucher: 'Riwayat Voucher',        
            see_details : 'Lihat Detail',
            get_points: 'Dapatkan Poin',
            explore_voucher: 'Jelajahi Voucher',
            my_voucher: 'Voucher Saya',
            browse_voucher: 'Jelajahi Voucher',
            redirect_billing: 'Alihkan ke Pembayaran Tagihan',
            customize_vouchers: 'Sesuaikan Voucher',
            search_voucher: 'Mencari voucher disini',
            redeem: 'Tukar',
            use_this_voucher: 'Gunakan Voucher Ini',
            load_more: 'Muat lebih',
            overview: 'Deskripsi',
            how_to_use: 'Cara penggunaan',
            t_and_c: 'S&K',
            redeem_now: 'Tukar Sekarang',
            sufficient_point: 'Kamu tidak punya cukup poin untuk menukar voucher ini',
            points: 'Poin',
            valid_until: 'Berlaku hingga',
            outstanding: 'Tagihan',
            outstandings: 'Tagihan',
            learn_more: 'Pelajari Lebih Lanjut',
            outstanding_text: 'Transaksi ini akan mengurangi poin anda karena membutuhkan poin dari poin anda, jadi poin anda akan berkurang.',
            you_have: 'Anda memiliki',
            have_outstanding: 'Anda memiliki tagihan',
            available: 'Tersedia',
            from: 'dari',
            save_ovoid: 'Simpan nomor telepon akun OVO dan hubungkan ke Akun untuk transaksi berikutnya.',
            phonenumber_cant_empty: 'Mohon isi nomor telepon akun OVO Anda',
            your_ovoid: 'Nomor Telepon Akun OVO',
            there_has_been_an_error_our_system: 'Terjadi kesalahan pada sistem kami, <br> silakan coba lagi nanti',    
            ovo_info1: 'Pastikan Anda sudah login ke aplikasi OVO',
            ovo_info2: 'Pembayaran dengan aplikasi OVO akan Kedaluwarsa dalam 30 detik setelah Anda klik "Bayar menggunakan OVO"',
            ovo_info3: 'Buka notifikasi OVO untuk melakukan pembayaran',
            ovo_info4: 'Pilih cara pembayaran dengan "OVO Cash" atau "OVO Point" atau kombinasi keduanya, kemudian klik "Bayar"',
            info_payment_ovo: 'Info Pembayaran dengan aplikasi OVO',
            payment_ovo: 'Pembayaran OVO',
            transaction_failed: 'Transaksi Gagal',
            others_desc_billing: '(Bank Transfer, Karti Kredit and Go-Pay)',
            transaction_cancelled: 'Transaksi Dibatalkan',
            worth: 'Senilai',
            redeem_for_various: 'Tukarkan poin untuk mendapatkan voucher dari kami',
            lowest_point: 'Poin Terendah',
            highest_point: 'Poin Tertinggi',
            availability: 'Ketersediaan',
            distance: 'Jarak',
            voucher_status : 'Status Voucher',
            quick_filter : 'Filter Cepat',
            expiring : 'Akan Kedaluwarsa',
            expired : 'Kedaluwarsa',
            voucher_with_my_point: 'Voucher yang dapat ditukarkan dengan ',
            voucher_expiring: 'Voucher yang akan kedaluwarsa',
            scan_qrcode: 'Pindai Kode QR',
            scan_qrcode_desc: 'Dapatkan poin dengan memindai kode QR pada acara',
            scan_now: 'Pindai Sekarang',
            learn_more_get_point: 'Pelajari lebih lanjut dapatkan poin',
            qrcode_scanned: 'Kode QR dipindai',
            qrcode_limit: 'Kode QR sudah tidak tersedia',
            qrcode_scanned_desc: 'Bagikan acara ini dan dapatkan poin tambahan',
            share_now: 'Bagikan Sekarang',
            how_do_earn_points: 'Bagaimana cara saya mendapatkan Poin?',
            read_more: 'Baca lebih banyak',
            msg_have_checkin: 'Yay! Saya sudah check-in di acara',
            go_back: 'Kembali',
            qr_invalid: 'Kode QR Tidak Valid',
            point: 'Poin',
            available_points: 'Poin yang tersedia',
            pts: 'pts',
            cancel_share_event: 'Batal membagikan acara',
            customize_voucher: 'Sesuaikan Voucher',
            customize_voucher_desc: 'Lihat dan atur preferensi voucher Anda.',
            available_until: 'Tersedia Sampai',
            use: 'Gunakan',
            used: 'Digunakan',
            used_date: 'Tanggal Digunakan',
            expiring_this_month: 'Kedaluwarsa bulan ini',
            redeem_voucher: 'Gunakan Voucher',
            use_point_to_redeem_desc : 'Gunakan poin Anda untuk menebus voucher ini',
            Ooopss : 'Ooopss......',
            apply_clp: 'Terapkan',
            outstanding_not_found: 'Data tagihan Anda tidak ditemukan',
            please_input_merchant: 'Masukkan kode merchant',
            please_input_ovo : 'Masukkan OVO id atau OVO Number',
            how_get_merchant: 'Bagaimana mendapatkan kode merchant',
            see_my_voucher : 'Lihat Voucher Saya',
            transaction_id: 'Transaksi ID',
            submit_by: 'Disubmit oleh',
            date_time: 'Tanggal dan Waktu',
            redeemed: 'Ditukarkan',
            submit_voucher: 'Kirim',
            title_deleted: 'Hapus Otomatis',
            title_deleted_desc: 'Hapus kedaluwarsa oleh sistem, 7 (tujuh) hari setelah voucher telah kedaluwarsa.',
            title_reminder: 'Pengingat notifikasi voucher',
            title_reminder_desc: 'Siapkan pemberitahuan tentang voucher kedaluwarsa. Aktifkan pemberitahuan untuk mendapatkan informasi ketika voucher hampir kedaluwarsa.',
            payment_succeed: 'Pembayaran sukses',
            payment_status: 'Status Pembayaran',
            payment_has_been_canceled: 'Payment has been cancelled',
            km_desc_tenant : 'Km dari lokasi anda',
            second: 'detik',
            minutes: 'menit',
            hours: 'jam',
            days: 'hari',
            ago: 'yang lalu',
            will_be_expiring_at: 'voucher ini akan kedaluwarsa pada',
            billing_info: 'Bukti pembayaran akan di kirimkan terpisah melalui email. Jika dalam waktu 1 jam, customer belum menerima bukti pembayaran, silahkan hubungi CS.',
            billing_statement: 'Tagihan',
            payment_history: 'Riwayat',
            time: 'waktu',
            user_details: 'Detail Pengguna',
            payment_details: 'Detail Pembayaran',
            payment_method: 'Metode Pembayaran',
            total_payment: 'Total Pembayaran',
            va_number: 'Nomor Akun Virtual',
            credit_card: 'Nomor Kartu',
            unit_details: 'Detail UNit',
            download_pdf: 'Unduh PDF',
            download_payment_history: 'Unduh Riwayat Pembayaran',
            from_input: 'Dari',
            to_input: 'Sampai',
            download_text: 'Unduh',
            filter: 'Filter',
            i_want_to_pay : 'Saya ingin membayar',
            other_bill: 'Tagihan Lainnya',
            unpaid: 'Belum Dibayar',
            paid: 'Dibayar',
            apply: 'Apply',
            with_ovo: 'Dengan OVO',
            with_midtrans: 'Dengan Midtrans',
            payment_unit: 'Pembayaran Unit',
            my_unit: 'Unit Saya',
            number_of_unit: 'Jumlah Unit',
            dialog_pay_other_bill: 'Apakah anda yakin akan membayar Tagihan Lain ?',
            confirmation: 'Konfirmasi',
            units : 'Units',
            needhelp_our: 'Tim Layanan Pelanggan kami selalu siap membantu anda, jika anda memiliki pertanyaan atau mengalami masalah',
            needhelp_for: 'Untuk respon cepat, silahkan hubungi tim Layanan Pelanggan kami Pusat Layanan Pelanggan',
            needhelp_csc: 'Pusat Layanan Pelanggan',
            needhelp_reach: 'Hubungi tim kami untuk informasi lebih lanjut',
            hours_24: '24 Jam',
            telephone: 'Telepon',
            detail_history: "Detail Histori",
            billing_has_been_paid: "Anda tidak mempunyai tagihan pembayaran",
            bukti_pembayaran: "Bukti pembayaran akan dikirimkan terpisah melalui email. Jika dalam waktu 1 jam anda belum menerima bukti pembayaran, silahkan hubungi CS.",
            see_payment_detail: "Lihat Detail Pembayaran",
            no_payment_method: 'Metode pembayaran untuk tagihan Anda sedang tidak tersedia',
            date_and_time: "Tanggal dan Waktu",
            transaction_id: "ID Transaksi",    
            have_agree: "Saya telah membaca dan setuju dengan ",
            terms_and_condition: "syarat & ketentuan",
            pay_bills: "Bayar Tagihan",
            type_search_point: "Ketik minimal 3 karakter",
            result_for: "Hasil dari",
            no_result_found_for: "Tidak ada hasil untuk",
            make_sure_your_words: 'Oopsss.... Pastikan kata yang diketikkan benar, atau gunakan kata kunci yang berbeda',
            barcode_scanner_info: 'Tempatkan kode di dalam area pemindaian',
        });
    $translateProvider.preferredLanguage('en');
    // remember language
    $translateProvider.useLocalStorage();
    $urlRouterProvider.otherwise("/");
    // white list link payment

    $sceDelegateProvider.resourceUrlWhitelist([
        // Allow same origin resource loads.
        'self',
        // Allow loading from our assets domain.  Notice the difference between * and **.
        'https://innoprod.vnetcloud.com/liveinpayment/payment?**'
    ]);

}

function run($ionicPlatform, $ionicPopup, $state, $ionicModal, $timeout, $rootScope, $location, $filter, $localStorage, ngFB, NotifAccountService, AdvertiseService, PointService, Version, $cordovaAppVersion, $ionicScrollDelegate) {
    
    $rootScope.search = function (value) {
        console.log($location.path());
        if ($location.path() == "/app/main" || $location.path() == "/app/currency" ) {
            $location.path('/app/search/' + value);
        } else if ($location.path() == "/app/property") {
            $location.path('/app/propertysearch/' + value + '/');
        } else if ($location.path() == "/app/gallery" || $location.path().includes("/app/detailGallery/") || $location.path().includes("/app/getSearchGallery/")) {
            $location.path('/app/getSearchGallery/' + value);
        } else if($location.path().includes("/app/tenantHome/")){
            $location.path('/app/searchTenants/' + value);
        }else if($state.current.name == 'app.category'){
            $rootScope.search_page = value;
            if($rootScope.checkSearch) {
                $rootScope.checkSearch();    
            }
        } else if($location.path().includes("/app/whatsNew")){
            $rootScope.search_page = value;
            if($rootScope.searchWhatsNew){
                $rootScope.searchWhatsNew();
            }
        }
        else {
            $rootScope.search_page = value;
        }
        
        $ionicScrollDelegate.scrollTop();
    }

    $rootScope.$on("$ionicView.beforeEnter", function () {
        //$ionicConfigProvider.views.maxCache(0);

        var myEl = angular.element(document.querySelector('#sidemenu-con'));
        // $location.path().substr(0, 15) == "/app/cctvDetail" ||
        if ( $location.path() == "/app/main" || $location.path().substr(0, 11) == "/app/search" ||
            $location.path() == "/app/currency" || $location.path() == "/app/profile" || $location.path() == "/app/history" ||
            $location.path().substr(0, 14) == "/app/myhistory" || $location.path() == "/app/editprofile" || $location.path() == "/app/listbookmark" ||
            $location.path() == "/app/notification" || $location.path().substr(0, 23) == "/app/notificationDetail" ||
            $location.path() == "/app/map" || $location.path() == "/app/download" || $location.path().substr(0, 19) == "/app/downloadDetail" ||
            $location.path() == "/app/inivitefriend" || $location.path() == "/app/tenantDetail/:idtenant" ) {
            myEl.attr('nav-view', 'cached');
        } else {
            myEl.attr('nav-view', 'active');
        }

    });
 
    $rootScope.$on("$ionicView.beforeEnter", function () {
        $rootScope.footerPaymentHistory = false;
        if ($location.path() == "/app/bus" || $location.path() == "/app/billing" || 
            $location.path() == "/app/paymentMidtransGoPay" || $location.path().substr(0, 18) == "/app/detailPayment" || 
            $location.path() == "/app/needhelp" || $location.path().substr(0, 13) == "/app/cctvFull" || 
            $location.path().substr(0, 25) == "/app/detailHistoryBilling" || $location.path() == "/app/otherbilling" || 
            $location.path().substr(0, 18) == "/app/voucherDetail" || $location.path() == "/app/newsearchPoint" || $location.path() == "/app/historyVoucher" || $location.path() == "/app/historyPoint" ||
            $location.path().substr(0, 19) == "/app/whatsNewDetail") 
        {
            $rootScope.tab = false;
        } else {
            $rootScope.tab = true;
        } 
        
    });

    $rootScope.$on("$ionicView.afterEnter", function () {
        
        $rootScope.closeModalErrorConnection = function () {
            if (window.Connection) {
                if (navigator.connection.type == Connection.NONE) {
                    $rootScope.closeModalErrorConnection();
                } else {
                    $rootScope.modalErrorConnection.hide();
                }
            }
        };
        
        if($localStorage.firstOpen){
            if (window.Connection) {
                if (navigator.connection.type == Connection.NONE) {
                    $ionicModal.fromTemplateUrl('partials/sides/modalErrorConnection.html', {
                        scope: $rootScope
                    }).then(function (modalMenu) {
                        $rootScope.modalErrorConnection = modalMenu;
                        $rootScope.modalErrorConnection.show();
                    });
                }
            }
        }
    });


    $rootScope.$on("$ionicView.beforeEnter", function () {
        if ($location.path() != "/app/main") {
            $rootScope.$broadcast('adsModal:hideModal');
            $rootScope.$broadcast('adsLogin:hideModal');
        }
    });

    $rootScope.$on("$ionicView.beforeEnter", function () {
        if ($location.path().substr(0, 13) == "/app/cctvFull") {
            screen.orientation.lock('landscape');

            // // set to either landscape
            // screen.orientation.lock('landscape');

            // // allow user rotate
            // screen.orientation.unlock();

            // // access current orientation
            // console.log('Orientation is ' + screen.orientation.type);
        }
    });

    $ionicPlatform.ready(function () {

        // --START ANALYTIC GOOGLE
        if(window.ga){
            window.ga.startTrackerWithId('UA-121566347-1', 30);
            console.log("Analytic - startTrackerWithId - UA-121566347-1");
            Version.GetVersion(function (response) {
                $rootScope.getVersionApplication = response;
                window.ga.setAppVersion(response);
                console.log("Analytic - Version - " + response);
                // window.ga.setUserId('my-user-id');
            });
         }
        $rootScope.StartEvent = false;

        if (window.StatusBar) {
            if (ionic.Platform.isAndroid()) {
              StatusBar.backgroundColorByHexString("#27A9E1");
            } 
        }
        // backgroundGeolocation.configure(callBackFn,failureFn,{
        //    desiredAccuracy: 10,
        // stationaryRadius: 20,
        // distanceFilter: 30,
        // interval: 60000
        // });

        // //get location succes
        // var callBackFn = function (position) {
        //     //console.log("Bisa map");
        //     $rootScope.backgroundmyLatlng = new google.maps.LatLng(position.latitude, position.longitude);
        //     backgroundGeolocation.finish();
        // };

        // var failureFn = function (error){
        //     console.log("error map");
        //     $rootScope.backgroundmyLatlng = undefined;
        // };

        // backgroundGeolocation.start();

        // navigator.geolocation.getCurrentPosition(function(pos) {
        //     lat = pos.coords.latitude
        //     long = pos.coords.longitude
        //      $rootScope.backgroundmyLatlng = new google.maps.LatLng(lat, long);

        // },function(error){
        //     navigator.geolocation.watchPosition
        //         (function onSucces(position){
        //             $rootScope.backgroundmyLatlng = new google.maps.LatLng(lat, long);

        //         },function onMapError(error){

        //     $rootScope.backgroundmyLatlng = undefined;

        //         },
        //         { enableHighAccuracy: false });
        // });

        // cordova.getAppVersion(function (version) {
        //     alert(version);
        // });

        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)

        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
            /*StatusBar.overlaysWebView(false);
            StatusBar.backgroundColorByHexString('#0D6DB6');*/
        }

        // Push Notification
        setInterval(function () {

            if ($localStorage.currentUser != null) {
 
                // Push Notifications
                PushNotifications();
                if ($localStorage.firstOpenhasClosed) {
                    PushAdvertise();
                }
            }
        }, 5000);
        // var serHours = 4;
        // var calculatehours = (serHours * 60 * 60 * 1000);
        var calculatehours = ( 1 * 60 * 1000);
        setInterval(function () {
            if ($localStorage.settingMyVoucher) {
                if($localStorage.settingMyVoucher.isReminder){
                    getNotifVoucherExpiring();
                    console.log(" getNotifVoucherExpiring new Date()");
                    console.log(strToDate(new Date().toISOString()));
                }
            }
        }, calculatehours);

        function PushNotifications() {
            NotifAccountService.countNotif(function (response) {
                var sum = response;

                if ($localStorage.notifPush.sound != false) {
                    var playSound = 'res://platform_default';
                } else {
                    var playSound = 'TYPE_NOTIFICATION';
                }
 
                if (sum > 0) {
                    $localStorage.idNotification++;
                    console.log('Anda memiliki ' + sum + ' notif baru..');
                    if ($localStorage.notifPush.status != false) {
                        cordova.plugins.notification.badge.get(function (badge) {
                            console.log('Count Notif ..'+ badge);
                        });
                        console.log('Notif Aktif ..');
                        cordova.plugins.notification.local.schedule({
                            id: $localStorage.idNotification,
                            title: $filter('translate')('notification_push'),
                            sound: playSound,
                            badge: sum,
                        });
                        cordova.plugins.notification.badge.increase(1, function (badge) {
                            console.log('Success increase badge now ' + badge);

                            // badge is now 11 (10 + 1)
                        });

                        cordova.plugins.notification.badge.get(function (badge) {
                            console.log('Count Notif ..'+ badge);
                        });
                        cordova.plugins.notification.local.on("trigger", function (notification) {
                            console.log('Success with ' + notification.id);
                        });
                        cordova.plugins.notification.local.on("schedule", function(notification) {
                            console.log('scheduled with ' + notification.id);
                        });
                        cordova.plugins.notification.local.on("click", function(notification) {
                            console.log('click with ' + notification.id);
                            // cordova.plugins.notification.badge.decrease(1, function (badge) {
                            //     console.log('Success decrease badge now ' + badge);
                            // });
                            $state.go('app.notification');
                        });
                    } else {
                        // console.log('Notif Nonaktif ..');
                    }
                } else {
                    // console.log('Tidak ada notif baru ..');
                }
            });
        }

        function PushAdvertise() {
            AdvertiseService.AdsWhenNew(function (response) {
                var sum = response;

                if (sum > 0) {
                    //console.log('Anda memiliki ' + sum + ' ads baru..');
                    AdvertiseService.AdsOpen();
                } else {
                    // console.log('Tidak ada ads baru ..');
                }
            });
        }

        function getNotifVoucherExpiring() {
            PointService.getVoucherExpired(function (response) {
                if(response){
                    if(response.status){ 
                        if($localStorage.idNotificationVoucher){
                            $localStorage.idNotificationVoucher = 1;
                            // $localStorage.tempVoucherExpiring = [];
                        }
                        response.data.forEach(function(obj){
                            // $localStorage.tempVoucherExpiring.push(obj);
                            pushNotifVoucherExpiring(obj);
                        });

                    }else{
                        console.log("==== response getVoucherExpired ====");
                        console.log(response);
                    }
                }else{
                    console.log("404 getVoucherExpired");
                }
            });
        }


       function strToDate (date){
            var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
            return dt;
        } 

        function pushNotifVoucherExpiring(dataVoucher){
            var playSound;
            if ($localStorage.notifPush.sound) {
                playSound = 'res://platform_default';
            } else {
                playSound = 'TYPE_NOTIFICATION';
            }

            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
            cordova.plugins.notification.badge.get(function (badge) {
                console.log('Count Notif ..'+ badge);
            });

            var title = lang == 'ina' ? dataVoucher.title_id : dataVoucher.title;

            var expired_date = moment(dataVoucher.expired_date).format('D MMM YYYY hh:mm a'); 
            console.log('Add Notif Aktif Voucher expiring ..');
            console.log(title);
            $localStorage.idNotificationVoucher++;
            var date_at_8am = strToDate(new Date().toISOString());
            date_at_8am.setHours(8);
            date_at_8am.setMinutes(0);
            date_at_8am.setSeconds(0);
            console.log('date_at_8am');
            console.log(date_at_8am);
            var date_at_5pm = strToDate(new Date().toISOString());
            date_at_5pm.setHours(17);
            date_at_5pm.setMinutes(0);
            date_at_5pm.setSeconds(0);
            console.log('date_at_5pm');
            console.log(date_at_5pm);

            cordova.plugins.notification.local.schedule({
                id: dataVoucher.id,
                title: title,
                text: $filter('translate')('will_be_expiring_at') + " " + expired_date,
                sound: playSound, 
                badge: 1,
                trigger: { at: date_at_8am }
            });

            cordova.plugins.notification.local.schedule({
                id: dataVoucher.id,
                title: title,
                text: $filter('translate')('will_be_expiring_at') + " " + expired_date,
                sound: playSound, 
                badge: 1,
                trigger: { at: date_at_5pm }
            });

            cordova.plugins.notification.badge.get(function (badge) {
                console.log('Count Notif ..'+ badge);
            });
            cordova.plugins.notification.local.on("trigger", function (notification) {
                console.log('Success with ' + notification.id);
            });
            cordova.plugins.notification.local.on("schedule", function(notification) {
                console.log('scheduled with ' + notification.id);
                cordova.plugins.notification.badge.increase(1, function (badge) {
                    console.log('Success increase badge now ' + badge);
                    // badge is now 11 (10 + 1)
                });
            });
            cordova.plugins.notification.local.on("click", function(notification) {
                console.log('click with ' + notification.id);
                // console.log('click with ' + notification.idVoucher);
                // cordova.plugins.notification.badge.decrease(1, function (badge) {
                //     console.log('Success decrease badge now ' + badge);
                // }); 
                
                $state.go('app.voucherDetail', {id:notification.id});
            });
        }
    });

    // keep user logged in after page refresh
    if ($localStorage.currentUser) {
        $localStorage.currentUser.fullname = $localStorage.currentUser.fullname;
    }

    /*// redirect to login page if not logged in and trying to access a restricted page
    $rootScope.$on('$locationChangeStart', function(event, next, current) {
        var publicPages = ['/'];
        var restrictedPage = publicPages.indexOf($location.path()) === -1;
        if (restrictedPage && !$localStorage.currentUser) {
            $location.path('/');
        }
    });*/

    ngFB.init({ appId: '822365854560840' });

}

function ngEnter() {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });

                event.preventDefault();
            }
        });
    }
}

function repeatDone() {
    return function (scope, element, attrs) {
        if (scope.$last) {
            scope.$eval(attrs.repeatDone);
        }
    }
}

function trustAsResourceUrl($sce) {
    return function (url) {
        return $sce.trustAsResourceUrl(url);
    };
}
