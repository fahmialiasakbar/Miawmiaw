angular
    .module('livein')
    .controller('mainTabs', mainTabs);

function mainTabs($scope, $cordovaGeolocation, billingServices, PointService, $sce, $state, $rootScope, $timeout, $window, $ionicPopup, $localStorage, $ionicLoading, $ionicModal, $ionicSlideBoxDelegate, $ionicPlatform, dataWhatsNew, talktoUs, $filter, AdvertiseService, $cordovaSocialSharing, CouponService, $filter, TenantService) {
    $scope.fakelist=[1,2,3,4];
    $scope.tenantAccomodations;
    $scope.tenantDinings;
    $scope.tenantEntertainment;
    $scope.tenantShopping;

    var email = 'samadhi.emaus@yahoo.com';
    // if ($localStorage.currentUser) {
    //     if ($localStorage.currentUser.data) {
    //         if ($localStorage.currentUser.data[0]) {
    //             if ($localStorage.currentUser.data[0].email) {
    //                 email = $localStorage.currentUser.data[0].email;
    //             }
    //         }
    //     }
    // } 

    $rootScope.emailres = email; //params older billing 
    
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Dashboard Home';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    function getId(id) {
        var shapeId = id;
        console.log("idnya vroh: " + shapeId);
    }

    $rootScope.StartEvent = false;
    if (!$localStorage.firstOpen) {
        if (ionic.Platform.isIOS()) {
            startIntroduction();
        }else{
            getListCoupon();
            $localStorage.firstOpen = { status: true };
        }
    }

    //mulai sini
    $ionicModal.fromTemplateUrl('partials/sides/coba.html', {
        scope: $scope
    }).then(function (modalMenu) {
        $scope.modalMenu = modalMenu;
    });

    $scope.openMenu = function () {
        $scope.modalMenu.show();
    }

    $scope.closeModalSlider = function () {
        $scope.modalMenu.hide();
    };

    //sampe sini

    function startIntroduction() {

        var screen = angular.element(document.querySelector('ion-side-menu'));
        screen.css('visibility', 'hidden');

        $rootScope.IntroOptions = {
            steps: [
                {
                    element: document.querySelector('.tabs .tab-item.profilecon'),
                    intro: '<div class="introjs-first">' + $filter('translate')('intro1') + '</div>',
                    position: 'top'
                },
                {
                    element: document.querySelector('#step1'),
                    intro: '<div class="introjs-second">' + $filter('translate')('intro2') + '</div>',
                    position: 'top'
                },
                {
                    //.bar .button.button-custom.navcon
                    element: document.querySelector('.bar'),
                    intro: '<div class="introjs-third">' + $filter('translate')('intro3') + '</div>',
                    position: 'bottom'
                }
            ],
            showStepNumbers: false,
            showBullets: false,
            exitOnOverlayClick: false,
            exitOnEsc: false,
            showProgress: false,
            // nextLabel: $filter('translate')('next'),
            // prevLabel: $filter('translate')('previous'),
            // skipLabel: $filter('translate')('skip'),
            // doneLabel: $filter('translate')('thanks')
            nextLabel: 'Next',
            prevLabel: 'Previous',
            skipLabel: 'Skip',
            doneLabel: 'Thanks'

        };
        var introprofile = angular.element(document.querySelector('.tabs .tab-item.profilecon'));
        introprofile.css('opacity', '1.0');
        introprofile.css('background-color', 'white');
        introprofile.css('margin-top', ' 1px')

        var intronav = angular.element(document.querySelector('.bar .button.button-custom'));
        intronav.css('background-color', 'transparent');

        $rootScope.CompletedEvent = function () {
            screen.css('visibility', 'visible');
            // console.log('[directive] completed Event')
            getListCoupon();
            $localStorage.firstOpen = { status: true };
        }
        $rootScope.StartEvent = true;
        $rootScope.ExitEvent = function () {
            screen.css('visibility', 'visible');
            if (!$localStorage.firstOpenhasClosed) {
                $localStorage.firstOpenhasClosed = true;
                $localStorage.firstOpen = { status: true };
                $localStorage.idNotification = 0;
            }

            // console.log('[directive] exit Event')
        }
        $rootScope.ChangeEvent = function (id) {
            // console.log('[directive] change Event')
            // console.log($rootScope.IntroOptions.steps);
            $timeout(function () {
                if ($scope.couponData == '') {
                    $scope.showCoupon = true;
                    $scope.couponData = [{
                        id: '1',
                        idtenant: '2',
                        image: '',
                        title: 'Discount'
                    }];
                }
            }, 0)
        }
        $rootScope.BeforeChangeEvent = function (id) {
            // console.log('[directive] beforeChange Event')
            // console.log($rootScope.IntroOptions.steps);
        }
        $rootScope.AfterChangeEvent = function (id) {
            // console.log('[directive] after change Event')
            // console.log($rootScope.IntroOptions.steps);
        }


    }

    $scope.affiliate_ovo = isOVO;
    function isOVO() {
        // this function invokes the plugin:

        var scheme;
        if (device.platform === 'iOS') {
            scheme = 'ovo://';
        }
        else if (device.platform === 'Android') {
            scheme = 'ovo.id';
        }
        appAvailability.check(
            scheme,
            function onSucces(result) {
                gotoApps();
            },
            function onError(error) {
                gotoAppStore();
            }
        );

        function gotoApps() {
            window.open(scheme, '_system', 'location=no');
            console.log('Ovo Installed');
        }

        function gotoAppStore() {
            if (device.platform === 'iOS') {
                window.open('https://itunes.apple.com/id/app/ovo/id1142114207?mt=8', '_system', 'location=no');
            } else {
                window.open('https://play.google.com/store/apps/details?id=ovo.id', '_system', 'location=no');
            }

            console.log('Ovo Not Installed');
        }
    }

    $scope.gotoInstagram = function () {
        window.open('https://www.instagram.com/officiallippocikarang', '_system', 'location=no');
    }

    $scope.gotoTwitter = function () {
        window.open('https://twitter.com/lippockrg', '_system', 'location=no');
    }

    $scope.gotoFacebook = function () {
        window.open('https://www.facebook.com/Lippo-Cikarang-1721784978116394/', '_system', 'location=no');
    }

    if ($localStorage.currentUser) {
        $scope.fullname = $localStorage.currentUser.data[0].fullname;
        $scope.salah = true;
    } else {
        $scope.salah = false;
    }

    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    var pagesize = 3;

    // dataWhatsNew.getDataWhatsNew(lang, pagesize, function (response) {
    //     $timeout(function () {
    //         if (response != false) {
    //             $scope.data = response;
    //             $scope.news = [];
    //             var a = 0;
    //             angular.forEach($scope.data, function (obj) {
    //                 var b = a++;
    //                 var list = $scope.data;
    //                 var data = list[b];

    //                 var status = data.status;
    //                 var idnews = data.idnews;
    //                 var description = data.description;
    //                 var gallery = data.gallery;

    //                 if (data.createdate != null) {
    //                     var d = new Date(data.createdate.replace(' ', 'T'));
    //                     var createdate = new Date(d);
    //                 } else {
    //                     var createdate = "";
    //                 }

    //                 var title = data.title;
    //                 var avatar = data.avatar;

    //                 $scope.news.push({
    //                     'status': status,
    //                     'idnews': idnews,
    //                     'description': description,
    //                     'gallery': gallery,
    //                     'title': title,
    //                     'createdate': createdate,
    //                     'avatar': avatar
    //                 });
    //             });

    //             $ionicSlideBoxDelegate.update();
    //         } else {
    //             $scope.news = [{ name: $filter('translate')('no_news') }];
    //         }
    //     }, 500);
    // });

    talktoUs.getTalktoUs(function (response) {
        if (response != false) {
            $scope.datatalk = response;
        } else {
            $scope.datatalk = [{ name: $filter('translate')('no_data') }];
        }
        $ionicLoading.hide();
    });

    //modal talkToUs
    $ionicModal.fromTemplateUrl('partials/sides/talktoUs.html', {
        scope: $scope
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openTalkto = function (index) {
        $scope.modal.show();
        // ----- Analytic Screen
        if (window.ga) {
            var analyticView = 'Talk to Us';
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Screen View', analyticView);
            console.log("Analytic - Screen View - " + analyticView);
        }
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
        $scope.modalSlider.hide();
    };

    $ionicModal.fromTemplateUrl('partials/sides/whatsNewModal.html', {
        scope: $scope
    }).then(function (modalSlider) {
        $scope.modalSlider = modalSlider;
    });

    $scope.openModal = function (list) {
        $scope.list = list;
        $scope.urly = $sce.trustAsResourceUrl("https://www.youtube.com/embed/XCWmONajkOg")

        for (var i = 0; i < $scope.list.gallery.length; i++) {
            var obj_gal = $scope.list.gallery[i];
            if (obj_gal.type == 2) {
                if (obj_gal.avatar) {
                    var ava = obj_gal.avatar;
                    var source = [{
                        src: $sce.trustAsResourceUrl(obj_gal.avatar),
                        type: 'video/' + ava.substring(ava.length - 3)
                    }]
                    obj_gal.sources = source;
                }
            }
            else if (obj_gal.type == 3) {
                obj_gal.urly = $sce.trustAsResourceUrl(obj_gal.link_youtube)
            }

        }
        $scope.config = {
            preload: "none",
            tracks: [
                {
                    src: "http://www.videogular.com/assets/subs/pale-blue-dot.vtt",
                    kind: "subtitles",
                    srclang: "en",
                    label: "English",
                    default: ""
                }
            ],
            theme: {
                url: "https://unpkg.com/videogular@2.1.2/dist/themes/default/videogular.css"
            }
        };

        if (list.gallery == '' | list.gallery.length == 0) {
            $scope.showGallery = false;
        } else {
            $scope.showGallery = true;
            $scope.gallery = list.gallery;
        }
        $scope.modalSlider.show();
    };

    $scope.closeModalSlider = function () {
        $scope.modalSlider.hide();

        $timeout(function () {
            removetaskmodal();
        }, 1000);
        //     removetaskmodal ();




    };

    function removetaskmodal() {
        $scope.modalSlider.remove();


        $ionicModal.fromTemplateUrl('partials/sides/whatsNewModal.html', {
            scope: $scope
        }).then(function (modalSlider) {
            $scope.modalSlider = modalSlider;
        });

    }

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hide', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });

    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
    };

    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.showCoupon = true;
    getListCoupon();
    function getListCoupon() {
        CouponService.listCoupon(function (response) {
            $scope.couponData = [];
            if (response != false) {
                for (var i = 0; i < response.length; i++) {
                    $scope.couponData.push({
                        id: response[i].iddiscountcoupon,
                        idtenant: response[i].idtenant,
                        imageurl: response[i].imageurl,
                        title: response[i].title
                    })
                }
                $scope.data = response;

            } else {
                $scope.showCoupon = false;
                $scope.data = { name: $filter('translate')('no_user') };
            }
            $ionicLoading.hide();
        });
    }

    $scope.shownew = true;
    getWhatsNew();
    function getWhatsNew() {
        $scope.whatsnew = [];
        var pagenumber = 1;
        dataWhatsNew.getDataWhatsNewSide(pagenumber, lang, function (response) {
            if (response != false) {
                $scope.data = response;
                $scope.whatsnew = [];
                var a = 0;
                angular.forEach($scope.data, function (obj) {
                    var b = a++;
                    var list = $scope.data;
                    var data = list[b];

                    var status = data.status;
                    var idnews = data.idnews;
                    var description = data.description;
                    var descnew = description.substr(3, 200);
                    var gallery = data.gallery;

                    if (data.createdate != null) {
                        var createdate = $scope.strToDate(data.createdate);
                    } else {
                        var createdate = null;
                    }

                    var title = data.title;
                    var avatar = data.avatar;
                    var image;
                    if (avatar == null || avatar == "") {
                        image = 'img/items/property_add_photo.png'
                    } else {
                        image = avatar;
                    }
                    var createdateago = cekLastCreatedOn(createdate);
                    $scope.whatsnew.push({
                        'status': status,
                        'idnews': idnews,
                        'descnew': descnew,
                        'description': description,
                        'gallery': gallery,
                        'title': title,
                        'createdate': createdate,
                        'avatar': image,
                        'createdateago': createdateago,
                    });
                    if ($scope.whatsnew == '') {
                        $scope.shownew = 'false';
                    }
                });

                //if($scope.hehe == null){
                //
                var i = 2;
                $scope.loadMore = function () {
                    pagenumber = i;

                    dataWhatsNew.getDataWhatsNewSide(pagenumber, lang, function (response) {
                        if (response) {
                            $scope.whatsnew = $scope.whatsnew.concat(response);

                        } else {
                            console.log('no more data loaded');

                        }
                    });

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    i++;
                };
                //
                //}
            } else {
                $scope.shownew = false;
                $scope.data = [{ name: $filter('translate')('no_news') }];
            }
            $ionicLoading.hide();
        });
    }
    $scope.strToDate = function (date) {
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    }

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    } 

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    function cekLastCreatedOn(date) {
        var str = '';
        var now = new Date();
        if (date) {
            var bitDate = new Date(date);
            var waktu;
            var n = now - bitDate;
            var detik = Math.round(n / 1000);
            var menit = Math.round(detik / 60);
            var jam = Math.round(menit / 60);
            var hari = Math.round(jam / 24);
            if (detik < 60 && detik >= 0) { waktu = detik + " " + $filter('translate')('second') }
            else if (menit < 60) { waktu = menit + " " + $filter('translate')('minutes') }
            else if (jam < 24) { waktu = jam + " " + $filter('translate')('hours') }
            else if (hari < 7) { waktu = hari + " " + $filter('translate')('days') }
            else { waktu = "" }

            if (waktu == "") {
                str = "";
            } else {
                str = waktu + " " + $filter('translate')('ago');
            }
        }
        return str;
    }

    var calculatdistance = function (longlat) {
        datalonglat1 = longlat.replace('(', '');
        datalonglat2 = datalonglat1.replace(')', '');
        lattenant = (datalonglat2.split(',')[0]);
        longtenant = (datalonglat2.split(',')[1]);

        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
        var dLon = deg2rad($scope.long - longtenant);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
    $scope.showDining = true;
    $scope.showEntertainment = true;
    $scope.showAccomodation = true;
    $scope.showShopping = true;


    function texcategory(idcategory) {

        if (angular.equals(idcategory, "16")) {
            child_category = $filter('translate')('events');
        }
        //sport
        if (angular.equals(idcategory, "17")) {
            child_category = $filter('translate')('sport');
        }
        //child sport
        if (angular.equals(idcategory, "21")) {
            child_category = $filter('translate')('gym');
        }
        if (angular.equals(idcategory, "22")) {
            child_category = $filter('translate')('outdoor_sport');
        }
        if (angular.equals(idcategory, "23")) {
            child_category = $filter('translate')('indoor_sports');
        }
        if (angular.equals(idcategory, "104")) {
            child_category = $filter('translate')('recreational_sites');
        }
        if (angular.equals(idcategory, "105")) {
            child_category = $filter('translate')('golfing');
        }
        //leisure
        if (angular.equals(idcategory, "18")) {
            child_category = $filter('translate')('leisure');
        }
        // child leisure
        if (angular.equals(idcategory, "24")) {
            child_category = $filter('translate')('cinema');
        }
        if (angular.equals(idcategory, "25")) {
            child_category = $filter('translate')('karaoke');
        }
        if (angular.equals(idcategory, "26")) {
            child_category = $filter('translate')('games');
        }
        //art
        if (angular.equals(idcategory, "19")) {
            child_category = $filter('translate')('art');
        }
        //beauty
        if (angular.equals(idcategory, "20")) {
            child_category = $filter('translate')('beauty');
        }
        //child beauty
        if (angular.equals(idcategory, "27")) {
            child_category = $filter('translate')('salon');
        }
        if (angular.equals(idcategory, "28")) {
            child_category = $filter('translate')('skin_care');
        }
        if (angular.equals(idcategory, "29")) {
            child_category = $filter('translate')('cosmetic');
        }
        if (angular.equals(idcategory, "30")) {
            child_category = $filter('translate')('spa___treatment');
        }
        //dining
        //fast food
        if (angular.equals(idcategory, "31")) {
            child_category = $filter('translate')('fastfood');
        }
        //japanese
        if (angular.equals(idcategory, "32")) {
            child_category = $filter('translate')('japanese_food');
        }
        //traditional
        if (angular.equals(idcategory, "33")) {
            child_category = $filter('translate')('traditional_food');
        }
        //chinese
        if (angular.equals(idcategory, "34")) {
            child_category = $filter('translate')('chinese_food');
        }
        //western
        if (angular.equals(idcategory, "35")) {
            child_category = $filter('translate')('westren_food');
        }
        //bakery
        if (angular.equals(idcategory, "36")) {
            child_category = $filter('translate')('bakery');
        }
        //cafe
        if (angular.equals(idcategory, "37")) {
            child_category = $filter('translate')('bar_cafe_club');
        }
        //korean
        if (angular.equals(idcategory, "90")) {
            child_category = $filter('translate')('korean_food');
        }
        //oth_dining
        if (angular.equals(idcategory, "38")) {
            child_category = $filter('translate')('others');
        }
        //accomodation
        //hotel
        if (angular.equals(idcategory, "45")) {
            child_category = $filter('translate')('hotel');
        }
        //condominiums
        if (angular.equals(idcategory, "46")) {
            child_category = $filter('translate')('condominiums');
        }
        //apartment
        if (angular.equals(idcategory, "47")) {
            child_category = $filter('translate')('apartment_property');
        }
        //shopping
        //department
        if (angular.equals(idcategory, "48")) {
            child_category = $filter('translate')('deparment_store');
        }
        //mart
        if (angular.equals(idcategory, "49")) {
            child_category = $filter('translate')('mart');
        }
        //child mart
        if (angular.equals(idcategory, "55")) {
            child_category = $filter('translate')('supermarket');
        }
        if (angular.equals(idcategory, "56")) {
            child_category = $filter('translate')('minimarket');
        }
        //fashion
        if (angular.equals(idcategory, "50")) {
            child_category = $filter('translate')('fashion');
        }
        //child fashion
        if (angular.equals(idcategory, "57")) {
            child_category = $filter('translate')('Batik');
        }
        if (angular.equals(idcategory, "58")) {
            child_category = $filter('translate')('clothes');
        }
        if (angular.equals(idcategory, "59")) {
            child_category = $filter('translate')('shoes');
        }
        if (angular.equals(idcategory, "60")) {
            child_category = $filter('translate')('accessories___toys');
        }
        if (angular.equals(idcategory, "61")) {
            child_category = $filter('translate')('sport');
        }
        if (angular.equals(idcategory, "62")) {
            child_category = $filter('translate')('eyewear');
        }
        if (angular.equals(idcategory, "63")) {
            child_category = $filter('translate')('jewelry');
        }
        //home
        if (angular.equals(idcategory, "51")) {
            child_category = $filter('translate')('home_improvement');
        }
        //book
        if (angular.equals(idcategory, "52")) {
            child_category = $filter('translate')('book_stationety');
        }
        //electronic
        if (angular.equals(idcategory, "53")) {
            child_category = $filter('translate')('electronic');
        }
        //automotive
        if (angular.equals(idcategory, "54")) {
            child_category = $filter('translate')('automotive');
        }
        //other
        if (angular.equals(idcategory, "64")) {
            child_category = $filter('translate')('others');
        }
        //education
        if (angular.equals(idcategory, "66")) {
            child_category = $filter('translate')('school');
        }
        if (angular.equals(idcategory, "67")) {
            child_category = $filter('translate')('tutor');
        }
        if (angular.equals(idcategory, "68")) {
            child_category = $filter('translate')('music');
        }
        //health care
        if (angular.equals(idcategory, "70")) {
            child_category = $filter('translate')('health');
        }
        if (angular.equals(idcategory, "71")) {
            child_category = $filter('translate')('hospital');
        }
        //public service
        //property
        if (angular.equals(idcategory, "73")) {
            child_category = $filter('translate')('property_agents');
        }
        //atm
        if (angular.equals(idcategory, "74")) {
            child_category = $filter('translate')('atm_gallery');
        }
        //tour
        if (angular.equals(idcategory, "75")) {
            child_category = $filter('translate')('tour_travel');
        }
        //bank
        if (angular.equals(idcategory, "76")) {
            child_category = $filter('translate')('bank');
        }
        //insurance
        if (angular.equals(idcategory, "77")) {
            child_category = $filter('translate')('insurance');
        }
        //gas
        if (angular.equals(idcategory, "78")) {
            child_category = $filter('translate')('spbu');
        }
        //others
        if (angular.equals(idcategory, "80")) {
            child_category = $filter('translate')('others');
        }
        //workshop
        if (angular.equals(idcategory, "81")) {
            child_category = $filter('translate')('workshop_services');
        }
        //industry
        //DS1
        if (angular.equals(idcategory, "96")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS1";
        }
        //DS2
        if (angular.equals(idcategory, "97")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS2";
        }
        //DS3
        if (angular.equals(idcategory, "98")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS3";
        }
        //DS5
        if (angular.equals(idcategory, "100")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS5";
        }
        //DS6
        if (angular.equals(idcategory, "101")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS6";
        }
        //newton
        if (angular.equals(idcategory, "102")) {
            child_category = $filter('translate')('newton_techno_park');
        }
        //transportation
        if (angular.equals(idcategory, "106")) {
            child_category = $filter('translate')('rental_cars');
        }

        return child_category;
    }
    listTenantHome();
    function listTenantHome() {
        var idcategory = '11,12,13,14'
        TenantService.listTenantHome(idcategory, function (response) {
            var a = 0;
            var tempAcc = [];
            var tempDin = [];
            var tempEnt = [];
            var tempShop = [];
            $scope.tenantDinings = [];
            $scope.tenantEntertainment = [];
            $scope.tenantAccomodations = [];
            $scope.tenantShopping = [];

            angular.forEach(response, function () {
                var b = a++;
                var listTenant = response[b]
                tempDin = listTenant.category12;
                tempEnt = listTenant.category11;
                tempAcc = listTenant.category13;
                tempShop = listTenant.category14;
            })

            var din = 0;
            for (din; din < 4; din++) {
                var dataDin = tempDin[din];
                var imageDin;
                if (dataDin.avatar == null || dataDin.avatar == "") {
                    imageDin = 'img/items/property_add_photo.png'
                } else {
                    imageDin = dataDin.avatar
                }

                $scope.tenantDinings.push({
                    'idcategory': dataDin.idcategory,
                    'categoryname': texcategory(dataDin.idcategory),
                    'level': dataDin.level,
                    'idtenant': dataDin.idtenant,
                    'avatar': imageDin,
                    'tenantsname': dataDin.tenantsname,
                    'address': dataDin.address,
                    'longlat': calculatdistance(dataDin.longlat),
                    'premium': dataDin.premium,
                    'phone': dataDin.phone,
                    'link': dataDin.link,
                    'logo': dataDin.logo,
                    'color': dataDin.color,
                    'rate': parseFloat(dataDin.rate).toFixed(1),
                    'open': dataDin.open,
                    'openhour': dataDin.openhour,
                    'closehour': dataDin.closehour,
                    'bookmarked': dataDin.bookmarked
                });

                if ($scope.tenantDinings == '') {
                    $scope.showDining = false;
                }
            }

            var ent = 0;
            angular.forEach(tempEnt, function () {
                var e = ent++;
                var dataEnt = tempEnt[e];
                var imageEnt;
                if (dataEnt.avatar == null || dataEnt.avatar == "") {
                    imageEnt = 'img/items/property_add_photo.png'
                } else {
                    imageEnt = dataEnt.avatar
                }
                $scope.tenantEntertainment.push({
                    'idcategory': dataEnt.idcategory,
                    'categoryname': texcategory(dataEnt.idcategory),
                    'level': dataEnt.level,
                    'idtenant': dataEnt.idtenant,
                    'avatar': imageEnt,
                    'tenantsname': dataEnt.tenantsname,
                    'address': dataEnt.address,
                    'longlat': calculatdistance(dataEnt.longlat),
                    'premium': dataEnt.premium,
                    'phone': dataEnt.phone,
                    'link': dataEnt.link,
                    'logo': dataEnt.logo,
                    'color': dataEnt.color,
                    'rate': parseFloat(dataEnt.rate).toFixed(1),
                    'open': dataEnt.open,
                    'openhour': dataEnt.openhour,
                    'closehour': dataEnt.closehour,
                    'bookmarked': dataEnt.bookmarked
                });

                if ($scope.tenantEntertainment == '') {
                    $scope.showEntertainment = false;
                }
            })

            var acc = 0;
            angular.forEach(tempAcc, function () {
                var c = acc++;
                var dataAcc = tempAcc[c];
                var imageAcc;
                if (dataAcc.avatar == null || dataAcc.avatar == "") {
                    imageAcc = 'img/items/property_add_photo.png'
                } else {
                    imageAcc = dataAcc.avatar
                }
                $scope.tenantAccomodations.push({
                    'idcategory': dataAcc.idcategory,
                    'categoryname': texcategory(dataAcc.idcategory),
                    'level': dataAcc.level,
                    'idtenant': dataAcc.idtenant,
                    'avatar': imageAcc,
                    'tenantsname': dataAcc.tenantsname,
                    'address': dataAcc.address,
                    'longlat': calculatdistance(dataAcc.longlat),
                    'premium': dataAcc.premium,
                    'phone': dataAcc.phone,
                    'link': dataAcc.link,
                    'logo': dataAcc.logo,
                    'color': dataAcc.color,
                    'rate': parseFloat(dataAcc.rate).toFixed(1),
                    'open': dataAcc.open,
                    'openhour': dataAcc.openhour,
                    'closehour': dataAcc.closehour,
                    'bookmarked': dataAcc.bookmarked
                });

                if ($scope.tenantAccomodations == '') {
                    $scope.showAccomodation = false;
                }
            })

            var shop = 0;
            angular.forEach(tempShop, function () {
                var s = shop++;
                var dataShop = tempShop[s];
                var imageShop;
                if (dataShop.avatar == null || dataShop.avatar == "") {
                    imageShop = 'img/items/property_add_photo.png'
                } else {
                    imageShop = dataShop.avatar
                }
                $scope.tenantShopping.push({
                    'idcategory': dataShop.idcategory,
                    'categoryname': texcategory(dataShop.idcategory),
                    'level': dataShop.level,
                    'idtenant': dataShop.idtenant,
                    'avatar': imageShop,
                    'tenantsname': dataShop.tenantsname,
                    'address': dataShop.address,
                    'longlat': calculatdistance(dataShop.longlat),
                    'premium': dataShop.premium,
                    'phone': dataShop.phone,
                    'link': dataShop.link,
                    'logo': dataShop.logo,
                    'color': dataShop.color,
                    'rate': parseFloat(dataShop.rate).toFixed(1),
                    'open': dataShop.open,
                    'openhour': dataShop.openhour,
                    'closehour': dataShop.closehour,
                    'bookmarked': dataShop.bookmarked
                });

                if ($scope.tenantShopping == '') {
                    $scope.showShopping = false;
                }
            })
        })
    }

    getUserAndPoint();
    function getUserAndPoint(){
        $scope.hasLogin = false;
        if ($localStorage.currentUser) {
            $scope.hasLogin = true;
            $scope.isResident = false;
            $scope.fullNameUser = $localStorage.currentUser.data[0].fullname;
            if ($localStorage.currentUser.data[0].privilege == "resident") {
                $scope.isResident = true;
                if ($localStorage.currentPoint) {
                    $scope.myPoints = $localStorage.currentPoint;
                } else {
                    getMyPoints();
                }
            }
        }
    }

    function getMyPoints(){
        PointService.getMyPoint(function(response){
            if(!$localStorage.currentPoint){
                $localStorage.currentPoint = 0;
            }
            if(response){
                if(response.statusCode == 10){
                    $localStorage.currentPoint = response.mypoint;
                }
            }
        });
    }

    $scope.doRefresh = function () {
        listTenantHome();
        getListCoupon();
        getWhatsNew();
        getUserAndPoint();
        getDataLogin();
        // getUserAndPoint();
        $scope.$broadcast('scroll.refreshComplete');
    }

    getDataLogin();
    function getDataLogin() {
        billingServices.loginBillingServices(email, function (response) {
            if (response) {
                if (response.status) {
                    $scope.dataResident = response.data;
                    $scope.dataSite = response.data.Site;
                    if (response.data.Site.length > 0) {
                        getBillingStatement();
                    }
                }
            } else {
                console.log(response);
            }
        });
    }

    function getBillingStatement() {
        $scope.billingData = true;
        billingServices.getbillingmultiside(email, function (response) {
            if (response) {
                if(response.status == 'success'){
                    var range  = [];
                    $scope.dataMultiSite=[];

                    angular.forEach(response.data['Site'], function (value, key) {
                        $scope.pushed = true;
                        for (var i = 0; i <= range.length; i += 1) {
                            if(value['@attributes'].SiteID==range[i]){
                                $scope.pushed = false;
                            }
                        }
            
                        if($scope.pushed==true){
                            range.push(value['@attributes'].SiteID);
                            $scope.dataMultiSite.push(value);
                        }
                    });

                    $scope.amountpaid = [];
                    $scope.dataMultiSite.forEach(function(obj){
                        $scope.atributeres = obj['@attributes'];
                        if($scope.atributeres.Name) $scope.billingName = $scope.atributeres.Name;
                        if(obj['@attributes'].BillingOutstandingBalance > 0){
                            $scope.amountpaid.push(obj['@attributes'].BillingOutstandingBalance);
                        }
                    })
                }
            } else {
                console.log(response);
            }
            
            // if($scope.amountpaid.length == 0) $scope.billingData = false;
        });
    }

    $scope.detailBillingStatement = detailBillingStatement;
    function detailBillingStatement(site) {
        $scope.titleUnit = site['@attributes'].SiteName;
        $scope.siteID = site['@attributes'].SiteID;
        $scope.billingOutstanding = site['@attributes'].BillingOutstandingBalance;
        $scope.dataDetailBillingStatement = site.Periode;
        $scope.month = site.Periode[0]['@attributes'].Name;
        
        var i = 0;
        $scope.dataDetailBillingStatement.forEach(function (obj, idx) {
            $scope.dataDetailBillingStatement[idx].Unit.forEach(function (obj, idy) {
                $scope.dataDetailBillingStatement[idx].Unit[idy].id = i++;
                var btn_id = $scope.dataDetailBillingStatement[idx].Unit[idy].id;
                $scope['btn_unit_' + btn_id] = false;
            });
            var bulan = $scope.dataDetailBillingStatement[idx]['@attributes'].Name;
                        if(lang=='ina'){
                            bulan = bulan.replace("Januari", "JAN");
                            bulan = bulan.replace("Februari", "FEB");
                            bulan = bulan.replace("Maret", "MAR");
                            bulan = bulan.replace("April", "APR");
                            bulan = bulan.replace("Mei", "MEI");
                            bulan = bulan.replace("Juni", "JUN");
                            bulan = bulan.replace("Juli", "JUL");
                            bulan = bulan.replace("September", "AGU");
                            bulan = bulan.replace("Agustus", "SEP");
                            bulan = bulan.replace("Oktober", "OKT");
                            bulan = bulan.replace("November", "NOV");
                            bulan = bulan.replace("Desember", "DES");
                        }else{
                            bulan = bulan.replace("Januari", "JAN");
                            bulan = bulan.replace("Februari", "FEB");
                            bulan = bulan.replace("Maret", "MAR");
                            bulan = bulan.replace("April", "APR");
                            bulan = bulan.replace("Mei", "MEI");
                            bulan = bulan.replace("Juni", "JUN");
                            bulan = bulan.replace("Juli", "JUL");
                            bulan = bulan.replace("September", "AUG");
                            bulan = bulan.replace("Agustus", "SEP");
                            bulan = bulan.replace("Oktober", "OCT");
                            bulan = bulan.replace("November", "NOV");
                            bulan = bulan.replace("Desember", "DEC");
                        
                        }
                        $scope.dataDetailBillingStatement[idx]['@attributes'].NewName = bulan;
        });

        $ionicModal.fromTemplateUrl('partials/tabs/billing/detailBillingStatementModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.modalMenu = modalMenu;
            $scope.modalMenu.show();
        });
    }

    $scope.varUnitDetails = function (id) {
        return $scope['btn_unit_' + id];
    }

    $scope.showHideUnitDetails = function (id) {
        $scope['btn_unit_' + id] = !$scope['btn_unit_' + id];
    }

    
    $scope.closeModalDetailBilling = function () {
        $scope.modalMenu.remove();
    }

    $scope.payNowBillingDetail = function (siteID) {
        $scope.closeModalDetailBilling();
        $state.go('app.detailPayment', { siteId: siteID });
    }
}
