angular
    .module('livein')
    .controller('gallery', gallery)
    .controller('detailGallery', detailGallery)
    .controller('searchGalleryDetail', searchGalleryDetail)
    .controller('searchGalleryDetailImage', searchGalleryDetailImage);

function gallery($scope, $ionicLoading, $ionicModal, $ionicSlideBoxDelegate, listGallery, $filter, $timeout, $rootScope, $stateParams, $ionicScrollDelegate) {
     // ----- Analytic Screen
     if (window.ga) {
        var analyticView = 'Photo Gallery';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    } 
    // $scope.isFirstLoading = true;
    var i = 0;
    getData();

    $scope.refreshTasks = function () {
        getData();
    };

    function getData() {
        // i++;
        // if (i == 1) {
            $scope.images = [];
        // }
        var pagenumber = 1;
        listGallery.getlistGallery(function (response) {
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            if (response != false) {
                console.log("jmlh: "+response.length);
                for (var i = 0; i < response.length; i++) {
                    var obj_img = response[i];
                    $scope.images.push(obj_img)
                }
            }

            listGallery.getListInstagram(function (response) {
                var data = response.data;
                var a = 0;
                for (var i = 0; i < data.length; i++) {
                    var obj_img = data[i];
                    var avatar = obj_img.images.standard_resolution.url
                    var caption = obj_img.caption;
                    var title = "No Caption";
                    if (caption != null) {
                        title = caption.text;
                    }
                    var picture = $scope.images;

                    if (checkImage(picture, avatar)) {
                        // a++;
                    } else {
                        saveGallery(avatar, title);
                    }
                    // console.log("data is duplicate: "+a);
                }
            });

            console.log("all img: " + $scope.images.length);
            $rootScope.imagesAll = $scope.images;
            $ionicLoading.hide();

            if ($scope.images.length == 0) $scope.images = [{ name: $filter('translate')('there_no_gallery') }];

            // if ($scope.isFirstLoading == true) {
            //     $timeout(function () {
            //         $ionicLoading.hide();
            //     }, 500);
            //     $scope.isFirstLoading = false;
            // }
            $scope.$broadcast('scroll.refreshComplete');

        });
        // $ionicScrollDelegate.resize()
        // $scope.$broadcast('scroll.infiniteScrollComplete');
    }

    function saveGallery(avatar, title) {
        listGallery.saveGallery(
            avatar,
            title,
            function (response) {
                if (response != false) {
                    var obj_img = {
                        'status': true,
                        'avatar': avatar,
                        'title': title
                    }
                    $scope.images.push(obj_img)
                } else {
                    //alert("Failed save image")
                }
            })
    }

    addmodal();

    function addmodal(){
        $ionicModal.fromTemplateUrl('partials/sides/GalleryImage.html', {
            scope: $scope
        }).then(function (modalImage) {
            $scope.modalImage = modalImage;
        });  
    }
    
    

    $scope.openModalImage = function (index) {
        $scope.modalImage.show();
        $scope.result= [];
        angular.forEach($scope.images, function (obj, index) {
            obj['number'] = index + 1;
            $scope.result.push(obj);
        });

        $scope.len = $scope.result.length;
        $scope.activeSlideIdx = index;
    }

    $scope.closeModalImage = function () {
        $scope.modalImage.remove();
        addmodal();
    }

    function checkImage(picture, avatar) {
        for (var i = 0; i < picture.length; i++) {
            if (picture[i].avatar == avatar) {
                return true;
            }
        }
        return false;
    }
}

function detailGallery($scope, $timeout, $ionicLoading, $ionicSlideBoxDelegate, $stateParams, listGallery, $filter, $rootScope) {
    $scope.next = next;
    $scope.previous = previous;
    $scope.loadMore = loadMore;
    // $scope.updateSlider = function () {
    //     $ionicSlideBoxDelegate.update(); //or just return the function
    // }
    var i = 0;
    loadMore();

    function loadMore() {
        i++;
        console.log("i nyaaa: " + i);
        if (i == 1) {
            $scope.image = [];
        }
        var pagenumber = i;

        listGallery.getlistGallery2(pagenumber, function (response) {
            console.log("masuk sini couyyyy");
            // $timeout(function () {
            $scope.gall = $stateParams.index;
            if (response != false) {
                for (i = 0; i < response.length; i++) {
                    var data = response[i];
                    $scope.image.push(data);
                }

                var keys = Object.keys($scope.image);
                $scope.len = keys.length;

                // var i = 1;
                // $scope.image.forEach(function (itemfile, indexfile, arrfile) {
                //     $scope.image[indexfile].number = i++;
                //     // console.log("yoyo: " + $scope.image[indexfile].number)
                // });
                $ionicSlideBoxDelegate.update();
                $ionicLoading.hide();
            } else {
                $ionicLoading.hide();
                $scope.image = [{ name: $filter('translate')('there_no_gallery') }];
            }
            // $ionicSlideBoxDelegate.update();
            // }, 1000);
        });
    }

    function next() {
        $ionicSlideBoxDelegate.next();
        loadMore();
    };

    function previous() {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };
}

function searchGalleryDetail($scope, $ionicModal, $ionicHistory, $timeout, $ionicLoading, $ionicSlideBoxDelegate, $stateParams, listGallery, $filter) {

    $scope.next = next;
    $scope.previous = previous;
    $scope.updateSlider = function () {
        $ionicSlideBoxDelegate.update(); //or just return the function
    }
    $scope.searchval = $stateParams.searchval;
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };
    getSearch();

    function getSearch(){
        listGallery.getSearchGallery($stateParams.name, function (response) {
            $timeout(function () {
                var gall = $stateParams.name;
                if (response != false) {
                    $scope.image = response;
                    var keys = Object.keys($scope.image);
                    $scope.len = keys.length;
    
                    $scope.gall = gall;
                    $ionicSlideBoxDelegate.update();
    
                    var i = 1;
                    $scope.image.forEach(function (itemfile, indexfile, arrfile) {
                        $scope.image[indexfile].number = i++;
                    });
    
                } else {
                    // $scope.image = [{ name: $filter('translate')('there_no_gallery') }];
                    console.log('error');
                }
            }, 1000);
            $ionicLoading.hide();
        });    
    }
    
    function addmodal(){
        $ionicModal.fromTemplateUrl('partials/sides/GalleryImage.html', {
            scope: $scope
        }).then(function (modalImage) {
            $scope.modalImage = modalImage;
       });
    }

    addmodal();
    
    $scope.openModalImage = function (index) {
        
        $scope.modalImage.show();
        $scope.result= [];
        angular.forEach($scope.image, function (obj, index) {
            obj['number'] = index + 1;
            $scope.result.push(obj);
        });

        $scope.len = $scope.result.length;

        $scope.activeSlideIdx = index;
        $ionicSlideBoxDelegate.update(); 
    }

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };

    $scope.closeModalImage = function () {
        $scope.modalImage.remove();
        addmodal();
    }


    function next() {
        $ionicSlideBoxDelegate.next();
    };

    function previous() {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };
}

function searchGalleryDetailImage($scope, $timeout, $ionicLoading, $ionicSlideBoxDelegate, $stateParams, listGallery, $filter) {

    $scope.next = next;
    $scope.previous = previous;
    $scope.updateSlider = function () {
        $ionicSlideBoxDelegate.update(); //or just return the function
    }
    $scope.searchval = $stateParams.searchval;
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    listGallery.getSearchGallery($stateParams.gall, function (response) {
        $timeout(function () {
            var gall = $stateParams.index;
            if (response != false) {
                $scope.image = response;
                var keys = Object.keys($scope.image);
                $scope.len = keys.length;

                $scope.gall = gall;
                $ionicSlideBoxDelegate.update();

                var i = 1;
                $scope.image.forEach(function (itemfile, indexfile, arrfile) {
                    $scope.image[indexfile].number = i++;
                });

            } else {
                $scope.image = [{ name: $filter('translate')('there_no_gallery') }];
                console.log('error');
            }
        }, 1000);
        $ionicLoading.hide();
    });

    function next() {
        $ionicSlideBoxDelegate.next();
    };

    function previous() {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };
}
