angular
    .module('livein')
    .controller('whatsNew', whatsNew)
    .controller('whatsNewDetail', whatsNewDetail);

function whatsNew($scope, $rootScope, $state, $sce, $localStorage, $ionicLoading, $ionicModal, dataWhatsNew, $filter, $ionicSlideBoxDelegate, AdvertisementService) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    $scope.adsList = [];
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Getting to Know';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    $scope.hahaha = $sce.trustAsResourceUrl($filter('translate')('apilinkliveinweb') + 'assets/file/cctv/cctv1.mp4');

    this.config = {
        sources: [
            { src: $sce.trustAsResourceUrl("http://static.videogular.com/assets/videos/videogular.mp4"), type: "video/mp4" },
            { src: $sce.trustAsResourceUrl("http://static.videogular.com/assets/videos/videogular.webm"), type: "video/webm" },
            { src: $sce.trustAsResourceUrl("http://static.videogular.com/assets/videos/videogular.ogg"), type: "video/ogg" }
        ],
        tracks: [
            {
                src: "http://www.videogular.com/assets/subs/pale-blue-dot.vtt",
                kind: "subtitles",
                srclang: "en",
                label: "English",
                default: ""
            }
        ],
        theme: "bower_components/videogular-themes-default/videogular.css",
        plugins: {
            poster: "http://www.videogular.com/assets/images/videogular.png"
        }
    };

    // video.addSource('mp4', $filter('translate')('apilinkliveinweb') + 'assets/file/cctv/cctv1.mp4');

    // var taek = document.getElementById('video_taek');
    // taek.setAttribute("playsinline","");

    $scope.doRefresh = function () {
        listWhatNew();
        $scope.$broadcast('scroll.refreshComplete');
    }

    $scope.gotoAdsDetail = function(dataAds){
        $state.go("app.adsDetail", { idAds: dataAds[0].id });
    }
    
    $rootScope.searchWhatsNew = function(){
        if($rootScope.search_page){
            $scope.keyword = $rootScope.search_page;
            $scope.isSearch = true;
            listSearchWhatsNew();
        }else{           
            $scope.keyword = ""; 
            $scope.isSearch = false;
            listWhatNew();
        }
    }

    function listSearchWhatsNew(){
        var pagenumber = 1;
        var pagesize = 8; 
        $scope.whatsnew = [];
        $scope.loadMoreSearchWhatsNew = function(){
            dataWhatsNew.searchingNews(pagenumber, pagesize, $rootScope.search_page, lang, function(response){
                if (response != false) {
                    pagenumber++;
                    $scope.data = response;
                    $scope.showText = false;
                    var a = 0;
                    angular.forEach($scope.data, function (obj) { 
                        var b = a++;
                        var list = $scope.data;
                        var data = list[b];

                        var status = data.status;
                        var idnews = data.idnews;
                        var description = data.description;
                        var descnew = description.substr(3, 200);
                        var gallery = data.gallery;

                        if (data.createdate != null) {
                            var d = new Date(data.createdate.replace(' ', 'T'));
                            var createdate = new Date(d);
                        } else {
                            var createdate = null;
                        }

                        var title = data.title;
                        var avatar;
                        if (data.avatar == null || data.avatar == "" || data.avatar == undefined) {
                            avatar = 'img/items/property_add_photo.png';
                        } else {
                            avatar = data.avatar;
                        }

                        $scope.whatsnew.push({
                            'status': status,
                            'idnews': idnews,
                            'descnew': descnew,
                            'description': description,
                            'gallery': gallery,
                            'title': title,
                            'createdate': createdate,
                            'avatar': avatar
                        });
                    });
                } else {
                    if($scope.whatsnew.length < 0){
                        $scope.showText = true;
                        $scope.hideSkeleton=true;
                        $scope.data = [{ name: $filter('translate')('no_user') }];
                    }
                }

                listAds(pagenumber);
                $ionicLoading.hide();
                $scope.$broadcast('scroll.refreshComplete');
                $scope.$broadcast('scroll.infiniteScrollComplete');

            });
        }
        $scope.loadMoreSearchWhatsNew();
    }

    $scope.loadMore = function(){    
        if ($scope.isSearch){
            $scope.loadMoreSearchWhatsNew();
        } else{
            $scope.loadMoreWhatsNew();
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
    }

    function listAds(pagenumberAds){
        var idtype = 3;
        var pagesize;
        
        if($scope.whatsnew.length == 0) pagesize = 1;
        else pagesize = 2;
        
        AdvertisementService.getAdsbyFilter(idtype, pagenumberAds, pagesize, $scope.keyword, "", function(response){
            if(response.status != false){
                var a = 0;
                angular.forEach(response, function (obj) { 
                    var b = a++;
                    var data = response[b];
                    $scope.adsList.push({
                        id: data.id,
                        idadstype: data.idadstype,
                        image: data.image,
                        title: data.title,
                        title_id: data.title_id,
                        validfrom: data.validfrom,
                        validuntil: data.validuntil
                    })
                })
            }
        })
    }

    listWhatNew();
    function listWhatNew() {
        $scope.keyword = ""; 
        var pagenumber = 1;
        $scope.whatsnew = [];
        $scope.adsList = [];
        $scope.loadMoreWhatsNew = function(){
            dataWhatsNew.getDataWhatsNewSide(pagenumber, lang, function (response) {
                if (response != false) {
                    pagenumber++;
                    $scope.data = response;
                    $scope.showText = false;
                    var a = 0;
                    angular.forEach($scope.data, function (obj) { 
                        var b = a++;
                        var list = $scope.data;
                        var data = list[b];

                        var status = data.status;
                        var idnews = data.idnews;
                        var description = data.description;
                        var descnew = description.substr(3, 200);
                        var gallery = data.gallery;

                        if (data.createdate != null) {
                            var d = new Date(data.createdate.replace(' ', 'T'));
                            var createdate = new Date(d);
                        } else {
                            var createdate = null;
                        }

                        var title = data.title;
                        var avatar;
                        if (data.avatar == null || data.avatar == "" || data.avatar == undefined) {
                            avatar = 'img/items/property_add_photo.png';
                        } else {
                            avatar = data.avatar;
                        }

                        $scope.whatsnew.push({
                            'status': status,
                            'idnews': idnews,
                            'descnew': descnew,
                            'description': description,
                            'gallery': gallery,
                            'title': title,
                            'createdate': createdate,
                            'avatar': avatar
                        });
                    });
                } else {
                    if($scope.whatsnew.length < 0){
                        $scope.showText = true;
                        $scope.hideSkeleton=true;
                        $scope.data = [{ name: $filter('translate')('no_user') }];
                    }
                }

                listAds(pagenumber);
                $ionicLoading.hide();
                $scope.$broadcast('scroll.refreshComplete');
                $scope.$broadcast('scroll.infiniteScrollComplete');

            });
        }
        $scope.loadMoreWhatsNew();
    }

    $ionicModal.fromTemplateUrl('partials/sides/whatsNewModal.html', {
        scope: $scope
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (list) {
        $scope.list = list;

        for (var i = 0; i < $scope.list.gallery.length; i++) {
            var obj_gal = $scope.list.gallery[i];
            if (obj_gal.type == 2) {
                if (obj_gal.avatar) {
                    var ava = obj_gal.avatar;
                    var source = [{
                        src: $sce.trustAsResourceUrl(obj_gal.avatar),
                        type: 'video/' + ava.substring(ava.length - 3)
                    }]
                    obj_gal.sources = source;
                }
            } else if (obj_gal.type == 3) {
                obj_gal.urly = $sce.trustAsResourceUrl(obj_gal.link_youtube)
            }

        }
        $scope.config = {
            preload: "none",
            tracks: [
                {
                    src: "http://www.videogular.com/assets/subs/pale-blue-dot.vtt",
                    kind: "subtitles",
                    srclang: "en",
                    label: "English",
                    default: ""
                }
            ],
            theme: {
                url: "https://unpkg.com/videogular@2.1.2/dist/themes/default/videogular.css"
            }
        };

        if (list.gallery == '' | list.gallery.length == 0) {
            $scope.showGallery = false;
        } else {
            $scope.showGallery = true;
            $scope.gallery = list.gallery;
        }
        $scope.modal.show();
    };

    $scope.closeModalSlider = function () {
        $scope.modal.hide();

    };

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hide', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });
    $scope.$on('modal.shown', function () {
        console.log('Modal is shown!');
    });

}

function whatsNewDetail($scope, $sce, $state, $localStorage, $ionicHistory, $ionicLoading, $stateParams, dataWhatsNew, $filter, $ionicSlideBoxDelegate, AdvertisementService) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Getting to Know Detail';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    dataWhatsNew.retriveGetNews(lang, $stateParams.idnews, function (response) {
        if (response != false) {
            $scope.detail = response.detail[0];
            $scope.gallery = response.gallery[0];
            $scope.list = response;

            if (response.detail[0].createdate != null) {
                var d = new Date(response.detail[0].createdate.replace(' ', 'T'));
                var createdate = new Date(d);
            } else {
                var createdate = null;
            }
            $scope.createdate = createdate;

            for (var i = 0; i < $scope.list.gallery.length; i++) {
                var obj_gal = $scope.list.gallery[i];
                if (obj_gal.type == 2) {
                    if (obj_gal.avatar) {
                        var ava = obj_gal.avatar;
                        var source = [{
                            src: $sce.trustAsResourceUrl(obj_gal.avatar),
                            type: 'video/' + ava.substring(ava.length - 3)
                        }]
                        obj_gal.sources = source;
                    }
                } else if (obj_gal.type == 3) {
                    obj_gal.urly = $sce.trustAsResourceUrl(obj_gal.link_youtube)
                }

            }

            if (response.gallery == '' | response.gallery.length == 0) {
                $scope.showGallery = false;
            } else {
                $scope.showGallery = true;
                $scope.gallery = response.gallery;
            }


            $ionicLoading.hide();
        } else {

            $ionicLoading.hide();
        }
    });
    $scope.adsList = [];
    // integrasi small ads
    var idtype = 1;
    var pagenumber = 1;
    var pagesize = 1;
    AdvertisementService.getAdsbyFilter(idtype, pagenumber, pagesize, "", "", function(response){
        if(response.status != false){
            $scope.imgAds = response[0].image;
            var data = response[0];
            $scope.adsList.push({
                id: data.id,
                idadstype: data.idadstype,
                image: data.image,
                title: data.title,
                title_id: data.title_id,
                validfrom: data.validfrom,
                validuntil: data.validuntil
            })
        }
    })

    $scope.gotoAdsDetail = function(dataAds){
        $state.go("app.adsDetail", { idAds: dataAds[0].id });
    }
}