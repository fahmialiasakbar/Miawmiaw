angular
  .module('livein')
  .controller('coupon', coupon)
  .controller('detailCoupon', detailCoupon)
  .controller('worldclock', worldclock)

function coupon($scope, CouponService, $ionicLoading, $filter) {
  $scope.data;
  $scope.dataExist=true;
  $scope.fake=[1,2,3,4];
  
  // ----- Analytic Screen
  if (window.ga) {
    var analyticView = 'Discount Coupon List';
    window.ga.trackView(analyticView);
    window.ga.trackEvent('Screen View', analyticView);
    console.log("Analytic - Screen View - " + analyticView);
  }
  $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });

  CouponService.listCoupon(function (response) {
    if (response != false) {
      $scope.data = response;
    } else {
      $scope.dataExist=false;
      $scope.data = { name: $filter('translate')('no_user') };
    }
    $ionicLoading.hide();
  });

}

function detailCoupon($scope, $timeout, $stateParams, $ionicSlideBoxDelegate, $ionicHistory, PropertyService,
  $ionicLoading, $filter, $localStorage, $ionicModal, CouponService) {
  // ----- Analytic Screen
  if (window.ga) {
    var analyticView = 'Discount Coupon Detail';
    window.ga.trackView(analyticView);
    window.ga.trackEvent('Screen View', analyticView);
    console.log("Analytic - Screen View - " + analyticView);
  }
  $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });

  var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

  $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
    viewData.enableBack = true;
  });

  CouponService.retrieveGetCoupon($stateParams.idtenant, function (response) {
    if (response != false) {
      for (var i = 0; i < response.length; i++) {
        if (response[i].iddiscountcoupon == $stateParams.idcoupon) {
          $scope.data = response[i];
        }
      }
    } else {
      $scope.data = { name: $filter('translate')('no_user') };
    }
    $ionicLoading.hide();
  });

  $scope.downloadDiscountCoupon = function (fileurl) {
    if (fileurl) {
      window.open(fileurl, "_system", "location=yes,enableViewportScale=yes,hidden=no");
    } else {
      $ionicPopup.alert({
        template: $filter('translate')('no_file_download'),
        okText: $filter('translate')('okay'),
        cssClass: "alertPopup"
      })

    }
  }

  $scope.myGoBack = function () {
    $ionicHistory.goBack();
  };
}

function worldclock($scope, $ionicLoading, $filter) {
  // ----- Analytic Screen
  if (window.ga) {
    var analyticView = 'World Clock';
    window.ga.trackView(analyticView);
    window.ga.trackEvent('Screen View', analyticView);
    console.log("Analytic - Screen View - " + analyticView);
  }
  $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
  $ionicLoading.hide();
  $scope.gmtValue = 7;

  $scope.data = [{
    "city": "Lippo Cikarang",
    "timezone": "Asia/Jakarta",
    "gmtvalue": "7"
  }, {
    "city": "Tokyo",
    "timezone": "Asia/Tokyo",
    "gmtvalue": "9"
  }, {
    "city": "Seoul",
    "timezone": "Asia/Seoul",
    "gmtvalue": "9"
  }, {
    "city": "Sydney",
    "timezone": "Australia/Sydney",
    "gmtvalue": "10"
  }, {
    "city": "Amsterdam",
    "timezone": "Europe/Amsterdam",
    "gmtvalue": "1"
  }, {
    "city": "Prague",
    "timezone": "Europe/Prague",
    "gmtvalue": "1"
  }]
}
