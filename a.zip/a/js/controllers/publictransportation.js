angular
    .module('livein')
    .controller('publictransportation', publictransportation)

function publictransportation($scope, $state, $stateParams, $window, publictransportationService, $ionicLoading, $ionicPopup, $filter) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Public Transportion';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    listpublictransportation();

    function listpublictransportation() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
        publictransportationService.listpublictransport(function (response) {
            if (response != false) {
                $scope.data = response;
            } else {
                $scope.data = [{ name: $filter('translate')('no_data') }];
            }
            $ionicLoading.hide();
        });
    };

}