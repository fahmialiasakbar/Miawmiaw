angular
    .module('livein')
    .controller('profile', profile)
    .controller('notification', notification)
    .controller('notificationDetail', notificationDetail)
    .controller('editProfile', editProfile)
    .controller('history', history)
    .controller('myhistory', myhistory)
    .filter('elapsed', elapsed);

function elapsed() {
    return function (date) {
        if (!date) return;

        var time = Date.parse(date.replace(' ', 'T'));
        timeNow = new Date().getTime();
        difference = timeNow - time;
        seconds = Math.floor(difference / 1000);
        minutes = Math.floor(seconds / 60);
        hours = Math.floor(minutes / 60);
        days = Math.floor(hours / 24);

        if (days > 1)
            return days + " days";

        if (hours > 1)
            return hours + " h";

        if (minutes > 1)
            return minutes + " m";

        return "a few seconds ago";

    }
}

function profile($scope, $sce, $ionicModal, $timeout, $rootScope, $state, $localStorage, $filter, $ionicPopup, $ionicLoading, LoginService, Notification, ProfileService, $window) {
    $scope.fullname = $localStorage.currentUser.data[0].fullname;
    $scope.email = $localStorage.currentUser.data[0].email;
    $scope.logoutConfirm = logoutConfirm;
    $scope.showNotification = false;
    $scope.privilege = $localStorage.currentUser.data[0].privilege;

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'My Profile';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }


    if ($localStorage.currentUser != null) {
    } else{
        $state.go('login');
    }

    $scope.helpFeedback = function () {
          
        if (device.platform === 'iOS') {
            $window.open('https://itunes.apple.com/id/app/lippo-cikarang/id1191438061?mt=8', '_system', 'location=yes');
        } else {
            window.open('https://play.google.com/store/apps/details?id=lippocikarang.com', '_system', 'location=no');
        }
        console.log('help and feedback clicked');
        // ----- Analytic Screen
        if (window.ga) {
            var analyticView = 'Help And Feed Back';
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Screen View', analyticView);
            console.log("Analytic - Screen View - " + analyticView);
        }
    }

    Notification.countUnreadNotif(function (response) {
        if(window.hasOwnProperty('cordova')){
            cordova.plugins.notification.badge.set(response);
        }
    });

    countnotif();

    $scope.cb = [];
    console.log($scope.cb);
    function countnotif() {
        Notification.totalnotif(
            function (response) {
                if (response != false) {
                    $scope.listnotifUser = response;
                    $scope.listnotif = [];

                    var a = 0;
                    angular.forEach($scope.listnotifUser, function (obj) {
                        var b = a++;
                        var list = $scope.listnotifUser;
                        var data = list[b];
                        var isread = data.isread;

                        if (isread === 'f') {
                            $scope.listnotif.push({
                                'isread': isread
                            });
                        }
                    });

                    if ($scope.listnotif.length === 0) {
                        $scope.showNotification = false;
                        $scope.cb.push(0);
                    } else {
                        $scope.countnotif = $scope.listnotif.length;
                        $scope.showNotification = true;

                        var cn = $scope.listnotif.length;
                        $scope.cb.push(cn);
                    }
                } else {
                    $scope.listnotifUser = { name: $filter('translate')('failed_get_data') };
                    $scope.showNotification = false;
                    $scope.cb.push(0);
                }
                $ionicLoading.hide();
            });

        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');


        if ($scope.lang == 'ina') {
            tentangLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/tentang_in.html";
            privacyLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/kebijakan_privasi_in.html";
            ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_in.html";
        } else {
            tentangLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/tentang_en.html";
            privacyLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/kebijakan_privasi_en.html";
            ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_en.html";
        }

        $scope.privacyLink = $sce.trustAsResourceUrl(privacyLink);
        $scope.tentangLink = $sce.trustAsResourceUrl(tentangLink);
        $scope.ketentuanLink = $sce.trustAsResourceUrl(ketentuanLink);

        $ionicModal.fromTemplateUrl('partials/sides/modalPrivacy.html', {
            scope: $scope
        }).then(function (modalHelp) {
            $scope.modalHelp = modalHelp;
        });

        $scope.openPrivacy = function () {
            $scope.modalHelp.show();
        };

        $ionicModal.fromTemplateUrl('partials/sides/modalTerms.html', {
            scope: $scope
        }).then(function (modalTerms) {
            $scope.modalTerms = modalTerms;
        });

        $scope.openTerms = function () {
            $scope.modalTerms.show();
        };

        $scope.closeModal = function () {
            $scope.modalHelp.hide();
            $scope.modalTerms.hide();
        };

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modalHelp.remove();
            $scope.modalTerms.remove();
        });

    }

    retrievegetaccount();

    function retrievegetaccount() {
        ProfileService.retrievegetaccount(
            function (response) {
                if (response != false) {
                    var account = response.account;
                    var arrayLength = account.length;
                    for (var i = 0; i < arrayLength; i++) {
                        $scope.avatar = account[i].avatar;
                    }
                } else {
                    $scope.dataaccount = { name: $filter('translate')('failed_get_data') };
                }
            });

    }

    function logoutConfirm() {
        var confirmPopup = $ionicPopup.confirm({
            template: $filter('translate')('dialog_signout'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                LoginService.logoutUser();
                $rootScope.buttonDisabled = false;
                $ionicLoading.show({ template: $filter('translate')('logoutmessage') + "...", duration: 500 });
                window.plugins.googleplus.logout(
                    function (msg) {
                        window.plugins.googleplus.disconnect(
                            function (msg) {

                            }
                        );
                    }
                );

                $state.go('login');
            }

        });
    }
}

function notification($scope, $stateParams, $ionicLoading, $location, $state, Notification, $ionicPopup, $filter, $window, $localStorage, $ionicListDelegate) {
    $scope.insertbookmarknotif = insertbookmarknotif;
    $scope.deletebookmarknotif = deletebookmarknotif;

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'My Notification';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    Notification.countUnreadNotif(function (response) {
        if(window.hasOwnProperty('cordova')){
            cordova.plugins.notification.badge.set(response);
        }
    });

    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    $scope.tab1 = false;
    $scope.tab2 = false;
 
    tabClickedFunc(1);
    $scope.tabClicked = tabClickedFunc;
    function tabClickedFunc(tab) {
        if (tab == 1) {
            $scope.tab1 = true;
            $scope.tab2 = false;
        } else if (tab == 2) {
            $scope.tab1 = false;
            $scope.tab2 = true;
        }
    }
    $scope.doRefresh = function(){
        if($scope.loadAll) $scope.loadNotif(); // have already loaded all data
        else listnotifService();
        $scope.$broadcast('scroll.refreshComplete');
    } 
    listnotifService();
    function listnotifService() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        $scope.listnotifUser = [];
        $scope.listnotifUnread = [];

        var pagenumber = 1;

        Notification.listnotif(lang, pagenumber, function (response) {
            if (response != false) {
                if(response[0].status == false){
                    $scope.listnotifUser = { name: $filter('translate')('failed_get_data') };
                }else{
                    $scope.loadAll = false;
                    $scope.listnotifUser = response;
                    console.log($scope.listnotifUser)
    
                    // list unread
                    var r=0;
                    angular.forEach(response, function(){
                        var t = r++;
                        var unread = response[t].isread
                        if(unread != 't'){
                            $scope.listnotifUnread = response;
                        }
                    })
    
                    var i = 2;
                    var a = 0;
                    $scope.loadNotif = function () {
                        $scope.loadAll = true;
                        pagenumber = i;
                        Notification.listnotif(lang, pagenumber, function (response) {
                            if (response[a]) {
                                if(response[a].idnotif){
                                    $scope.listnotifUser = $scope.listnotifUser.concat(response);
                                    
                                    // list unread
                                    var unread = response[a].isread
                                    if(unread != 't'){
                                        $scope.listnotifUnread = $scope.listnotifUnread.concat(response);
                                    }
                                }
                            } 
                        });

                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        i++;
                        a++;
                    };
                }
            } else {
                $scope.listnotifUser = { name: $filter('translate')('failed_get_data') };
            }
            $ionicLoading.hide();
        });
    };

    function insertbookmarknotif(idnotif) {
        Notification.insertBookmarkNotif(
            idnotif,
            function (response) {
                if (response != false) {
                    $ionicLoading.show({
                        template: $filter('translate')('success_favorite'),
                        duration: 5000
                    });
                    listnotifService();
                } else {
                    $ionicLoading.show({
                        template: $filter('translate')('failed_favorite'),
                        duration: 5000
                    });
                    listnotifService();
                }
                $ionicLoading.hide();
            });
    };

    function deletebookmarknotif(idnotifbookmark) {
        Notification.deleteBookmarkNotif(
            idnotifbookmark,
            function (response) {
                if (response != false) {
                    $ionicLoading.show({
                        template: $filter('translate')('remove_favorite_success'),
                        duration: 5000
                    });
                    listnotifService();
                } else {
                    $ionicLoading.show({
                        template: $filter('translate')('remove_favorite_failed'),
                        duration: 5000
                    });
                    listnotifService();
                }
                $ionicLoading.hide();
            });
    };

    var initial_state = false;
    $scope.show = initial_state;

    // toggle value
    $scope.showFooter = function () {
        $scope.show = !$scope.show;
    }

    $scope.delete = function (idnotif) {
        Notification.deleteNotif(idnotif, function (response) {
            if (response != false) {
                $ionicLoading.show({
                    template: $filter('translate')('msg_deleted'),
                    duration: 5000
                });
                listnotifService();
            } else {
                $ionicLoading.show({
                    template: $filter('translate')('msg_delete_failed'),
                    duration: 5000
                });
                listnotifService();
            }
        });

        // var p = [];
        // var results = [];
        // var a = 0;

        // for (var i = 0; i < $scope.listnotifUser.length; i++) {
        //     var item = $scope.listnotifUser[i];
        //     if (item.checked) {
        //         p.push(item)
        //     }
        // }
        // $scope.selectedItems = p;

        // angular.forEach($scope.selectedItems, function (obj) {
        //     var b = a++;
        //     var data = $scope.selectedItems;
        //     var dat = data[b];
        //     var ll = dat.idnotif;

        //     results = dat.idnotif;
        //     $scope.idku = results;

        //     Notification.deleteNotif(results, function (response) {
        //         if (response != false) {
        //             $ionicLoading.show({
        //                 template: $filter('translate')('msg_deleted'),
        //                 duration: 5000
        //             });
        //             listnotifService();
        //         } else {
        //             $ionicLoading.show({
        //                 template: $filter('translate')('msg_delete_failed'),
        //                 duration: 5000
        //             });
        //             listnotifService();
        //         }
        //     });
        // })
        $ionicListDelegate.closeOptionButtons();
    }

    $scope.readed = function (idnotif) {
        Notification.updateNotif(idnotif, function (response) {
            if (response != false) {
                $ionicLoading.show({
                    template: $filter('translate')('msg_marked'),
                    duration: 5000
                });
                listnotifService();
            } else {
                $ionicLoading.show({
                    template: $filter('translate')('msg_update_failed'),
                    duration: 5000
                });
                listnotifService();
            }
        });

        // var p = [];
        // var results = [];
        // var a = 0;
        // for (var i = 0; i < $scope.listnotifUser.length; i++) {
        //     var item = $scope.listnotifUser[i];
        //     if (item.checked) {
        //         p.push(item)
        //     }
        // }
        // $scope.selectedItems = p;

        // angular.forEach($scope.selectedItems, function (obj) {
        //     var b = a++;
        //     var data = $scope.selectedItems;
        //     var dat = data[b];
        //     var ll = dat.idnotif;

        //     results = dat.idnotif;
        //     $scope.idku = results;

        //     Notification.updateNotif(results, function (response) {
        //         if (response != false) {
        //             $ionicLoading.show({
        //                 template: $filter('translate')('msg_marked'),
        //                 duration: 5000
        //             });
        //             listnotifService();
        //         } else {
        //             $ionicLoading.show({
        //                 template: $filter('translate')('msg_update_failed'),
        //                 duration: 5000
        //             });
        //             listnotifService();
        //         }
        //     });
        // })
        $ionicListDelegate.closeOptionButtons();
    }
}

function notificationDetail($scope, $stateParams, $ionicLoading, $location, $state, Notification, $ionicPopup, $ionicHistory, $filter) {
    $scope.goBack = function () {
        $state.go('app.notification');
    };

    Notification.countUnreadNotif(function (response) {
        if(window.hasOwnProperty('cordova')){
            cordova.plugins.notification.badge.set(response);
        }
    });
    // Notification.listnotif(function (response) {
    //     if (response != false) {
    //         $scope.results = [];
    //         $scope.notif = response;

    //         var a = 0;
    //         angular.forEach($scope.notif, function (obj) {
    //             var b = a++;
    //             var list = $scope.notif;
    //             var data = list[b];
    //             var ll = data.idnotif;

    //             if (ll == $stateParams.idnotif) {
    //                 $scope.results.push(list[b]);
    //             }
    //         })

    //     } else {
    //         $.data = { name: $filter('translate')('failed_get_data') };
    //     }

    // });

    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    Notification.detailNotif(lang, function (response) {
        if (response != false) {
            $scope.details = response.notif;
            $scope.bookmarked = $stateParams.bookmarked;
        } else {
            $.data = { name: $filter('translate')('failed_get_data') };
        }

    });
}

function editProfile($scope, $ionicLoading, $location, $state, EditProfileService, ProfileService, $localStorage,
    $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice, $ionicPopup, $cordovaActionSheet, $filter) {
    $scope.saveEditProfile = saveEditProfile;
    $scope.upgradeResident = upgradeResident;
    $scope.isRead = true;
    $scope.isEdit1 = true;

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Edit Profile';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    $scope.ShowRead = function () {
        //If DIV is hidden it will be visible and vice versa.
        $scope.isRead = $scope.isRead ? false : true;
    };

    $scope.ShowEdit = function () {
        //If DIV is hidden it will be visible and vice versa.
        $scope.isEdit1 = $scope.isEdit1 ? false : true;
    };

    dataProfile();

    function dataProfile() {
        //$ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        ProfileService.retrievegetaccount(
            function (response) {
                if (response != false) {
                    $scope.dataaccount = response.account;
                    $scope.account = [];

                    var a = 0;
                    angular.forEach($scope.dataaccount, function (obj) {
                        var b = a++;
                        var list = $scope.dataaccount;
                        var data = list[b];

                        var address = data.address;
                        var avatar = data.avatar;
                        var createdate = data.createdate;
                        var dateofbirth = data.dateofbirth;
                        var email = data.email;
                        var fullname = data.fullname;
                        var gender = data.gender;
                        var idaccount = data.idaccount;
                        var privilege = data.privilege;
                        console.log("ini " + privilege)
                        var pscode = data.pscode;

                        if (data.phone == null) {
                            var phone = "";
                        } else {
                            var phone = data.phone;
                        }

                        $scope.account.push({
                            'address': address,
                            'avatar': avatar,
                            'createdate': createdate,
                            'dateofbirth': dateofbirth,
                            'email': email,
                            'fullname': fullname,
                            'gender': gender,
                            'idaccount': idaccount,
                            'privilege': privilege,
                            'pscode': pscode,
                            'phone': phone
                        });
                    });
                } else {
                    $scope.dataaccount = { name: $filter('translate')('failed_get_data') };
                    console.log("error yahhh");

                }
            });
        $ionicLoading.hide();
    }

    $scope.image = null;

    function saveEditProfile(user) {
        var filename = $scope.image; // File name only
        var dataEditProfile = user[0];

        if (!dataEditProfile.fullname || !dataEditProfile.phone) {
            var title = "";
            if (!dataEditProfile.fullname) {
                title = $filter('translate')('name') + " " + $filter('translate')('not_empty');
            } else if (!dataEditProfile.phone) {
                title = $filter('translate')('phone') + " " + $filter('translate')('not_empty');
            }
            $ionicPopup.alert({
                template: title,
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });
            return false; 
        }

        if (!(dataEditProfile.phone.toString().length >= 8 && dataEditProfile.phone.toString().length <= 14)) {
            $ionicPopup.alert({
                template: $filter('translate')('phone_validation'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });
            return false;
        }


        var nameFormat = /[!@#$%^&*()_+\-=\[\]{};:"\\|,.<>\/?]+/;
        var phoneFormat = /^(?:(?:\(?(?:00|\+)([1-4]\d\d|[1-9]\d?)\)?)?[\-\.\ \\\/]?)?((?:\(?\d{1,}\)?[\-\.\ \\\/]?){0,})(?:[\-\.\ \\\/]?(?:#|ext\.?|extension|x)[\-\.\ \\\/]?(\d+))?$/i;

        if (nameFormat.test(dataEditProfile.fullname) || !phoneFormat.test(dataEditProfile.phone)) {
            var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('msg_update_failed'),
                template: $filter('translate')('cbe_check'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });
            return false;
        }

        if (dataEditProfile.dateofbirth == null || dataEditProfile.dateofbirth == undefined) {
            dataEditProfile.dateofbirth = '';
        }
        
        if (filename === null) {
            var avatarupdate = dataEditProfile.avatar;
            saveEditProfile();
        } else {
            var url = encodeURI($filter('translate')('apilinkliveinweb') + "assets/img/upload_file_avatar.php");
            var targetPath = $scope.pathForImage($scope.image); // File for Upload

            var options = {
                fileKey: "file",
                fileName: filename,
                chunkedMode: false,
                mimeType: "multipart/form-data",
                params: { 'fileName': filename }
            };

            var avatarupdate = $filter('translate')('apilinkliveinweb') + "assets/img/account/" + filename;
        
            console.log(url);
            console.log(targetPath);
            console.log(options);

            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            $cordovaFileTransfer.upload(url, targetPath, options)
                .then(function (result) {
                    console.log("Image upload finished");
                    var response = JSON.parse(result.response);
                    console.log("response image upload")
                    console.log(result)
                    $ionicLoading.hide();
                    if(response[0].status == 'success'){
                        saveEditProfile();
                    }else{ 
                        $ionicPopup.alert({
                            title: $filter('translate')('msg_update_failed'),
                            template: response[0].message,
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                    }
                }, function (response) {
                    // $scope.showAlert('Success', 'Image upload finished.');
                    console.log("Image upload failed finished");
                    console.log(response);
                    $ionicLoading.hide();
                    $ionicPopup.alert({
                        title: $filter('translate')('msg_update_failed'),
                        template: $filter('translate')('error_upload_image'),
                        okText: $filter('translate')('okay'),
                        okType: "button-stable",
                        cssClass: "alertPopup"
                    });
                });
            }

        function saveEditProfile(){
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            EditProfileService.editprofile(
                dataEditProfile.idaccount,
                dataEditProfile.gender,
                dataEditProfile.phone,
                dataEditProfile.dateofbirth,
                dataEditProfile.fullname,
                dataEditProfile.address,
                avatarupdate,
                dataEditProfile.pscode,
                dataEditProfile.privilege,
                dataEditProfile.password,
                dataEditProfile.email,
                function (response) {
                    if (response != false) {
                        var message = response.message;
                        if(localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina'){
                            message = response.message_id;
                        }
                        if(response.status){
                            $localStorage.currentUser.data[0].fullname = dataEditProfile.fullname;
                            $localStorage.currentUser.data[0].gender = dataEditProfile.gender;
                            $localStorage.currentUser.data[0].address = dataEditProfile.address;
                            $localStorage.currentUser.data[0].phone = dataEditProfile.phone;
                        }
                        $ionicPopup.alert({
                            title: $filter('translate')('msg_update'),
                            template: message,
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                        dataProfile();
                        $ionicLoading.hide();
                    } else {
                        $ionicPopup.alert({
                            title: $filter('translate')('msg_update'),
                            template: $filter('translate')('msg_update_failed'),
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                        dataProfile();
                        $ionicLoading.hide();
                    }
                });
        }

    }

    function upgradeResident(data) {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        var dataUpgradeProfile = data;
        ProfileService.upgradeToResident(
            dataUpgradeProfile.email,
            function (response) {
                if (response.status) {
                    var psCode = response.data['@attributes'].PSCode;
                    
                    if (dataUpgradeProfile.dateofbirth == null || dataUpgradeProfile.dateofbirth == undefined) {
                        dataUpgradeProfile.dateofbirth = '';
                    }
                    EditProfileService.editprofile(
                        dataUpgradeProfile.idaccount,
                        dataUpgradeProfile.gender,
                        dataUpgradeProfile.phone,
                        dataUpgradeProfile.dateofbirth,
                        dataUpgradeProfile.fullname,
                        dataUpgradeProfile.address,
                        dataUpgradeProfile.avatar,
                        psCode,
                        "resident",
                        dataUpgradeProfile.password,
                        dataUpgradeProfile.email,
                        function (res) {
                            if(res){
                                $localStorage.currentUser.data[0].privilege = 'resident';
                                console.log("priv : " + $localStorage.currentUser.data[0].privilege);
                                $ionicPopup.alert({
                                    title: $filter('translate')('msg_update'),
                                    template: $filter('translate')('msg_upgrade_success'),
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup2"
                                });
                                $state.go('app.profile');
                            }else{
                                $ionicPopup.alert({
                                    template: $filter('translate')('dialog_fail_upgrade'),
                                    okText: $filter('translate')('try_again'),
                                    cssClass: "alertPopup2"
                                });
                            }
                            
                        });
                } else {
                    $ionicPopup.alert({
                        template: $filter('translate')('dialog_fail_upgrade'),
                        okText: $filter('translate')('try_again'),
                        cssClass: "alertPopup2"
                    });
                }
                $ionicLoading.hide();
            }
        )
    }

    $scope.showAlert = function (title, msg) {
        var alertPopup = $ionicPopup.alert({
            title: title,
            template: msg,
            okType: "button-stable",
            cssClass: "alertPopup"
        });
    };

    // The rest of the app comes in here
    // Present Actionsheet for switch beteen Camera / Library
    $scope.loadImage = function () {
        var callback = function (buttonIndex) {
            setTimeout(function () {
                //alert('button index clicked: ' + buttonIndex);
            });
        };

        var options = {
            title: $filter('translate')('select_image_source'),
            buttonLabels: [$filter('translate')('load_from_library'), $filter('translate')('use_camera')],
            addCancelButtonWithLabel: $filter('translate')('cancel'),
            androidEnableCancelButton: true,
            winphoneEnableCancelButton: true,
            destructiveButtonLast: true
        };

        $cordovaActionSheet.show(options, callback).then(function (btnIndex) {
            var type = null;
            if (btnIndex === 1) {
                type = Camera.PictureSourceType.PHOTOLIBRARY;
            } else if (btnIndex === 2) {
                type = Camera.PictureSourceType.CAMERA;
            }
            if (type !== null) {
                $scope.selectPicture(type);
            }
        });
    };

    $scope.selectPicture = function (sourceType) {
        var options = {
            quality: 100,
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: sourceType,
            saveToPhotoAlbum: false,
            targetWidth: 1000,
            targetHeight: 1000
        };

        $cordovaCamera.getPicture(options).then(function (imagePath) {
            // Grab the file name of the photo in the temporary directory
            var currentName = imagePath.replace(/^.*[\\\/]/, '');
            //Create a new name for the photo
            var d = new Date(),
                n = d.getTime(),
                newFileName = "account-" + n + ".jpg";

            if ($cordovaDevice.getPlatform() == 'Android' && sourceType === Camera.PictureSourceType.PHOTOLIBRARY) {
                window.FilePath.resolveNativePath(imagePath, function (entry) {
                    window.resolveLocalFileSystemURL(entry, success, fail);

                    function fail(e) {
                        console.error('Error: ', e);
                    }

                    function success(fileEntry) {
                        var namePath = fileEntry.nativeURL.substr(0, fileEntry.nativeURL.lastIndexOf('/') + 1);
                        // Only copy because of access rights
                        $cordovaFile.copyFile(namePath, fileEntry.name, cordova.file.dataDirectory, newFileName)
                            .then(function (success) {
                                $scope.image = newFileName;

                            }, setTimeout(function (error) {
                                $scope.showAlert('Error', error.exception);
                            }, 3000));
                    };
                });
            } else {
                var namePath = imagePath.substr(0, imagePath.lastIndexOf('/') + 1);
                // Move the file to permanent storage
                $cordovaFile.moveFile(namePath, currentName, cordova.file.dataDirectory, newFileName)
                    .then(function (success) {
                        $scope.image = newFileName;
                    }, setTimeout(function (error) {
                        $scope.showAlert('Error', error.exception);
                    }, 3000));
            }
        },
            function (err) {
                // Not always an error, maybe cancel was pressed...
            })
    };

    $scope.pathForImage = function (image) {
        if (image === null) {
            return '';
        } else {
            return cordova.file.dataDirectory + image;
        }
    };
}

function history($scope, $localStorage, $localStorage, $ionicLoading, HistoryService, $filter) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'My History';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    $scope.data = [];
    var pagenumber = 1;
    $scope.idaccount = $localStorage.currentUser.data[0].idaccount;
    HistoryService.listHistory($scope.idaccount, pagenumber, function (response) {
        if (response != false) {
            $scope.data = response;

            var i = 2;
            $scope.loadMore = function () {
                pagenumber = i;

                HistoryService.listHistory($scope.idaccount, pagenumber, function (response) {
                    if (response) {       
                        var a=0;
                        angular.forEach(response, function(){
                            var b = a++;
                            var date = response[b].visitdate;
                            dataLoadmore = [{
                                activities : response[b].activities,
                                activities_id : response[b].activities_id,
                                categoryname: response[b].categoryname,
                                idaccount: response[b].idaccount,
                                idcategory: response[b].idcategory,
                                idhistory: response[b].idhistory,
                                visitdate: date.slice(0, 16)
                            }];
                        
                            $scope.data = $scope.data.concat(dataLoadmore);
                        })
                        
                    } else {
                        console.log('no more data loaded');
                    }
                });

                $scope.$broadcast('scroll.infiniteScrollComplete');
                i++;
            };
            //
        } else {
            $scope.data = [{ name: $filter('translate')('no_user') }];
        }
        for (var i = 0; i < $scope.data.length; i++) {
            if ($scope.data[i].hasOwnProperty('visitdate')) {
                var d = new Date($scope.data[i].visitdate.replace(' ', 'T'));
                $scope.data[i]['visitdate'] = d;
            }
        }
        console.log('data: ');
        console.log($scope.data);
        $ionicLoading.hide();
    });

}

function myhistory($scope, $stateParams, $localStorage, $ionicLoading, HistoryService, $filter) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
    $scope.data = [];
    var pagenumber = 1;
    $scope.idaccount = $localStorage.currentUser.data[0].idaccount;
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'My History';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    HistoryService.listHistory($stateParams.idaccount, pagenumber, function (response) {
        if (response != false) {
            $scope.data = response;

            var i = 2;
            $scope.loadMore = function () {
                pagenumber = i;

                HistoryService.listHistory($stateParams.idaccount, pagenumber, function (response) {
                    if (response) {
                        $scope.data = $scope.data.concat(response);
                    } else {
                        console.log('no more data loaded');
                    }
                });

                $scope.$broadcast('scroll.infiniteScrollComplete');
                i++;
            };
            //
        } else {
            $scope.data = [{ name: $filter('translate')('no_user') }];
        }

        $ionicLoading.hide();
    });

}
