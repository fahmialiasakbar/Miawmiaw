angular
    .module('livein')
    .controller('sportDetail', entertaimentSportDetail)
    .controller('tenantMap', tenantMap)
    .controller('sportDetailImage', entertaimentSportDetailImage)
    .controller('tenantHome', tenantHome);

function entertaimentSportDetail($scope, $timeout, $ionicHistory, $rootScope, $cordovaGeolocation, $stateParams, $ionicPopup, $location, $ionicLoading, $localStorage, $state, TenantService, TenantServiceA, $filter, $ionicPlatform, $ionicModal, $ionicSlideBoxDelegate) {

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    try {
        $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            $rootScope.lat = position.coords.latitude
            $rootScope.long = position.coords.longitude
            //console.log('lat :' + $rootScope.lat + '  long: ' + $rootScope.long);

        });
    } catch (e) {  

    }

    $ionicModal.fromTemplateUrl('partials/sides/tenantDetailImage.html', {
        scope: $scope
    }).then(function (modalImage) {
        $scope.modalImage = modalImage;
    });

    $scope.openModalImage = function (idtenant, index) {
        $scope.modalImage.show();
        $scope.idtenant = idtenant;
        $scope.index = index;

        TenantService.retriveGetTenantImage($scope.idtenant, function (response) {
            if (response != false) {
                $ionicSlideBoxDelegate.update();
                $scope.results = [];

                $scope.gall = $scope.index;
                $scope.dari = $scope.results;

                $scope.gallery = response;
                var i = 1
                angular.forEach($scope.gallery, function (obj) {
                    if (obj.idtenant == $scope.idtenant) {
                        obj.number = i++;
                        $scope.results.push(obj);
                    }
                });

                var keys = Object.keys($scope.results);
                $scope.len = keys.length;
            } else {
                $.data = { name: $filter('translate')('failed_get_data') };
            }
        });

        $scope.next = function () {
            $ionicSlideBoxDelegate.next();
        };

        $scope.previous = function () {
            $ionicSlideBoxDelegate.previous();
        };

        $scope.slideChanged = function () {
            $ionicSlideBoxDelegate.update();
        };
    };

    $scope.openModalImageAvatar = function (avatar) {
        $scope.modalImage.show();
        $scope.index = 0;
        $scope.results = [{
            avatar: avatar,
            number: 1,
            title: '',
        }];
        $scope.len = $scope.results.length;

        $scope.next = function () {
            $ionicSlideBoxDelegate.next();
        };

        $scope.previous = function () {
            $ionicSlideBoxDelegate.previous();
        };

        $scope.slideChanged = function () {
            $ionicSlideBoxDelegate.update();
        };
    };

    $scope.closeModalImage = function () {
        $scope.modalImage.hide();
    };

    if ($localStorage.currentUser != null) {
        $scope.salah = true;
    } else {
        $scope.salah = false;
    }

    $scope.gagalBookmark = function () {
        var alertPopup = $ionicPopup.alert({
            template: $filter('translate')('blm_login'),
            okText: $filter('translate')('okay'),
            okType: "button-stable",
            cssClass: "alertPopup"
        });
    };

    $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        viewData.enableBack = true;
    });

    $scope.MapClick = gotoMap;
    $scope.Bookmark = setbookmark;
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    function formatDate(d) {
        var hour = d.split(":");
        var hh = hour[0]
        var m = hour[1]
        var s = hour[2]

        var dd = "AM";
        var h = hh;
        if (h >= 12) {
            h = hh - 12;
            if (h.toString().length == 1) h = "0" + (hh - 12)
            dd = "PM";
        }

        if (h == 0) {
            h = 12;
        }
        m = m < 10 ? m : m;
        s = s < 10 ? "0" + s : s;
        var replacement = h + ":" + m;
        /* if you want to add seconds
        replacement += ":"+s;  */
        replacement += " " + dd;
        return replacement;
    }

    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    TenantService.retriveGetTenant($stateParams.idtenant, function (response) {
        $timeout(function () {
            if (response != false) {
                
                angular.forEach(response.detail, function (value, key) {
                    // $scope.tenantdata = value;
                    $scope.tenantdata = {
                        address:value.address,
                        avatar:value.avatar,
                        closehour:formatDate(value.closehour),
                        color:value.color,
                        idcategory:value.idcategory,
                        idtenant:value.idtenant,
                        isBookmarked:value.isBookmarked,
                        link:value.link,
                        logo:value.logo,
                        longlat:value.longlat,
                        name:value.name,
                        open:value.open,
                        openhour:formatDate(value.openhour),
                        phone:value.phone,
                        premium:value.premium,
                        rating:value.rating,
                        idtenant: value.idtenant,
                    }
                });
      
                $scope.tenantDining = response.menu;
                //rate tenant
                $scope.rateValue = $scope.tenantdata.rating;
                $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');    
                
                $scope.categorytenant = texcategory(response.detail[0].idcategory);
                               
                $scope.idcategory = $scope.tenantdata.idcategory;
                $scope.tenantname = $scope.tenantdata.name;                
                
                // ----- Analytic Screen
                if (window.ga) {
                    var analyticView = 'Tenant ' + $scope.tenantdata.name;
                    window.ga.trackView(analyticView);
                    window.ga.trackEvent(response.detail[0].catname_parent, response.detail[0].catname , analyticView);
                    console.log("Analytic - " + $scope.categorytenant + " - " + analyticView);
                }
                $scope.avatar = $scope.tenantdata.avatar;
                $scope.isBookmarked = $scope.tenantdata.isBookmarked;
                getTenantGallery();
    
                datalonglat1 = $scope.tenantdata.longlat.replace('(', '');
                datalonglat2 = datalonglat1.replace(')', '');
                if (datalonglat2.length > 0) {
                    $rootScope.lattenant = (datalonglat2.split(',')[0]);
                    $rootScope.longtenant = (datalonglat2.split(',')[1]);
    
                }
    
                //set to service
                $scope.distance = calculatdistance($rootScope.lat, $rootScope.long);
                //console.log($scope.distance);
                //console.log($scope.categorytenant);
                $ionicLoading.hide();
            } else {
                $scope.data = { name: $filter('translate')('failed_get_data') };
                $ionicLoading.hide();
            }
        }, 2000)
    });

    function texcategory(idcategory) {

        if (angular.equals(idcategory, "16")) {
            child_category = $filter('translate')('events');
            parent_category = $filter('translate')('entertaiment');
        }
        //sport
        if (angular.equals(idcategory, "17")) {
            child_category = $filter('translate')('sport');
            parent_category = $filter('translate')('entertaiment');
        }
        //child sport
        if (angular.equals(idcategory, "21")) {
            child_category = $filter('translate')('gym');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "22")) {
            child_category = $filter('translate')('outdoor_sport');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "23")) {
            child_category = $filter('translate')('indoor_sports');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "104")) {
            child_category = $filter('translate')('recreational_sites');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "105")) {
            child_category = $filter('translate')('golfing');
            parent_category = $filter('translate')('entertaiment');
        }
        //leisure
        if (angular.equals(idcategory, "18")) {
            child_category = $filter('translate')('leisure');
            parent_category = $filter('translate')('entertaiment');
        }
        // child leisure
        if (angular.equals(idcategory, "24")) {
            child_category = $filter('translate')('cinema');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "25")) {
            child_category = $filter('translate')('karaoke');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "26")) {
            child_category = $filter('translate')('games');
            parent_category = $filter('translate')('entertaiment');
        }
        //art
        if (angular.equals(idcategory, "19")) {
            child_category = $filter('translate')('art');
            parent_category = $filter('translate')('entertaiment');
        }
        //beauty
        if (angular.equals(idcategory, "20")) {
            child_category = $filter('translate')('beauty');
            parent_category = $filter('translate')('entertaiment');
        }
        //child beauty
        if (angular.equals(idcategory, "27")) {
            child_category = $filter('translate')('salon');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "28")) {
            child_category = $filter('translate')('skin_care');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "29")) {
            child_category = $filter('translate')('cosmetic');
            parent_category = $filter('translate')('entertaiment');
        }
        if (angular.equals(idcategory, "30")) {
            child_category = $filter('translate')('spa___treatment');
            parent_category = $filter('translate')('entertaiment');
        }
        //dining
        //fast food
        if (angular.equals(idcategory, "31")) {
            child_category = $filter('translate')('fastfood');
            parent_category = $filter('translate')('dining');
        }
        //japanese
        if (angular.equals(idcategory, "32")) {
            child_category = $filter('translate')('japanese_food');
            parent_category = $filter('translate')('dining');
        }
        //traditional
        if (angular.equals(idcategory, "33")) {
            child_category = $filter('translate')('traditional_food');
            parent_category = $filter('translate')('dining');
        }
        //chinese
        if (angular.equals(idcategory, "34")) {
            child_category = $filter('translate')('chinese_food');
            parent_category = $filter('translate')('dining');
        }
        //western
        if (angular.equals(idcategory, "35")) {
            child_category = $filter('translate')('westren_food');
            parent_category = $filter('translate')('dining');
        }
        //bakery
        if (angular.equals(idcategory, "36")) {
            child_category = $filter('translate')('bakery');
            parent_category = $filter('translate')('dining');
        }
        //cafe
        if (angular.equals(idcategory, "37")) {
            child_category = $filter('translate')('bar_cafe_club');
            parent_category = $filter('translate')('dining');
        }
        //korean
        if (angular.equals(idcategory, "90")) {
            child_category = $filter('translate')('korean_food');
            parent_category = $filter('translate')('dining');
        }
        //oth_dining
        if (angular.equals(idcategory, "38")) {
            child_category = $filter('translate')('others');
            parent_category = $filter('translate')('dining');
        }
        //accomodation
        //hotel
        if (angular.equals(idcategory, "45")) {
            child_category = $filter('translate')('hotel');
            parent_category = $filter('translate')('accomodation');
        }
        //condominiums
        if (angular.equals(idcategory, "46")) {
            child_category = $filter('translate')('condominiums');
            parent_category = $filter('translate')('accomodation');
        }
        //apartment
        if (angular.equals(idcategory, "47")) {
            child_category = $filter('translate')('apartment_property');
            parent_category = $filter('translate')('accomodation');
        }
        //shopping
        //department
        if (angular.equals(idcategory, "48")) {
            child_category = $filter('translate')('deparment_store');
            parent_category = $filter('translate')('shopping');
        }
        //mart
        if (angular.equals(idcategory, "49")) {
            child_category = $filter('translate')('mart');
            parent_category = $filter('translate')('shopping');
        }
        //child mart
        if (angular.equals(idcategory, "55")) {
            child_category = $filter('translate')('supermarket');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "56")) {
            child_category = $filter('translate')('minimarket');
            parent_category = $filter('translate')('shopping');
        }
        //fashion
        if (angular.equals(idcategory, "50")) {
            child_category = $filter('translate')('fashion');
            parent_category = $filter('translate')('shopping');
        }
        //child fashion
        if (angular.equals(idcategory, "57")) {
            child_category = $filter('translate')('Batik');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "58")) {
            child_category = $filter('translate')('clothes');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "59")) {
            child_category = $filter('translate')('shoes');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "60")) {
            child_category = $filter('translate')('accessories___toys');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "61")) {
            child_category = $filter('translate')('sport');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "62")) {
            child_category = $filter('translate')('eyewear');
            parent_category = $filter('translate')('shopping');
        }
        if (angular.equals(idcategory, "63")) {
            child_category = $filter('translate')('jewelry');
            parent_category = $filter('translate')('shopping');
        }
        //home
        if (angular.equals(idcategory, "51")) {
            child_category = $filter('translate')('home_improvement');
            parent_category = $filter('translate')('shopping');
        }
        //book
        if (angular.equals(idcategory, "52")) {
            child_category = $filter('translate')('book_stationety');
            parent_category = $filter('translate')('shopping');
        }
        //electronic
        if (angular.equals(idcategory, "53")) {
            child_category = $filter('translate')('electronic');
            parent_category = $filter('translate')('shopping');
        }
        //automotive
        if (angular.equals(idcategory, "54")) {
            child_category = $filter('translate')('automotive');
            parent_category = $filter('translate')('shopping');
        }
        //other
        if (angular.equals(idcategory, "64")) {
            child_category = $filter('translate')('others');
            parent_category = $filter('translate')('shopping');
        }
        //education
        if (angular.equals(idcategory, "66")) {
            child_category = $filter('translate')('school');
            parent_category = $filter('translate')('education');
        }
        if (angular.equals(idcategory, "67")) {
            child_category = $filter('translate')('tutor');
            parent_category = $filter('translate')('education');
        }
        if (angular.equals(idcategory, "68")) {
            child_category = $filter('translate')('music');
            parent_category = $filter('translate')('education');
        }
        //health care
        if (angular.equals(idcategory, "70")) {
            child_category = $filter('translate')('health');
            parent_category = $filter('translate')('health_care');
        }
        if (angular.equals(idcategory, "71")) {
            child_category = $filter('translate')('hospital');
            parent_category = $filter('translate')('health_care');
        }
        //public service
        //property
        if (angular.equals(idcategory, "73")) {
            child_category = $filter('translate')('property_agents');
            parent_category = $filter('translate')('public_services');
        }
        //atm
        if (angular.equals(idcategory, "74")) {
            child_category = $filter('translate')('atm_gallery');
            parent_category = $filter('translate')('public_services');
        }
        //tour
        if (angular.equals(idcategory, "75")) {
            child_category = $filter('translate')('tour_travel');
            parent_category = $filter('translate')('public_services');
        }
        //bank
        if (angular.equals(idcategory, "76")) {
            child_category = $filter('translate')('bank');
            parent_category = $filter('translate')('public_services');
        }
        //insurance
        if (angular.equals(idcategory, "77")) {
            child_category = $filter('translate')('insurance');
            parent_category = $filter('translate')('public_services');
        }
        //gas
        if (angular.equals(idcategory, "78")) {
            child_category = $filter('translate')('spbu');
            parent_category = $filter('translate')('public_services');
        }
        //notaris
        if (angular.equals(idcategory, "79")) {
            child_category = $filter('translate')('notaris');
            parent_category = $filter('translate')('public_services');
        }
        //others
        if (angular.equals(idcategory, "80")) {
            child_category = $filter('translate')('others');
            parent_category = $filter('translate')('public_services');
        }
        //workshop
        if (angular.equals(idcategory, "81")) {
            child_category = $filter('translate')('workshop_services');
            parent_category = $filter('translate')('public_services');
        }
        //industry
        //DS1
        if (angular.equals(idcategory, "96")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS1";
        }
        //DS2
        if (angular.equals(idcategory, "97")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS2";
        }
        //DS3
        if (angular.equals(idcategory, "98")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS3";
        }
        //DS5
        if (angular.equals(idcategory, "100")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS5";
        }
        //DS6
        if (angular.equals(idcategory, "101")) {
            parent_category = $filter('translate')('industries');
            child_category = "DS6";
        }
        //newton
        if (angular.equals(idcategory, "102")) {
            child_category = $filter('translate')('newton_techno_park');
            parent_category = $filter('translate')('industries');
        }
        //transportation
        if (angular.equals(idcategory, "106")) {
            child_category = $filter('translate')('rental_cars');
            parent_category = $filter('translate')('transportation');
        }
        var catmeong = child_category+', '+parent_category
        return catmeong;
    }

    function inserthistory() {
        TenantService.insertHistory(
            data.title,
            data.description,
            linkImg,
            function (response) {
                if (response != false) {
                    var newforum = $ionicPopup.alert({
                        template: $filter('translate')('new_forum'),
                        okText: $filter('translate')('okay'),
                        okType: "button-stable",
                        cssClass: "alertPopup"
                    });

                    $state.go('app.forum')
                } else {
                    console.log("failed")
                }
            })
    }


    function calculatdistance(lat, long) {

        datalonglat1 = $scope.tenantdata.longlat.replace('(', '');
        datalonglat2 = datalonglat1.replace(')', '');
        lattenant = (datalonglat2.split(',')[0]);
        longtenant = (datalonglat2.split(',')[1]);


        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad($rootScope.lat - lattenant); // deg2rad below
        var dLon = deg2rad($rootScope.long - longtenant);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat)) * Math.cos(deg2rad(lattenant)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km

        //console.log(d);
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180)
    }

    //goto map
    function gotoMap(longlat) {
        datalonglat1 = longlat.replace('(', '');
        datalonglat2 = datalonglat1.replace(')', '');

        $rootScope.lattenant = (datalonglat2.split(',')[0]);
        $rootScope.longtenant = (datalonglat2.split(',')[1]);
        $rootScope.nametenant = $scope.tenantname;
        $rootScope.detailTenantData = $scope.tenantdata;
        // $rootScope.lattenant, $rootScope.longtenant
        $state.go('app.tenantMap');
    };

    //function set bookamark
    function setbookmark() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        TenantServiceA.bookmarkTenant(
            $scope.tenantdata.idtenant,
            $scope.fullname = $localStorage.currentUser.data[0].idaccount,
            function (response) {
                $timeout(function () {
                    if (response != false) {

                        if (response[0].status == true) {
                            //$ionicLoading.show({ template: $filter('translate')('bookmarked'), duration: 10000 });
                            //alert( $filter('translate')('bookmarked'));

                            if (response[0].message == "success") {
                                var message = $filter('translate')('bookmarked');
                                $scope.isBookmarked = true;
                            } else {
                                $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
                                var message = response[0].message;
                                if ($scope.lang == 'ina') {
                                    message = response[0].message_id;
                                }
                                $scope.isBookmarked = false;
                            }

                            var alertPopup = $ionicPopup.alert({
                                //title: 'Don\'t eat that!',
                                template: message,
                                okType: "button-stable",
                                cssClass: "alertPopup",
                                duration: 10000
                            });

                        } else {
                            var alertPopup = $ionicPopup.alert({
                                //title: 'Don\'t eat that!',
                                template: $filter('translate')('all_bookmarked'),
                                okType: "button-stable",
                                cssClass: "alertPopup",
                                duration: 10000
                            });
                        }
                        $ionicLoading.hide();

                    } else {
                        $ionicLoading.show({
                            template: $filter('translate')('post_rating_success'),
                            duration: 10000
                        });
                    }
                    $ionicLoading.hide();

                }, 1000);
            });

    }

    $scope.reviewClick = function (urlview) {
        if (urlview != null) {

            window.open(urlview, '_system', 'location=yes')

        } else {
            var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('action_review') + ' Tenant',
                template: $filter('translate')('no_review_tenant'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });

        }

    }
    function getTenantGallery (){
        $scope.resultsImg = [];
        TenantService.retriveGetTenantImage($stateParams.idtenant, function (response) {
            if (response != false) {
                if (response.length > 0) {
                    angular.forEach(response, function (obj) {
                        if (obj.idtenant == $stateParams.idtenant) {
                            $scope.resultsImg.push(obj);
                        }
                    });
                    $scope.isEmptyImg = false;
                }
    
                if ($scope.resultsImg.length == 0) {
                    $scope.isEmptyImg = true; 
                    $scope.resultsImg = [
                        { avatar: $scope.avatar }
                    ];
    
                }
            } else {
                if ($scope.resultsImg.length == 0) {
                    $scope.isEmptyImg = true; 
                    $scope.resultsImg = [
                        { avatar: $scope.avatar }
                    ];
                }
                $.data = { name: $filter('translate')('failed_get_data') };
            }
            console.log($scope.resultsImg);
        });
    }

    // $scope.$on('$ionicView.beforeLeave', function () {
    //     if ($scope.rating != null || $scope.rating != undefined) {
    //         var confirmPopup = $ionicPopup.confirm({
    //             title: $filter('translate')('rate_title'),
    //             template: $filter('translate')('rate_dialog'),
    //             okText: $filter('translate')('yes'),
    //             cancelText: $filter('translate')('no'),
    //             okType: "button-stable"
    //         });
    //         confirmPopup.then(function (res) {
    //             if (res) {
    //                 rateTenantService();
    //             } else {
    //                 //console.log('You are not sure');
    //             }
    //         });
    //     }
    // }); 

    function rateTenantService() {

        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        TenantServiceA.rateTenant(
            $stateParams.idtenant,
            $localStorage.currentUser.data[0].idaccount,
            $scope.rating,
            function (response) {
                if (response != false) {
                    $ionicLoading.show({
                        template: $filter('translate')('post_rating_success'),
                        duration: 3000
                    });
                } else {
                    $ionicLoading.show({
                        template: $filter('translate')('post_rating_success'),
                        duration: 3000
                    });
                    $location.path('/rate');
                }
                $ionicLoading.hide();
            });
    };

    $scope.inputrate = function (rate) {

        if ($localStorage.currentUser != null) {
            $scope.rating = rate;
            var confirmPopup = $ionicPopup.confirm({
                title: $filter('translate')('rate_title'),
                template: $filter('translate')('rate_dialog'),
                okText: $filter('translate')('yes'),
                cancelText: $filter('translate')('no'),
                okType: "button-stable"
            });
            confirmPopup.then(function (res) {
                if (res) {
                    rateTenantService();
                } else {
                    //console.log('You are not sure');
                }
            });
        } else {
            var getStatus = $ionicPopup.alert({
                template: $filter('translate')('blm_rate'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });
        }

    }

    $scope.showdistance = false;
    var geocoder = new google.maps.Geocoder;
    var infowindow = new google.maps.InfoWindow;
    var confirm_status = 0;
    var myLocation;

    $ionicPlatform.ready(function () {
        console.log("masuk permission");
        //screen.lockOrientation('portrait');

        if (ionic.Platform.isIOS() || ionic.Platform.isAndroid()) {
            try {
                cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                    if (enabled == true) {
                        ionicToast.show($filter('translate')('gps_on'), 'bottom', false, 5000);
                    }
                    if (enabled == false) {
                        console.log("masuk popup");
                        var confirmPopup = $ionicPopup.confirm({
                            title: $filter('translate')('dialog_title_gps'),
                            template: $filter('translate')('dialog_content_gps')
                        });
                        confirmPopup.then(function (res) {
                            if (res) {
                                cordova.plugins.diagnostic.switchToLocationSettings();
                            } else {
                                console.log('You are not sure');
                            }
                        });

                    }
                }, function (error) {
                    alert("The following error occurred: " + error);
                });
            } catch (e) {

            }
        }
    });

    $scope.loadGLoader = function () {
        if (!window.google || !window.google.loader) {
            console.log("loading gloader");
            $http.get("http://maps.googleapis.com/maps/api/js?key=AIzaSyAZ4939bfDLme2qmuIsfwg-ilYmsG3CeBw&libraries=places")
                .success(function (json) {
                    var scriptElem = document.createElement('script');
                    document.getElementsByTagName('head')[0].appendChild(scriptElem);
                    scriptElem.text = json;
                    locations.loadGMaps();
                });
        } else {
            if (!window.google.maps || !window.google.maps) {
                console.log("no gmaps");
                $rootScope.loadGMaps();
            }
        }
    };
    $scope.loadGMaps = function () {
        if (window.google && window.google.loader && window.google.maps === undefined) {
            console.log("loading gmaps");
            try {
                google.load("maps", "3.21", {
                    callback: mappingCallback,
                    other_params: "libraries=geometry&sensor=true&language=en"
                });
            } catch (e) { }
        }
    };


    $scope.labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $scope.labelIndex = 0;
    $scope.arrMarker = [];
    $scope.myLocation;

    var loadMap = function () {

        var mapOptions = {
            center: new google.maps.LatLng(-6.21462, 106.84513),
            styles: [{ featureType: "all", stylers: [{ saturation: -75 }] }],
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControlOptions: { position: google.maps.ControlPosition.TOP_CENTER },
            zoom: 5,
            zoomControl: true,
            mapTypeControl: false,
            streetViewControl: false,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_BOTTOM,
                style: google.maps.ZoomControlStyle.SMALL
            }
        };


        var map = new google.maps.Map(document.getElementById("map"), mapOptions);
        $scope.map = map;


        try {
            if ($localStorage.permission_tabmaps.tabmaps == 1) {
                markerlocation();
            } else {
                popupconfirm();
            }
        } catch (e) {
            popupconfirm();

        }

        if (confirm_status == 1) {
            markerlocation();
        }
    }

    function popupconfirm() {
        var confirmPopup = $ionicPopup.confirm({
            title: "Permission ",
            template: "To show user current location, estimates time and travel distance and desired destination"
        });
        confirmPopup.then(function (res) {
            if (res) {
                confirm_status = 1;
                $localStorage.permission_tabmaps = { tabmaps: confirm_status };
                markerlocation();
            } else {
                confirm_status = 0;
            }
        });

    }

    function markerlocation() {
        var id = navigator.geolocation.watchPosition(function onSucces(position) {
            $timeout(function(){
                // lat = position.coords.latitude
                // long = position.coords.longitude
                lat = $rootScope.lattenant;
                long = $rootScope.longtenant;
                $scope.location = new google.maps.LatLng(lat, long);
                // alert(JSON.stringify($scope.location))

                if ($scope.location != null || $scope.location != undefined) {
                    //  map.setMapOnAll(null);
                    navigator.geolocation.clearWatch(id);

                    if (myLocation != undefined) {
                        myLocation.setMap(null);
                    }

                    $scope.map.setCenter($scope.location);
                    $scope.map.setZoom(16);
                    myLocation = new google.maps.Marker({
                        position: $scope.location,
                        map: $scope.map,
                        title: "background"
                    });
                }
            }, 1000);

        }, function onMapError(error) {

            $scope.location = undefined;

        }, { enableHighAccuracy: true });

    }

    $scope.$on('$ionicView.loaded', function () {
        console.log("map page loaded - should only see me once???");
    })

    $scope.$on('$ionicView.enter', function () {
        console.log("Is google, google maps and our map set up?")
        if (window.google) {
            console.log("google is");
            if (window.google.maps) {
                console.log("maps is");
                if ($scope.map === undefined) {
                    console.log("loading our map now...");
                    loadMap();
                }
                /*else{
                 goo
                 }*/
            } else {
                console.log("maps isn't...");
                $scope.loadGMaps(); //then load the map
            }
        } else {
            console.log("google isn't...");
            $scope.loadGLoader(); //then load maps, then load the map
        }
    });
}

function entertaimentSportDetailImage($timeout, $scope, $stateParams, $location, $ionicSlideBoxDelegate, $ionicLoading, TenantService) {
    //$ionicLoading.show({ template: 'Loading ...' });

    TenantService.retriveGetTenantImage($stateParams.idtenant, function (response) {
        if (response != false) {
            $ionicSlideBoxDelegate.update();
            $scope.results = [];

            $scope.gall = $stateParams.index;
            $scope.dari = $scope.results;

            $scope.gallery = response;
            var a = 0;
            angular.forEach($scope.gallery, function (obj) {
                var b = a++;
                var images = $scope.gallery;
                var img = images[b];
                var ll = img.idtenant;

                if (ll == $stateParams.idtenant) {
                    $scope.results.push(images[b]);
                }
            })

            var keys = Object.keys($scope.results);
            $scope.len = keys.length;

            var i = 1;
            $scope.results.forEach(function (itemfile, indexfile, arrfile) {
                $scope.results[indexfile].number = i++;
            });

        } else {
            $.data = { name: $filter('translate')('failed_get_data') };
        }
        //$ionicLoading.hide();
    });

    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };
}

function tenantMap($window, HistoryService, $ionicPopup, $rootScope, $localStorage, $scope, $ionicLoading, $cordovaGeolocation, distanceduration, $filter) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Tenant Map';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    
    function insertHistoryDirectionMaps(){
        var activities = "Direction to-"+ $rootScope.detailTenantData.name;
        var visitedate = new Date().toISOString();
        HistoryService.insertHistory($rootScope.detailTenantData.idtenant, activities, visitedate, $rootScope.detailTenantData.idcategory, function (response) {
            
            if(response){
                console.log("Success insert history direction maps");
                console.log(response);
            }else{
                console.log("Failed insert history direction maps");
            }
        });
    }
    $scope.tujuan = new google.maps.LatLng($rootScope.lattenant, $rootScope.longtenant);
    $confirm_status = 0;
    $scope.myLatlng;
    $scope.show_distance = false;

    console.log('bismillah');
    console.log($rootScope.backgroundmyLatlng);

    //    getduration($scope.myLatlng,$scope.tujuan);

    //load map
    $scope.$on('$ionicView.loaded', function () {
        //console.log("map page loaded - should only see me once???");
    })

    $scope.$on('$ionicView.enter', function () {

        //console.log("Is google, google maps and our map set up?")
        if (window.google) {
            //console.log("google is");
            if (window.google.maps) {
                //console.log("maps is");
                if ($scope.map === undefined) {
                    //console.log("loading our map now...");
                    loadMap();
                }
                /*else{
                 goo
                 }*/
            } else {
                console.log("maps isn't...");
                $scope.loadGMapstenant(); //then load the map
            }
        } else {
            console.log("google isn't...");
            $scope.loadGLoadertenant(); //then load maps, then load the map
        }
    });

    function loadMap() {
        // $scope.tujuan = new google.maps.LatLng($rootScope.lattenant, $rootScope.longtenant);
        // $scope.myLatlng = $rootScope.backgroundmyLatlng;
        var mapOptions = {
            center: new google.maps.LatLng(-6.21462, 106.84513),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControlOptions: { position: google.maps.ControlPosition.TOP_CENTER },
            zoom: 16,
            zoomControl: true,
            mapTypeControl: false,
            streetViewControl: false,
            zoomControlOptions: {
                position: google.maps.ControlPosition.RIGHT_TOP,
                style: google.maps.ZoomControlStyle.SMALL
            }

        };

        $scope.map = new google.maps.Map(document.getElementById("mapDetail"), mapOptions);

        try {
            if ($localStorage.permission_tenantMap.tenantMap == 1) {
                markerlocation();
            } else {
                popupconfirm();
            }
        } catch (e) {
            popupconfirm();
        }
        console.log($scope.tujuan);
        console.log($scope.myLatlng);
        console.log(mapOptions);

        // getdirection($scope.myLatlng,$scope.tujuan);
    }

    // get current location
    // get direction 
    function getdirection(mylatlang, tujuan) {
        if (mylatlang != undefined) {
            console.log("Masuk sini");
            $scope.map.setCenter(mylatlang);
            var myLocation = new google.maps.Marker({
                position: mylatlang,
                map: $scope.map,
                title: $filter('translate')('my_location')
            });


            //  set destinaiton
            var directionsDisplay = new google.maps.DirectionsRenderer;
            var directionsService = new google.maps.DirectionsService;

            directionsDisplay.setMap($scope.map);
            directionsService.route({
                origin: mylatlang,
                destination: tujuan,
                travelMode: 'DRIVING',
                unitSystem: google.maps.UnitSystem.IMPERIAL
            }, function (response, status) {
                console.log(response);
                if (status == 'OK') {
                    directionsDisplay.setDirections(response);
                } else {
                    window.alert('Directions request failed due to ' + status);
                }
            });
        } else {
            console.log("Masuk else");

            var geocoder = new google.maps.Geocoder;
            var infowindow = new google.maps.InfoWindow;
            var myLocation = new google.maps.Marker({
                position: tujuan,
                map: $scope.map,
                title: $filter('translate')('my_location')

            });
            //console.log(myLocation);
            infowindow.setContent($rootScope.nametenant);
            infowindow.open($scope.map, myLocation);
            $scope.map.setCenter($scope.tujuan);
        }

    }

    //get distance and duration
    function getduration(mylatlang, tujuan) {
        service = new google.maps.DistanceMatrixService;
        service.getDistanceMatrix({
            origins: [mylatlang],
            destinations: [tujuan],
            travelMode: 'DRIVING',
            unitSystem: google.maps.UnitSystem.METRIC,
            avoidHighways: false,
            avoidTolls: false
        }, function (response, status) {
            element = response.rows[0].elements[0];

            $scope.distance = element.distance.text;
            console.log('distance tenant : ', $scope.distance);
            
            insertHistoryDirectionMaps();
            $scope.show_distance = true;
            var abc = element.duration.text;
            var bcd = "" + abc.length;

            if (bcd >= 9) {
                $scope.durationH = abc.slice(0, 2) + " jam";
                $scope.durationM = abc.slice(6, 8) + " menit";
            }
            else if (bcd <= 8) {
                $scope.durationM = abc.slice(0, 2) + " menit";
                $scope.durationH = "";
            } else {
                console.log('it cannnot be done');
            }
            document.getElementById('container-matrik').style.display = "flex";
            document.getElementById('text-distance').innerHTML = $scope.distance
            document.getElementById('text-duration').innerHTML = abc


        });
    }

    function popupconfirm() {
        var confirmPopup = $ionicPopup.confirm({
            title: "Permission ",
            template: "To show user's current location, estimates distance and travel mileage from user's location to tenant's location"
        });
        confirmPopup.then(function (res) {
            if (res) {
                confirm_status = 1;
                $localStorage.permission_tenantMap = { tenantMap: confirm_status };
                markerlocation();
            } else {
                getdirection(undefined, $scope.tujuan)
            }
        });

    }

    function markerlocation() {

        var id = navigator.geolocation.watchPosition(function onSucces(position) {
            lat = position.coords.latitude
            long = position.coords.longitude
            $scope.location = new google.maps.LatLng(lat, long);
            // alert(JSON.stringify($scope.location))

            if ($scope.location != null || $scope.location != undefined) {
                //  map.setMapOnAll(null);
                navigator.geolocation.clearWatch(id);

                if ($scope.myLatlng != undefined) {
                    $scope.myLatlng.setMap(null);
                }

                $scope.map.setCenter($scope.location);
                $scope.map.setZoom(16);
                $scope.myLatlng = new google.maps.Marker({
                    position: $scope.location,
                    map: $scope.map,
                    title: "background"
                });

                getdirection($scope.location, $scope.tujuan)
                getduration($scope.location, $scope.tujuan)
            }

        }, function onMapError(error) {

            $scope.location = undefined;

        }, { enableHighAccuracy: true });

    }


    $scope.loadGLoadertenant = function () {
        if (!window.google || !window.google.loader) {
            //console.log("loading gloader");
            $http.get("http://maps.googleapis.com/maps/api/js?key=AIzaSyAZ4939bfDLme2qmuIsfwg-ilYmsG3CeBw&libraries=places")
                .success(function (json) {
                    var scriptElem = document.createElement('script');
                    document.getElementsByTagName('head')[0].appendChild(scriptElem);
                    scriptElem.text = json;
                    locations.loadGMaps();
                });
        } else {
            if (!window.google.maps || !window.google.maps) {
                //console.log("no gmaps");
                $rootScope.loadGMaps();
            }
        }
    };

    $scope.loadGMapstenant = function () {
        if (window.google && window.google.loader && window.google.maps === undefined) {
            //console.log("loading gmaps");
            try {
                google.load("maps", "3.21", {
                    callback: mappingCallback,
                    other_params: "libraries=geometry&sensor=true&language=en"
                });
            } catch (e) { }
        }
    };
}

function tenantHome(TenantService, $stateParams, $filter, $scope, $rootScope, $ionicHistory) {
    $scope.navbar = true;
    $scope.searchbar = false;

    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Tenant Home';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    $scope.searchbarAct = function () {
        $scope.navbar = false;
        $scope.searchbar = true;
    };

    $scope.navbarAct = function () {
        $scope.navbar = true;
        $scope.searchbar = false;
        $rootScope.search_page = "";
    };

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    categoryTenant();
    function categoryTenant() {
        TenantService.categoryTenant($stateParams.idtenant, function (response) {
            if (response != false) {
                $scope.idcategory = $stateParams.idtenant;
                $scope.tenantdata = [];
                $scope.recomendeddata = [];
                var a = 0;
                angular.forEach(response, function () {
                    var b = a++;
                    var data = response[b];
                    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
                    var parentname = data.parentname;
                    var categoryname = data.categoryname;
                    if ($scope.lang == 'ina') {
                        parentname = data.parentname_id != null ? data.parentname_id : data.parentname;
                        categoryname = data.categoryname_id != null ? data.categoryname_id : data.categoryname;
                    }

                    $scope.subcategorys = parentname;
                    var colors = ['#1d1d26', '#50d2c2', '#8c88ff', '#4083ff', '#fcab53', '#ff3366', '#d667cd', '#4a90e2', '#8b572a', '#f5a623', '#636363', '#30d581', '#ffd05c', '#79d8ff', '#b8e986', '#7987ff', '#50e3c2', '#6bdacd', '#6f9ec6', '#72678b'];
                    var random_color = colors[Math.floor(Math.random() * colors.length)];
                    if (data.categoryname == "Recommended") {
                        $scope.recomendeddata.push({
                            parentid: data.parentid,
                            parentname: data.parentname,
                            idcategory: data.idcategory,
                            categoryname: categoryname,
                            level: data.level,
                            numoftenant: data.numoftenant,
                            color: random_color
                        })
                    } else {
                        $scope.tenantdata.push({
                            parentid: data.parentid,
                            parentname: data.parentname,
                            idcategory: data.idcategory,
                            categoryname: categoryname,
                            level: data.level,
                            numoftenant: data.numoftenant,
                            color: random_color
                        })
                    }
                })
            }
        });
    }
}
