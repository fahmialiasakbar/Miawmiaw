angular
    .module('livein')
    .controller('callCenter', callCenter)
    .controller('aboutHelp', aboutHelp)
    .controller('talkToUs', talkToUs);
// .controller('AuthorisationController', ['$state', '$ionicPopup', 'UserAuthorisationService', AuthorisationController]);

function callCenter($scope, $ionicLoading, $state, help, $filter) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Call Center';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    callCenter();

    function callCenter() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        help.callCenter(
            function (response) {
                if (response != false) {
                    $scope.data = response;
                    console.log($scope.data);
                } else {
                    $scope.data = { name: $filter('translate')('failed_get_data') };
                }
                $ionicLoading.hide();
            });
    };
}

function talkToUs($scope, $ionicLoading, $state, $ionicHistory, talktoUs, $filter) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Talk to Us';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };


    talkToUs();

    function talkToUs() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        talktoUs.getTalktoUs(function (response) {
            if (response != false) {
                $scope.datatalk = response;
            } else {
                $scope.datatalk = [{ name: $filter('translate')('no_data') }];
            }
            $ionicLoading.hide();
        });

    };
}


function aboutHelp($scope, $ionicModal, $sce, $localStorage, $window, $filter) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'About Us';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    if ($scope.lang == 'ina') {
        tentangLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/tentang_in.html";
        privacyLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/kebijakan_privasi_in.html";
        ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_in.html";
    } else {
        tentangLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/tentang_en.html";
        privacyLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/kebijakan_privasi_en.html";
        ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_en.html";
    }

    $scope.privacyLink = $sce.trustAsResourceUrl(privacyLink);
    $scope.tentangLink = $sce.trustAsResourceUrl(tentangLink);
    $scope.ketentuanLink = $sce.trustAsResourceUrl(ketentuanLink);

    $ionicModal.fromTemplateUrl('partials/sides/modalPrivacy.html', {
        scope: $scope
    }).then(function (modalHelp) {
        $scope.modalHelp = modalHelp;
    });

    $scope.openPrivacy = function () {
        $scope.modalHelp.show();
    };

    $ionicModal.fromTemplateUrl('partials/sides/modalTerms.html', {
        scope: $scope
    }).then(function (modalTerms) {
        $scope.modalTerms = modalTerms;
    });

    $scope.openTerms = function () {
        $scope.modalTerms.show();
    };

    $scope.closeModal = function () {
        $scope.modalHelp.hide();
        $scope.modalTerms.hide();
    };

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modalHelp.remove();
        $scope.modalTerms.remove();
    });

    $scope.openBrowser = function () {        
        if (device.platform === 'iOS') {
            $window.open('https://itunes.apple.com/id/app/lippo-cikarang/id1191438061?mt=8', '_system', 'location=yes');
        } else {
            window.open('https://play.google.com/store/apps/details?id=lippocikarang.com', '_system', 'location=no');
        }
        
    }
}