angular
  .module('livein')
  .controller('adsDetail', adsDetail);

function adsDetail($scope, $stateParams,$ionicHistory, $ionicLoading, AdvertisementService) {
    $scope.myGoBack = function(){
      $ionicHistory.goBack();
    }

  var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    AdvertisementService.getAdsDetail($stateParams.idAds, function (response) {
      if (response) {
          $scope.data = response;
          $scope.image = response.imagedetail[0];
          $ionicLoading.hide();
      } else {
          $ionicLoading.hide();
      }
  });

}
