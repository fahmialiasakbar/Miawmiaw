angular
  .module('livein')
  .controller('cctvFull', cctvFull)
  .controller('cctvDetail', cctvDetail);

function cctvDetail($scope, $state, $rootScope, $ionicLoading, $ionicNavBarDelegate, $ionicSlideBoxDelegate, $stateParams, $ionicHistory, $ionicModal, cctv, $filter, $sce) {
  console.log('Orientation is ' + screen.orientation.type);
  // ----- Analytic Screen
  if (window.ga) {
    var analyticView = 'CCTV Theather View';
    window.ga.trackView(analyticView);
    window.ga.trackEvent('Screen View', analyticView);
    console.log("Analytic - Screen View - " + analyticView);
  }

  if(window.hasOwnProperty('StatusBar')){
    StatusBar.show();
  }

  $ionicNavBarDelegate.showBackButton(false);
  $scope.myGoBack = function () {
    $state.go('app.cctvList');
  };
  $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

  var uri = "http://innodev.vnetcloud.com/cctv-client/?port=";
  $scope.tempSlideCCTVProd = [{
    'id': '0',
    'bahasa': $sce.trustAsResourceUrl(uri + "9999"),
    'port': '9999',
    'portIndex': '9999',
    'name': 'MG Mataram (Arah OC)',
    'portFull' : '0'
  },{
    'id': '1',
    'bahasa': $sce.trustAsResourceUrl(uri + "9998"),
    'port': '9998',
    'portIndex': '9998',
    'name': 'MG Mataram (Arah Residential)',
    'portFull' : '1'
  },{
    'id': '2',
    'bahasa': $sce.trustAsResourceUrl(uri + "9996"),
    'port': '9996',
    'portIndex': '9996',
    'name': 'Bunderan Cibodas (Arah Jl. Mataram)',
    'portFull' : '2'
  },{
    'id': '3',
    'bahasa': $sce.trustAsResourceUrl(uri + "9997"),
    'port': '9997',
    'portIndex': '9997',
    'name': 'MG Mataram (Arah Deltamas) ',
    'portFull' : '3'
  },{
    'id': '4',
    'bahasa': $sce.trustAsResourceUrl(uri + "9995"),
    'port': '9995',
    'portIndex': '9995',
    'name': 'Bunderan Cibodas (Arah Masuk Cluster)',
    'portFull' : '4'
  },{
    'id': '5',
    'bahasa': $sce.trustAsResourceUrl(uri + "9992"),
    'port': '9992',
    'portIndex': '9992',
    'name': 'Cibatu (Arah Maxxbox)',
    'portFull' : '5'
  },{
    'id': '6',
    'bahasa': $sce.trustAsResourceUrl(uri + "9991"),
    'port': '9991',
    'portIndex': '9991',
    'name': 'Cibatu (Arah Pintu Tol)',
    'portFull' : '6'
  },{
    'id': '7',
    'bahasa': $sce.trustAsResourceUrl(uri + "9990"),
    'port': '9990',
    'portIndex': '9990',
    'name': 'Cibatu (Helipad)',
    'portFull' : '7'
  }]

  // $scope.tempSlideCCTVDev = [{
  //   'id': '0',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9999"),
  //   'port': '9999',
  //   'portIndex': '9999',
  //   'name': 'MG Mataram (Arah OC)',
  //   'portFull' : '0'
  // },{
  //   'id': '1',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9998"),
  //   'port': '9998',
  //   'portIndex': '9998',
  //   'name': 'MG Mataram (Arah Residential)',
  //   'portFull' : '1'
  // },{
  //   'id': '2',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9997"),
  //   'port': '9997',
  //   'portIndex': '9997',
  //   'name': 'MG Mataram (Arah Deltamas)',
  //   'portFull' : '2'
  // },{
  //   'id': '3',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9996"),
  //   'port': '9996',
  //   'portIndex': '9996',
  //   'name': 'Bunderan Cibodas (Arah Jl. Mataram)',
  //   'portFull' : '3'
  // },{
  //   'id': '4',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9995"),
  //   'port': '9995',
  //   'portIndex': '9995',
  //   'name': 'Bunderan Cibodas (Arah Masuk Cluster)',
  //   'portFull' : '4'
  // },{
  //   'id': '5',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9994"),
  //   'port': '9994',
  //   'portIndex': '9994',
  //   'name': 'Maxxbox , Orange Country',
  //   'portFull' : '5'
  // },{
  //   'id': '6',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9993"),
  //   'port': '9993',
  //   'portIndex': '9993',
  //   'name': 'Maxxbox , Orange Country',
  //   'portFull' : '6'
  // },{
  //   'id': '7',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9992"),
  //   'port': '9992',
  //   'portIndex': '9992',
  //   'name': 'Cibatu (Arah Maxxbox)',
  //   'portFull' : '7'
  // },{
  //   'id': '8',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9991"),
  //   'port': '9991',
  //   'portIndex': '9991',
  //   'name': 'Cibatu (Arah Pintu Tol)',
  //   'portFull' : '8'
  // },{
  //   'id': '9',
  //   'bahasa': $sce.trustAsResourceUrl(uri + "9990"),
  //   'port': '9990',
  //   'portIndex': '9990',
  //   'name': 'Cibatu (Helipad)',
  //   'portFull' : '9'
  // }]

  $scope.tempSlideCCTVDev = [{
    'id': '0',
    'bahasa': $sce.trustAsResourceUrl(uri + "9999"),
    'port': '9999',
    'portIndex': '9999',
    'name': 'MG Mataram (Arah OC)',
    'portFull' : '0'
  },{
    'id': '1',
    'bahasa': $sce.trustAsResourceUrl(uri + "9998"),
    'port': '9998',
    'portIndex': '9998',
    'name': 'MG Mataram (Arah Residential)',
    'portFull' : '1'
  },{
    'id': '2',
    'bahasa': $sce.trustAsResourceUrl(uri + "9997"),
    'port': '9997',
    'portIndex': '9997',
    'name': 'Bunderan Cibodas (Arah Jl. Mataram)',
    'portFull' : '2'
  },{
    'id': '3',
    'bahasa': $sce.trustAsResourceUrl(uri + "9996"),
    'port': '9996',
    'portIndex': '9996',
    'name': 'MG Mataram (Arah Deltamas)',
    'portFull' : '3'
  },{
    'id': '4',
    'bahasa': $sce.trustAsResourceUrl(uri + "9995"),
    'port': '9995',
    'portIndex': '9995',
    'name': 'Bunderan Cibodas (Arah Masuk Ciputra)',
    'portFull' : '4'
  },{
    'id': '5',
    'bahasa': $sce.trustAsResourceUrl(uri + "9992"),
    'port': '9992',
    'portIndex': '9992',
    'name': 'Cibatu (Arah Maxxbox)',
    'portFull' : '5'
  },{
    'id': '6',
    'bahasa': $sce.trustAsResourceUrl(uri + "9991"),
    'port': '9991',
    'portIndex': '9991',
    'name': 'Cibatu (Arah Pintu Tol)',
    'portFull' : '6'
  },{
    'id': '7',
    'bahasa': $sce.trustAsResourceUrl(uri + "9990"),
    'port': '9990',
    'portIndex': '9990',
    'name': 'Cibatu (Helipad)',
    'portFull' : '7'
  }]

  function getCCTV(gall){
    var link = $filter('translate')('apilink');
    if (link.includes("innoprod")) {
      console.log("haloo cctv prod");
      console.log("weh gilak : " + $rootScope.portFull);
      $scope.slideCCTV = [];

      var a = 0;
      angular.forEach($scope.tempSlideCCTVProd, function() {
        var b = a++;
        var result = $scope.tempSlideCCTVProd[b];
        if(gall == result.id || $rootScope.portFull == result.portFull){
          $scope.bahasa = $sce.trustAsResourceUrl(uri + result.port);
          $scope.port = result.port;
          $rootScope.portIndex = $scope.port;
          $scope.name = result.name;

          $scope.slideCCTV.push({
            'bahasa': $scope.bahasa,
            'port': $scope.port,
            'portIndex': $rootScope.portIndex,
            'name': $scope.name
          });
        }
      });

      // if (gall == '0' || $rootScope.portFull == '0') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9999");
      //   $scope.port = "9999";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah OC)';
      // } else if (gall == '1' || $rootScope.portFull == '1') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9998");
      //   $scope.port = "9998";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah Residential)';
      // } else if (gall == '2' || $rootScope.portFull == '2') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9996");
      //   $scope.port = "9996";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah Deltamas)';
      // } else if (gall == '3' || $rootScope.portFull == '3') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9997");
      //   $scope.port = "9997";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Bunderan Cibodas (Arah Jl. Mataram)';
      // } else if (gall == '4' || $rootScope.portFull == '4') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9995");
      //   $scope.port = "9995";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Bunderan Cibodas (Arah Masuk Cluster)';
      // } else if (gall == '5' || $rootScope.portFull == '5') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9992");
      //   $scope.port = "9992";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Arah Maxxbox)';
      // } else if (gall == '6' || $rootScope.portFull == '6') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9991");
      //   $scope.port = "9991";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Arah Pintu Tol)';
      // } else if (gall == '7' || $rootScope.portFull == '7') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9990");
      //   $scope.port = "9990";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Helipad)';
      // }
    } else {
      console.log("haloo cctv dev");
      $scope.slideCCTV = []
     
      var a = 0;
      angular.forEach($scope.tempSlideCCTVDev, function() {
        var b = a++;
        var result = $scope.tempSlideCCTVDev[b];
        if(gall == result.id || $rootScope.portFull == result.portFull){
          $scope.bahasa = $sce.trustAsResourceUrl(uri + result.port);
          $scope.port = result.port;
          $rootScope.portIndex = $scope.port;
          $scope.name = result.name;

          $scope.slideCCTV.push({
            'bahasa': $scope.bahasa,
            'port': $scope.port,
            'portIndex': $rootScope.portIndex,
            'name': $scope.name
          });
        }
      });

      // if (gall == '0' || $rootScope.portFull == '0') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9999");
      //   $scope.port = "9999";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah OC)';
      // } else if (gall == '1' || $rootScope.portFull == '1') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9998");
      //   $scope.port = "9998";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah Residential)';
      // } else if (gall == '2' || $rootScope.portFull == '2') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9997");
      //   $scope.port = "9997";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Bunderan Cibodas (Arah Jl. Mataram)';
      // } else if (gall == '3' || $rootScope.portFull == '3') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9996");
      //   $scope.port = "9996";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'MG Mataram (Arah Deltamas)';
      // } else if (gall == '4' || $rootScope.portFull == '4') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9995");
      //   $scope.port = "9995";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Bunderan Cibodas (Arah Masuk Cluster)';
      // } else if (gall == '5' || $rootScope.portFull == '5') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9994");
      //   $scope.port = "9994";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Maxxbox , Orange Country';
      // } else if (gall == '6' || $rootScope.portFull == '6') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9993");
      //   $scope.port = "9993";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Maxxbox , Orange Country';
      // } else if (gall == '7' || $rootScope.portFull == '7') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9992");
      //   $scope.port = "9992";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Arah Maxxbox)';
      // } else if (gall == '8' || $rootScope.portFull == '8') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9991");
      //   $scope.port = "9991";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Arah Pintu Tol)';
      // } else if (gall == '9' || $rootScope.portFull == '9') {
      //   $scope.bahasa = $sce.trustAsResourceUrl(uri + "9990");
      //   $scope.port = "9990";
      //   $rootScope.portIndex = $scope.port;
      //   $scope.name = 'Cibatu (Helipad)';
      // }
    }
  }
  
  cctv.cctvList(function (response) {
    if (response != false) {
      $scope.detail = response;
      var gall = $stateParams.index;
      $rootScope.portCCTV = gall;

      // if($rootScope.portCCTV)
      // $scope.port = $rootScope.portCCTV;

      $scope.gall = gall;
      $scope.max = ((response.length) - 1);
      $scope.min = 0;

      //$scope.listDetail = $scope.detail[gall].link;
      //var videoUrl = $scope.listDetail;
      $scope.slideCCTV = [];
      getCCTV($scope.gall);
      
    } else {
      $scope.data = { name: $filter('translate')('failed_get_data') };
    }

    $ionicLoading.hide();
  });
  //$ionicHistory.goBack();
  $scope.slideChanged = function () {
    $ionicSlideBoxDelegate.update();
  };

  $scope.next = function (gall) {
    $scope.gall = gall;
    getCCTV(gall)
    $ionicSlideBoxDelegate.next();
  };

  $scope.previous = function (gall) {
    $scope.gall = gall;
    getCCTV(gall)
    $ionicSlideBoxDelegate.previous();
  };
};

function cctvFull($scope, $state, $rootScope, $ionicLoading, $ionicSlideBoxDelegate, $stateParams, $ionicHistory, $ionicModal, cctv, $filter, $sce) {
  $scope.potrait = potrait;
  $scope.potraitMulti = potraitMulti;
  $scope.potraitTheater = potraitTheater;

  if(window.hasOwnProperty('StatusBar')){
    StatusBar.hide();
}

  var uri = "http://innodev.vnetcloud.com/cctv-client/?port=";
  // var port = $stateParams.index;
  var portIndex = $rootScope.portIndex;
  var index = $rootScope.portCCTV;

  $scope.port = $sce.trustAsResourceUrl(uri + portIndex);

  function potrait() {
    screen.orientation.lock('portrait');
    $state.go('app.cctvList'); //, {port: port}
  }

  function potraitMulti() {
    screen.orientation.lock('portrait');
    $state.go('app.cctvMulti');
  }

  function potraitTheater() {
    $rootScope.portFull = index;
    screen.orientation.lock('portrait');
    $state.go('app.cctvDetail');
  }

};
