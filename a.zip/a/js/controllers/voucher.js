angular
    .module('livein')
    .controller('listVoucher', listVoucher)
    .controller('voucherDetail', voucherDetail);

function listVoucher($rootScope,$filter, $ionicLoading, $timeout, $rootScope, $stateParams, $state, $ionicLoading, $cordovaSocialSharing, $scope, $ionicHistory, $ionicModal, PointService, $localStorage, $cordovaGeolocation) {
    $scope.id_category = $stateParams.id_category;
    $scope.fakelist=[1,2,3,4];
    $scope.searchVoucher = searchVoucher;
    $scope.showSort = showSort;
    $scope.showFilter = showFilter;
    $scope.showHideFilter = showHideFilter;
    $scope.functSort = functSort;
    $scope.redeem = redeem;
    $scope.redeemOvo = redeemOvo;
    $scope.isFilter; 
    $scope.isSort;  
    $scope.data; 
    $scope.ovoId='';
    $scope.myPoint = $localStorage.currentPoint; 
    $scope.haveOutstandingModal = haveOutstandingModal;
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    }; 

    

    $rootScope.isRedeemed = false;
    $rootScope.footerMyPoint = false;

    getBillingOutstanding();
    function getBillingOutstanding(){    
        $scope.billingOutstandingStatus = 1;
        if($localStorage.billingOutstandingBalance >= 0 || $localStorage.billingOutstandingBalance <= 0){
            if ($localStorage.billingOutstandingBalance == 0) {
                $scope.billingOutstandingStatus = 0;
            }else if($localStorage.billingOutstandingBalance == -1){
                $scope.billingOutstandingStatus = 2;
            }
            
        }
    }

    $scope.checkOutstanding = function(){
        if($scope.data){
            if($scope.billingOutstandingStatus == 0){
                return true;
            }
        }
        return false;
    }

    $scope.goRedeem = goRedeem;
     function goRedeem (data){
        $scope.data = data;
        $scope.title = data.title;
        $scope.title_id = data.title_id;
        $scope.point = data.point;
        $scope.status='newvoucher';
        $rootScope.idvoucher = data.id;

        $scope.checkCanRedeem = function(){
            if($scope.data){
                if($scope.myPoint>=$scope.data.point && $scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher($scope.data.expired_date)){
                    return true;
                }
            }
            return false;
        }
    
        $scope.checkPoint = function(){
            if($scope.data){
                if($scope.myPoint>=$scope.data.point){
                    return true;
                }
            }
            return false;
        }
    
        $ionicModal.fromTemplateUrl('partials/sides/redeemModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModal = modalMenu;
            $scope.redeemModal.show();
        });
    }

    $scope.goRedeemOvo = goRedeemOvo;
     function goRedeemOvo (data){
        $scope.data = data;
        $scope.title = data.title;
        $scope.title_id = data.title_id;
        $scope.point = data.point;
        $scope.status='newvoucher';
        $rootScope.idvoucher = data.id;

        $scope.checkCanRedeem = function(){
            if($scope.data){
                if($scope.myPoint>=$scope.data.point && $scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher($scope.data.expired_date)){
                    return true;
                }
            }
            return false;
        }
    
        $scope.checkPoint = function(){
            if($scope.data){
                if($scope.myPoint>=$scope.data.point){
                    return true;
                }
            }
            return false;
        }

        $scope.checkOutstanding = function(){
            if($scope.data){
                if($scope.billingOutstandingStatus == 0){
                    return true;
                }
            }
            return false;
        }

        $ionicModal.fromTemplateUrl('partials/tabs/profile/redeemModalOvo.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModalOvo = modalMenu;
            $scope.redeemModalOvo.show();
        });
    }

    $scope.closeRedeemOvo = function(){
        $scope.redeemModalOvo.hide();
    }

    $scope.closeRedeem = function(){
        $scope.redeemModal.hide();
    }

    function redeem(){
        if(!$scope.checkOutstanding()){
            $scope.haveOutstandingModal();
        }else{
            var type = 'regular';
            var idvoucher = $rootScope.idvoucher;
            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
            PointService.redeemVoucher(idvoucher, function (response){
                if(response){
                    if(response.statusCode == 10){
                        $localStorage.currentPoint = response.mypoint;
                        $rootScope.successRedeem = true;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    } else {
                        $rootScope.successRedeem = false;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    }
                }else{
                }
            });
            
        }
        
    }

    function redeemOvo(ovoid){
        if(!$scope.checkOutstanding()){
            $scope.haveOutstandingModal();
        }else{
            var type = 'ovo';
            var ovoid = ovoid;
            var idvoucher = $rootScope.idvoucher;
            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');     
            PointService.redeemVoucherOvo(idvoucher, ovoid, function (response){
                if(response){
                    if(response.statusCode == 10){
                        $localStorage.currentPoint = response.mypoint;
                        $rootScope.successRedeem = true;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    } else {
                        $rootScope.successRedeem = false;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    }
                }else{
                }
            });
        }
    }


    
    $scope.goRedeemSuccess = goRedeemSuccess;
    function goRedeemSuccess (type){
        $scope.successRedeem = $rootScope.successRedeem;
        $scope.messageRedeem = $rootScope.messageRedeem;
        var type = type;
        if(type=='regular'){
            $scope.redeemModal.hide();
        }else if(type=='ovo'){
            $scope.redeemModalOvo.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/redeemSuccessModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemSuccessModal = modalMenu;
            $scope.redeemSuccessModal.show();
        });
    }

    $scope.closeRedeemSuccess = function(){
        $scope.redeemSuccessModal.hide();
        location.reload();
    }

    function haveOutstandingModal(){
        if($scope.redeemModal){
            $scope.redeemModal.hide();
        }else if($scope.redeemModalOvo){
            $scope.redeemModalOvo.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/haveOutstandingModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.haveOutstanding = modalMenu; 
            $scope.haveOutstanding.show();
        });
    }

    $scope.closeHaveOutstanding = function(){
        $scope.haveOutstanding.hide();
    }

    $scope.goPayment = function(){
        $state.go('app.billing');
        $ionicHistory.nextViewOptions({
            disableBack: true
        });
    }

    $scope.goMyVoucher = function(){
        $scope.redeemSuccessModal.hide();
        $rootScope.footerMyPoint = true;
        $state.go('app.point');
    }

    function showFilter(){
        $scope.isFilter = true;
        $scope.isSort = false;
        $scope.title="filter";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
        $scope.dataFilter.distance = 0;
    }

    function showHideFilter(id){
        if(id == 1){
            $scope.filter1 = !$scope.filter1;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 2){
            $scope.filter1 = false;
            $scope.filter2 = !$scope.filter2;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 3){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = !$scope.filter3;
            $scope.filter4 = false;
        } else if(id == 4){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = !$scope.filter4;
        }
    }


    function showSort(){
        $scope.isFilter = false;
        $scope.isSort = true;
        $scope.title="sort";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
    }

    function searchVoucher(){
        $ionicModal.fromTemplateUrl('partials/sides/searchNewVoucher.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.searchNewVoucher = modalMenu;
            $scope.searchNewVoucher.show();
        });
    }

    $scope.closeModalSearch = function(){
        $scope.searchNewVoucher.hide();
    }

    $scope.closeModal = function(){
        $scope.pointFilterSortModal.hide();
        $scope.isFilter = false;
        $scope.isSort = false;
        if($rootScope.dataSorting == "low"){
            $scope.dataSort.value = 1
        } else if($rootScope.dataSorting == "high"){
            $scope.dataSort.value = 2
        } else if($rootScope.dataSorting == "availability"){
            $scope.dataSort.value = 3
        }
    }

    
    $scope.goPoint = function(){
        $scope.redeemSuccessModal.hide();
        $state.go('app.point');
    }
    
    getVoucher();
    function getVoucher(){
        $scope.userpoint = $localStorage.currentPoint;
        if($localStorage.currentPoint==''){
            $scope.userpoint=1000;
        }
        $localStorage.currentPoint = $scope.userpoint;
        var pagenumber = 1;
        PointService.listHomeVoucher(pagenumber, function(response){
            if (response != false) {
                getAllVoucher(response.cats);

                if (window.ga) {
                    var analyticView = 'List All Voucher';
                    window.ga.trackView(analyticView);
                    window.ga.trackEvent('Screen View', analyticView);
                    console.log("Analytic - Screen View - " + analyticView);
                }
            }else{
                $ionicLoading.hide();
            }
        });
    }

    $scope.voucher;
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    $scope.titlePage;
    function getAllVoucher(voucher){
        $scope.allVoucher = [];
        for(var i=0; i<voucher.length; i++){
            if(voucher[i].id == $scope.id_category){
                if(lang == 'en') {
                    $scope.titlePage = voucher[i].name;
                }
                else{
                    $scope.titlePage = voucher[i].name_id;
                }
            } 
        }
        if($scope.titlePage == null){
            setDefaultTitle();
        }
    }

    function setDefaultTitle(){
        if($scope.titlePage == null){
            if(lang == 'ina'){
                $scope.titlePage = 'Cari';
            } else{
                $scope.titlePage = 'Search';
            }
        }
    }

    function getFormattedWorth(getWorth) {
        var worth = reverseString(getWorth.toString());
        var newWorth = '';
        for (var i = 0; i < worth.toString().length; i++) {
            if (newWorth.length % 4 == 0) {
                newWorth += '.';
            }
            newWorth += worth.toString().charAt(i);
        }
        var show = newWorth.slice(1);
        return reverseString(show);
    }

    function reverseString(str) {
        return str.split("").reverse().join("");
    }
 

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    } 
    $scope.dateNow = function(){
        var dt = moment('YYYY-MM-DD HH:mm').toDate();
        return dt;
    } 
    
    function getListVoucher(response){
        $timeout(function(){
            console.log($scope.lat)
            $scope.getVoucher = response;
            $scope.dataList = [];
            var a = 0;
            angular.forEach($scope.getVoucher, function (obj) {
                var b = a++;
                var list = $scope.getVoucher;
                var getVoucher = list[b];
                // var distance = calculatdistance(getVoucher.tenant.latitude+","+ getVoucher.tenant.longitude);
                var worth = getFormattedWorth(getVoucher.worth);
                var currentTime = $scope.dateNow();
                var expired = $scope.strToDate(getVoucher.expired_date);
                if(expired< new Date){
                    var setatis = 'expired';
                }else{
                    var setatis = 'available';
                }
                $scope.dataList.push({
                    id: getVoucher.id,
                    title: getVoucher.title,
                    distance: calculatdistance(getVoucher.tenant.latitude+","+ getVoucher.tenant.longitude),
                    tenant:getVoucher.tenant,
                    point:getVoucher.point,
                    worth:getVoucher.worth,
                    status:setatis,
                    type:getVoucher.type,
                    expired_date:getVoucher.expired_date,
                    created_date:getVoucher.created_date,
                    title_id:getVoucher.title_id,
                    image:getVoucher.image
                });
            });
            $ionicLoading.hide();
        }, 2000)

        var i = 2;
        $scope.loadMore = function () {
            pagenumber = i;
            PointService.listVoucher($stateParams.id_category, pagenumber, function (response) {
                if (response) {       
                    var a=0;
                    angular.forEach(response, function(){
                        var b = a++;
                        var expired = $scope.strToDate(response[b].expired_date);
                        if(expired< new Date){
                            var setatis = 'expired';
                        }else{
                            var setatis = 'available';
                        }
                        dataLoadmore = [{
                            id : response[b].id,
                            title : response[b].title,
                            tenant : response[b].tenant,
                            point : response[b].point,
                            worth : getFormattedWorth(response[b].worth),
                            available : response[b].available,
                            expired_date : response[b].expired_date,
                            created_date : response[b].created_date,
                            type: response[b].type,
                            image : response[b].image,
                            status : setatis,
                            distance : calculatdistance(response[b].tenant.latitude+","+ response[b].tenant.longitude)
                        }];
                        $scope.dataList = $scope.dataList.concat(dataLoadmore);
                    })
                    
                } else {
                    console.log('no more data loaded');
                }
            });
            $scope.$broadcast('scroll.infiniteScrollComplete');
            i++;
        };
    }
    
    $scope.dataSort = [];
    $scope.resetSort = function (){
        $scope.dataSort = [];
        $scope.closeModal();
        getData();
        $scope.dataSort.value = ""
    };

    function functSort(){
        var value = $scope.dataSort.value;
        $rootScope.dataSorting;
        if(value == 1){
            $rootScope.dataSorting = "low"
        } else if(value == 2){
            $rootScope.dataSorting = "high"
        } else if(value == 3){
            $rootScope.dataSorting = "availability"
        }
        $scope.closeModal();
        $state.go('app.listVoucher', {id_category:99})
    }

    $rootScope.getDataListVoucher = getDataListVoucher
    getDataListVoucher();
    function getDataListVoucher(){ 
        $ionicLoading.show({ template: $filter('translate')('loading') + "..."});
        var posOptions = { timeout: 10000, enableHighAccuracy: true };
        $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            $scope.lat = position.coords.latitude;
            $scope.long = position.coords.longitude;
        });       
        var pagenumber = 1;
        // if($rootScope.idSearchPoint) $stateParams.id_category = $rootScope.idSearchPoint;
        // if($stateParams.id_category == 99){

            if($rootScope.dataFilter == undefined) $rootScope.dataFilter = []
            if($rootScope.dataSorting == undefined) $rootScope.dataSorting = ''
            if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
            if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
            if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
            if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
            if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
            if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''

            if($rootScope.dataFilter.distance == 0 || $rootScope.dataFilter.distance == undefined || $rootScope.dataFilter.distance == ''){
                $scope.lat = ""
                $scope.long = ""
            }

            if (window.ga) {
                var analyticView = 'Filter and Sorting Voucher';
                window.ga.trackView(analyticView);
                window.ga.trackEvent("Screen View", analyticView);
                if($rootScope.dataSorting != undefined && $rootScope.dataSorting != "") {
                    window.ga.trackEvent("Sorting", $rootScope.dataSorting, analyticView);
                    console.log("Analytic - Sorting - " + $rootScope.dataSorting +"-"+ analyticView);
                }
                if($rootScope.dataFilter.dateFrom != undefined && $rootScope.dataFilter.dateFrom != "" && $rootScope.dataFilter.dateTo != undefined && $rootScope.dataFilter.dateTo != "") {
                    window.ga.trackEvent("Filter Availability", $rootScope.dataFilter.dateFrom +" - "+$rootScope.dataFilter.dateTo, analyticView);
                    console.log("Analytic - Filter Availability - " + $rootScope.dataFilter.dateFrom +"-"+$rootScope.dataFilter.dateTo +"-"+ analyticView);
                }
                
                if($rootScope.dataFilter.status != undefined && $rootScope.dataFilter.status != "") {
                    window.ga.trackEvent("Filter Voucher Status", $rootScope.dataFilter.status, analyticView);
                    console.log("Analytic - Filter Voucher Status - " + $rootScope.dataFilter.status +"-"+ analyticView);
                }
                if($rootScope.dataFilter.mypoint != undefined && $rootScope.dataFilter.mypoint != "") {
                    window.ga.trackEvent("Filter Current Point", $rootScope.dataFilter.mypoint, analyticView);
                    console.log("Analytic - Filter Current Point - " + $rootScope.dataFilter.mypoint +"-"+ analyticView);
                }
                if($rootScope.dataFilter.point != undefined && $rootScope.dataFilter.point != "") {
                    window.ga.trackEvent("Filter Point", $rootScope.dataFilter.point, analyticView);
                    console.log("Analytic - Filter Point - " + $rootScope.dataFilter.point +"-"+ analyticView);
                }
                if($rootScope.dataFilter.distance != undefined && $rootScope.dataFilter.distance != "") {
                    window.ga.trackEvent("Filter Distance", $rootScope.dataFilter.distance, analyticView);
                    console.log("Analytic - Filter Distance - " + $rootScope.dataFilter.distance +"-"+ analyticView);
                }
                console.log("Analytic - Screen View - " + analyticView);
            }
            
            PointService.getVoucher(
                $stateParams.id_category,
                $rootScope.dataFilter.mypoint,
                $rootScope.dataFilter.distance,$scope.lat,$scope.long,
                '',
                $rootScope.dataSorting,pagenumber,
                $rootScope.dataFilter.point,
                $rootScope.dataFilter.dateFrom,
                $rootScope.dataFilter.dateTo,
                $rootScope.dataFilter.status,
                function(response){
                if (response.status != false) {
                    getListVoucher(response)
                } else{
                    $scope.dataList = [];
                    $ionicLoading.hide();
                }
                
            })
        // } else{
        //     PointService.listVoucher($stateParams.id_category, pagenumber, function (response) {
        //         if (response != false) {
        //             getListVoucher(response)
        //         } else {
        //         }
        //         $ionicLoading.hide();
        //     });
        // }
    }

    

    var calculatdistance = function (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);
            if($scope.lat == ""){
                var posOptions = { timeout: 10000, enableHighAccuracy: true };
                $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
                    $scope.lat = position.coords.latitude;
                    $scope.long = position.coords.longitude;
                });
                
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
                var dLon = deg2rad($scope.long - longtenant);
                
                var a =
                    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2);
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                var d = R * c; // Distance in km
            }else{
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
                var dLon = deg2rad($scope.long - longtenant);
                
                var a =
                    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2);
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                var d = R * c; // Distance in km
            }
            
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

}


function voucherDetail($rootScope,$cordovaGeolocation, billingServices, $cordovaSocialSharing, $ionicLoading, $filter, $scope, $ionicHistory, $ionicModal, $state, PointService, $stateParams, $ionicLoading, $localStorage){
    $scope.myPoint = $localStorage.currentPoint; 
    $scope.redeem = redeem;
    $scope.redeemOvo = redeemOvo;
    $scope.ovoId='';
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
        $rootScope.footerMyPoint = $scope.tempFooterMyPoint;
    };

    if($rootScope.showButton==false){
        $scope.showButton=false;
    }else{
        $scope.showButton=true;
    }

    if($rootScope.isRedeemed==true){
        $scope.redeemButton = false;
    }else{
        $scope.redeemButton = true;
    }
    $scope.tempFooterMyPoint = $rootScope.footerMyPoint;
    $rootScope.footerMyPoint = false;
    $scope.tab1 = false;
    $scope.tab2 = false;
    $scope.tab3 = false;
    $rootScope.tabDetail ? tabClickedFunc(2) : tabClickedFunc(1);
    $scope.tabClicked = tabClickedFunc;
    function tabClickedFunc(tab) {
        if (tab == 1) {
            $scope.tab1 = true;
            $scope.tab2 = false;
            $scope.tab3 = false;
        } else if (tab == 2) {
            $scope.tab1 = false;
            $scope.tab2 = true;
            $scope.tab3 = false;
        } else if (tab == 3) {
            $scope.tab1 = false;
            $scope.tab2 = false;
            $scope.tab3 = true;
        }
    }


    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    } 
    PointService.detailVoucher($stateParams.id, function (response) {
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        if (response != false) {
            $scope.data = response;
            var distance = calculatdistance(response.tenant.latitude+","+ response.tenant.longitude);
            $scope.distance = distance;
            $scope.idvoucher = response.id;
            $scope.type = response.type;
            $scope.gallery = response.image[0];
            $scope.used_date = $scope.strToDate(response.used_date);
            var expired_date = $scope.strToDate(response.expired_date);
            $scope.expired_date = expired_date;
            $scope.total = Number(response.available) + Number(response.reedem_voucher);
            $scope.worth = getFormattedWorth(response.worth);
            $scope.unredeem = response.available;
            $ionicLoading.hide();
            $scope.color1 = randomColor();
            $scope.color2 = randomColor();
            $scope.color3 = randomColor();
            $scope.initial = Array.prototype.map.call(response.title.split(" "), function (x) { return x.substring(0, 1).toUpperCase(); }).join('');
            
            if($scope.lang=='ina'){
                var months = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
            }else{
                var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
            }

            if(response.used_date==null){
                $scope.month = months[$scope.expired_date.getMonth()];
            }else{
                $scope.month = months[$scope.used_date.getMonth()];
            }



            if(response.redeemed){
                $scope.isRedeemedDate = $scope.strToDate(response.redeemed_date);
            }

            // ----- Analytic Screen
            var dataAnalytic = {
                tenantName: response.tenant.name,
                distance: Math.round($scope.distance) + ' Km',
                expired_date: response.expired_date,
                title: response.title,
                point: response.point + ' Point',
                available: response.available +' from '+ $scope.unredeem
            }

            console.log('Voucher ' + JSON.stringify(dataAnalytic))
            if (window.ga) {
                var analyticView = 'Voucher ' + response.title + " - " + response.tenant.name;
                window.ga.trackView(analyticView);
                window.ga.trackEvent("Tenant Name", response.tenant.name, analyticView);
                window.ga.trackEvent("Distance", Math.round($scope.distance) + ' Km', analyticView);
                window.ga.trackEvent("Expired Date", response.expired_date, analyticView);
                window.ga.trackEvent("Title", response.title, analyticView);
                window.ga.trackEvent("Point", response.point + ' Point', analyticView);
                window.ga.trackEvent("Available", response.available +' from '+ $scope.unredeem, analyticView);
                console.log("Analytic - " + response.title + " - " + analyticView, analyticView);
            }
        } else {

            $ionicLoading.hide();
        }
    });

    function randomColor(){
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    function getFormattedWorth(getWorth) {
        var worth = reverseString(getWorth.toString());
        var newWorth = '';
        for (var i = 0; i < worth.toString().length; i++) {
            if (newWorth.length % 4 == 0) {
                newWorth += '.';
            }
            newWorth += worth.toString().charAt(i);
        }
        var show = newWorth.slice(1);
        return reverseString(show);
    }

    function reverseString(str) {
        return str.split("").reverse().join("");
    }
 

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    var calculatdistance = function (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);

            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
            var dLon = deg2rad($scope.long - longtenant);
            var a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

    $scope.goRedeem = goRedeem;
     function goRedeem (idvoucher){
        $rootScope.idvoucher = idvoucher;
        $scope.myPoint = $localStorage.currentPoint; 
        $ionicModal.fromTemplateUrl('partials/sides/redeemModal.html', {
            scope: $scope 
        }).then(function (modalMenu) {
            $scope.redeemModal = modalMenu;
            $scope.redeemModal.show();
        });
    } 

    $scope.closeRedeem = function(){
        $scope.redeemModal.hide();
    }

    $scope.goRedeemOvo = goRedeemOvo;
     function goRedeemOvo(idvoucher){
        $rootScope.idvoucher = idvoucher;
        $scope.myPoint = $localStorage.currentPoint; 
        $ionicModal.fromTemplateUrl('partials/tabs/profile/redeemModalOvo.html', {
            scope: $scope 
        }).then(function (modalMenu) {
            $scope.redeemModalOvo = modalMenu;
            $scope.redeemModalOvo.show();
        });
    }

    $scope.closeRedeemOvo = function(){
        $scope.redeemModalOvo.hide();
    }

    function redeem(){
        var type = 'regular';
        var idvoucher = $rootScope.idvoucher;
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.redeemVoucher(idvoucher, function (response){
            if(response){
                if(response.statusCode == 10){
                    $localStorage.currentPoint = response.mypoint;
                    $rootScope.successRedeem = true;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                } else {
                    $rootScope.successRedeem = false;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                }
            }else{
            }
        });
        
    }

    function redeemOvo(ovoid){
        if(!$scope.checkCanRedeem()){
            var message = $filter('translate')('sufficient_point');
            if($scope.billingOutstandingStatus == 1){                
                message = $filter('translate')('you_have')+ " " + $filter('translate')('outstanding');
            }else if($scope.billingOutstandingStatus == 2){          
                message = $filter('translate')('outstanding_not_found');
            }
            $ionicLoading.show({ template: message, duration: 1500});
 
            return false;
        }

        $ionicLoading.show({ template: $filter('translate')('loading')+"..."});
        var type = 'ovo';
        var ovoid = ovoid;
        var idvoucher = $rootScope.idvoucher;
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.redeemVoucherOvo(idvoucher, ovoid, function (response){
            if(response){
                $ionicLoading.hide();
                if(response.statusCode == 10){
                    $localStorage.currentPoint = response.mypoint;
                    $rootScope.successRedeem = true;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                } else {
                    $rootScope.successRedeem = false;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                }
            }else{
            }
        });
        
    }

    
    $scope.goRedeemSuccess = goRedeemSuccess;
    function goRedeemSuccess(type){
        var type = type;
        if(type=='ovo'){
            $scope.redeemModalOvo.hide();
        }else if(type=='regular'){
            $scope.redeemModal.hide();
        }
        $scope.successRedeem = $rootScope.successRedeem;
        $scope.messageRedeem = $rootScope.messageRedeem;
        $ionicModal.fromTemplateUrl('partials/sides/redeemSuccessModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemSuccessModal = modalMenu;
            $scope.redeemSuccessModal.show();
        });
    }

    $scope.closeRedeemSuccess = function(){
        $scope.redeemSuccessModal.hide();
        $scope.redeemButton = false;
    }

    $scope.goPoint = function(){
        $scope.redeemSuccessModal.hide();
        $state.go('app.point');
    }
    
    $scope.goMyVoucher = function(){
        $scope.redeemSuccessModal.hide();
        $rootScope.footerMyPoint = true;
        $state.go('app.point');
    }

    $scope.showOutstandingInfo = function (){
        $ionicModal.fromTemplateUrl('partials/sides/outstandingModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.outstandingModal = modalMenu;
            $scope.outstandingModal.show();
        });
    }

    $scope.goBilling = function(){
        $state.go('app.billing');
    }

    $scope.closeOutstanding = function(){
        $scope.outstandingModal.hide();
    } 

    getBillingOutstanding();
 
    function getBillingOutstanding(){    
        $scope.billingOutstandingStatus = 1;
        if($localStorage.billingOutstandingBalance >= 0 || $localStorage.billingOutstandingBalance <= 0){
            if ($localStorage.billingOutstandingBalance == 0) {
                $scope.billingOutstandingStatus = 0;
            }else if($localStorage.billingOutstandingBalance == -1){
                $scope.billingOutstandingStatus = 2;
            }
            
        }
    }


    $scope.shareVoucher = function(){  
        var title = $scope.data.title;
        var ex_date = $scope.strToDate($scope.data.expired_date);
        
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };                  
        var expired_date = ex_date.toLocaleDateString("en-US", options);

        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

        if($scope.lang == 'ina'){
            title = $scope.data.title_id;
        }
        var str = 'Get voucher "'+ title +'" available until ' + expired_date + ' on Lippo Cikarang Mobile Apps';
        $cordovaSocialSharing.share(str, null, null, $filter('translate')('link_apps_store')).then(function (result) {
            console.log('Success Share voucher');
        }, function (error) {
            console.log('Failed Share voucher' + JSON.stringify(error));
        });
        
        // ----- Analytic Screen
        if (window.ga) {
            var analyticView = 'Share Voucher';
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Share Voucher', analyticView);
            console.log("Analytic - Share Voucher - " + analyticView);
        }
    }
 
    $scope.checkCanRedeem = function(){
        if($scope.data){
            if($scope.myPoint>=$scope.data.point && $scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher($scope.data.expired_date)){
                return true;
            }
        }
        return false;
    }

    $scope.checkPoint = function(){
        if($scope.data){
            if($scope.myPoint>=$scope.data.point){
                return true;
            }
        }
        return false;
    }

    $scope.checkOutstanding = function(){
        if($scope.data){
            if($scope.billingOutstandingStatus == 0){
                return true;
            }
        }
        return false;
    }

    $scope.checkExpired = function(){
        if($scope.data){
            if(!$scope.checkExpiredVoucher($scope.data.expired_date)){
                return true;
            }
        }
        return false;
    }

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate(); 
        return dt;
    }

    $scope.checkExpiredVoucher = function(dateExpired){
        var date = $scope.strToDate(dateExpired);
        if(date > new Date){
            return false;
        }        
        return true;
    }

    $scope.checkExpired = function(){
        if($scope.data){
            if($scope.checkExpiredVoucher($scope.data.expired_date)){
                return true;
            }
        }
        return false;
    }

    $scope.useVoucher = function(item){
        $scope.isSuccessUseVoucher = false;
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        $scope.usevoucher;
        
        if(item){
            $scope.voucher_title = $scope.lang == 'en' ? item.title : item.title_id;
            $scope.usevoucher = item;
            if(item.expired_date == null && item.expired_date == undefined && item.expired_date == ""){
                $scope.expireddateUseVoucher = "-";
            } else{
                $scope.expireddateUseVoucher = $scope.strToDate(item.expired_date);
            }
        }
        
        $ionicModal.fromTemplateUrl('partials/tabs/profile/useMyVoucher.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.usevoucherModal = modalMenu; 
            $scope.usevoucherModal.show();
        });
    }

    $scope.closeUseVoucherModal = function(){
        $scope.usevoucherModal.hide();
    }

    $rootScope.tabDetail = false;
    $scope.howgetMerchant = function(item){
        $scope.closeUseVoucherModal();
        tabClickedFunc(2);
    }

    $scope.btnVoucherSuccess = false;
    $scope.submitVoucher = function(activationcode, data){
        $scope.closeUseVoucherModal();
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.useVoucher(data.id, activationcode, function (response){
            console.log(response)
            if(response){
                if(response.statusCode == 10){
                    $scope.isSuccessUseVoucher = true;
                    $scope.btnVoucherSuccess = true;
                    $scope.dataVoucher = response;
                    if(response.date == null && response.date == undefined && response.date == ""){
                        $scope.dataVoucher.date = "-";
                        $scope.expireddateUseVoucher = "-";
                    } else{
                        $scope.dataVoucher.date = $scope.strToDate(response.date);
                        $scope.expireddateUseVoucher = $scope.strToDate(data.expired_date);
                    }
                    $scope.msgUseVoucher = ($scope.lang=='ina') ? response.message_id : response.message;
                    goUseVoucherSuccess();
                } else {
                    $scope.isSuccessUseVoucher = false;
                    $scope.btnVoucherSuccess = false;
                    $scope.msgUseVoucher = ($scope.lang =='ina') ? response.message_id : response.message;
                    goUseVoucherSuccess();
                }
            }else{
            }
        });
    }

    function goUseVoucherSuccess(){
        $ionicModal.fromTemplateUrl('partials/tabs/profile/successUseVoucher.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.successUseVoucherModal = modalMenu; 
            $scope.successUseVoucherModal.show();
        }); 
    }

    $scope.closesuccessUseVoucherModal = function(){
        $scope.successUseVoucherModal.hide();
    }
    $scope.loadListMyVoucher = function(){ 
        $scope.successUseVoucherModal.hide();
        $scope.myGoBack();
    }
}