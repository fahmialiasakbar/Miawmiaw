angular
    .module('livein')
    .controller('recommended', recommended);

function recommended($scope, $sce, $state, $rootScope, $timeout, $cordovaGeolocation, $stateParams, TenantService, $ionicLoading, $filter, $localStorage, $ionicLoading, $ionicModal, talktoUs, $filter, AdvertiseService, $cordovaSocialSharing, CouponService, $filter, dataWhatsNew, TenantService, AdvertisementService) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
    $scope.categoryname = $filter('translate')('recommended');
    $scope.defaultAvatar = 'img/items/item_beauty.png';
    $scope.subCategories = [];
    $scope.subCatsId = [];
    $scope.tenantDataRecommended=[];
    $scope.fakelist=[1,2,3];
    listRecomendedTenant();
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Recommended Tenant';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    $scope.gotoAdsDetail = function(dataAds){
        $state.go("app.adsDetail", { idAds: dataAds[0].id } );
    }

    function getAdsList(){
        var length = $scope.tenantDataRecommended.length;
        var idtype = 3;
        var pagenumber = 1;
        var pagesize;
        if(length < 4) pagesize = 1;
        else if(length%4 == 0) pagesize = length/4;
        else pagesize = parseInt((length/4).toString().charAt(0));

        $scope.adsList = [];
        AdvertisementService.getAdsbyFilter(idtype, pagenumber, pagesize, "", "", function(response){
            if(response.status != false){
                var a = 0;
                angular.forEach(response, function (obj) { 
                    var b = a++;
                    var data = response[b];
                    $scope.adsList.push({
                        id: data.id,
                        idadstype: data.idadstype,
                        image: data.image,
                        title: data.title,
                        title_id: data.title_id,
                        validfrom: data.validfrom,
                        validuntil: data.validuntil
                    })
                })
            }
        })
    }

    function listRecomendedTenant() {
        $scope.hideSkeleton = false;
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        $scope.tenantDataRecommended = [];
        $scope.adsList = [];
        TenantService.categoryTenant($stateParams.idcategory, function (response) {
            $timeout(function () {
                if (response != false) {
                    $scope.categoryTenantList = response;
                    $scope.idcategory = '';
                    angular.forEach(response, function (obj) {
    
                        if (obj.level == 1) {
                            $scope.idcategory += obj.idcategory + ',';
                        }
                    });
    
                    TenantService.listTenantHome($scope.idcategory.slice(0, -1), function (response) {
                        if (response != false) {
                            $scope.countDataRecommended = 0;
                            if (response.length > 0) {
                                var data = response[0];
                                angular.forEach($scope.categoryTenantList, function (obj) {
                                    var categorytenant = obj;
                                    categorytenant['dataRecommended'] = listRecomendedTenant(data['category' + obj.idcategory]);
                                    categorytenant['countDataRecommended'] = data['category' + obj.idcategory] ? data['category' + obj.idcategory].length : 0;
                                    $scope.countDataRecommended += categorytenant['countDataRecommended'];
                                    categorytenant['categoryName'] = $scope.lang == 'ina' ? categorytenant.categoryname_id != null ? categorytenant.categoryname_id : categorytenant.categoryname : categorytenant.categoryname;
                                    if(categorytenant['countDataRecommended'] > 0){
                                        $scope.tenantDataRecommended.push(categorytenant);                                     
                                    }
                                });
                                getAdsList();
                                $ionicLoading.hide();
                            } else {
                                $scope.data = [{ name: $filter('translate')('no_data') }];
                                $ionicLoading.hide();
                            }
                        }
                    });
                }

                $scope.hideSkeleton = true;
            }, 2000)

        });

        function listRecomendedTenant(dataArr) {
            var tenantdata = [];
            angular.forEach(dataArr, function (data) {
                var idcategory = data.idcategory;
                var categoryname = data.categoryname;
                var level = data.level;
                var idtenant = data.idtenant;
                var avatar = data.avatar;
                var tenantsname = data.tenantsname;
                var address = data.address;
                var longlat = calculatdistance(data.longlat);
                var premium = data.premium;
                var phone = data.phone;
                var link = data.link;
                var logo = data.logo;
                var color = data.color;
                var rate = parseFloat(data.rate).toFixed(1);
                var open = data.open;
                var openhour = data.openhour;
                var closehour = data.closehour;
                var bookmarked = data.bookmarked;
                var image;
                var initial = Array.prototype.map.call(tenantsname.split(" "), function (x) { return x.substring(0, 1).toUpperCase(); }).join('');
                if (avatar == null || avatar == "") {
                    image = ''
                } else {
                    image = avatar;
                }
                var letters = '0123456789ABCDEF';
                var color1 = '#';
                for (var i = 0; i < 6; i++) {
                    color1 += letters[Math.floor(Math.random() * 16)];
                }
                var color2 = '#';
                for (var i = 0; i < 6; i++) {
                    color2 += letters[Math.floor(Math.random() * 16)];
                }
                var color3 = '#';
                for (var i = 0; i < 6; i++) {
                    color3 += letters[Math.floor(Math.random() * 16)];
                }

                var timeTravel = (longlat * 1.67);

                tenantdata.push({
                    'idcategory': idcategory,
                    'categoryname': categoryname,
                    'level': level,
                    'idtenant': idtenant,
                    'avatar': image,
                    'tenantsname': tenantsname,
                    'address': address,
                    'longlat': longlat,
                    'premium': premium,
                    'phone': phone,
                    'link': link,
                    'logo': logo,
                    'color': color,
                    'rate': rate,
                    'open': open,
                    'openhour': formatDate(openhour),
                    'closehour': formatDate(closehour),
                    'bookmarked': bookmarked,
                    'timeTravel': timeTravel,
                    'initial': initial,
                    'color1': color1,
                    'color2': color2,
                    'color3': color3,
                });
            });

            return tenantdata;
        }
    }

    function formatDate(d) {
        var hour = d.split(":");
        var hh = hour[0]
        var m = hour[1]
        var s = hour[2]

        var dd = "AM";
        var h = hh;
        if (h >= 12) {
            h = hh - 12;
            if (h.toString().length == 1) h = "0" + (hh - 12)
            dd = "PM";
        }

        if (h == 0) {
            h = 12;
        }
        m = m < 10 ? m : m;
        s = s < 10 ? "0" + s : s;
        var replacement = h + ":" + m;
        /* if you want to add seconds
        replacement += ":"+s;  */
        replacement += " " + dd;
        return replacement;
    }

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    calculatdistance = function (longlat) {
        datalonglat1 = longlat.replace('(', '');
        datalonglat2 = datalonglat1.replace(')', '');
        lattenant = (datalonglat2.split(',')[0]);
        longtenant = (datalonglat2.split(',')[1]);

        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
        var dLon = deg2rad($scope.long - longtenant);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        return isNaN(d) ? 0 : d;
    };

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

    $rootScope.StartEvent = false;

    if (!$localStorage.firstOpen) {
        startIntroduction();
        $localStorage.firstOpen = { status: true };
    }

    //mulai sini
    $ionicModal.fromTemplateUrl('partials/sides/coba.html', {
        scope: $scope
    }).then(function (modalMenu) {
        $scope.modalMenu = modalMenu;
    });

    $scope.openMenu = function () {
        $scope.modalMenu.show();
    }

    $scope.closeModalSlider = function () {
        $scope.modalMenu.hide();
    };

    //sampe sini

    function startIntroduction() {

        var screen = angular.element(document.querySelector('ion-side-menu'));
        screen.css('visibility', 'hidden');

        $rootScope.IntroOptions = {
            steps: [
                {
                    element: document.querySelector('.tabs .tab-item.profilecon'),
                    intro: '<div class="introjs-first">' + $filter('translate')('intro1') + '</div>',
                    position: 'top'
                },
                {
                    element: document.querySelector('#step1'),
                    intro: '<div class="introjs-second">' + $filter('translate')('intro2') + '</div>',
                    position: 'top'
                },
                {
                    //.bar .button.button-custom.navcon
                    element: document.querySelector('.bar'),
                    intro: '<div class="introjs-third">' + $filter('translate')('intro3') + '</div>',
                    position: 'bottom'
                }
            ],
            showStepNumbers: false,
            showBullets: false,
            exitOnOverlayClick: false,
            exitOnEsc: false,
            showProgress: false,
            // nextLabel: $filter('translate')('next'),
            // prevLabel: $filter('translate')('previous'),
            // skipLabel: $filter('translate')('skip'),
            // doneLabel: $filter('translate')('thanks')
            nextLabel: 'Next',
            prevLabel: 'Previous',
            skipLabel: 'Skip',
            doneLabel: 'Thanks'

        };

        var introprofile = angular.element(document.querySelector('.tabs .tab-item.profilecon'));
        introprofile.css('opacity', '1.0');
        introprofile.css('background-color', '#0D6DB6');

        var intronav = angular.element(document.querySelector('.bar .button.button-custom'));
        intronav.css('background-color', '#0D6DB6');

        $rootScope.CompletedEvent = function () {
            screen.css('visibility', 'visible');
            // console.log('[directive] completed Event')
        }
        $rootScope.StartEvent = true;
        $rootScope.ExitEvent = function () {
            screen.css('visibility', 'visible');
            // console.log('[directive] exit Event')
        }
        $rootScope.ChangeEvent = function (id) {
            // console.log('[directive] change Event')
            // console.log($rootScope.IntroOptions.steps);
        }
        $rootScope.BeforeChangeEvent = function (id) {
            // console.log('[directive] beforeChange Event')
            // console.log($rootScope.IntroOptions.steps);
        }
        $rootScope.AfterChangeEvent = function (id) {
            // console.log('[directive] after change Event')
            // console.log($rootScope.IntroOptions.steps);
        }
    }

    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
    };

    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };
}
