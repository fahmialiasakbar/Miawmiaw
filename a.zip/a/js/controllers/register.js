angular
  .module('livein')
  .controller('register', register)

function register($window, $translate, $scope, $ionicLoading, $ionicPopup, $location, $state, registerService, $filter, $localStorage, $ionicModal, $ionicHistory) {
  $scope.registerManual = registerManualService;
  $scope.registerGooglePlus = registerGooglePlus;
  $scope.facebook_auth = facebook_auth;
  $scope.google_auth = google_auth;
  $scope.twitter_auth = twitter_auth;
  $scope.resendEmail = resendEmail;
  $scope.user = {};

  $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
  if ($scope.lang == 'ina') {
    $scope.persons = [{ "id": 1, "name": "Jenis Kelamin", "value": "M" }, { "id": 2, "name": "Laki-laki", "value": "M" }, { "id": 3, "name": "Perempuan", "value": "F" }];
    $scope.gender = $scope.persons[0].id;
  } else {
    $scope.persons = [{ "id": 1, "name": "Gender", "value": "M" }, { "id": 2, "name": "Male", "value": "M" }, { "id": 3, "name": "Female", "value": "F" }];
    $scope.gender = $scope.persons[0].id;
  }
  $scope.selectLang = "";
  // user.gender = $scope.gender

  // ----- Analytic Screen
  if (window.ga) {
    var analyticView = 'Register screen';
    window.ga.trackView(analyticView);
    window.ga.trackEvent('Screen View', analyticView);
    console.log("Analytic - Screen View - " + analyticView);
  }

  $scope.setgender = function (gender) {
    $scope.gender = gender;
  }

  $ionicModal.fromTemplateUrl('partials/sides/resendEmailModal.html', {
    scope: $scope
  }).then(function (modalResend) {
    $scope.modalResend = modalResend;
  });

  $scope.myGoBack = function () {
    $ionicHistory.goBack();
};

  // Get the modal & button
  var modal = document.getElementById('myModal');
  // var btn = document.getElementById("myBtn");

  //Show Hide Password
  $scope.passwordshow = 'password';
  $scope.showPassword = function () {
    $scope.passwordshow = 'text';
  }
  $scope.hidePassword = function () {
    $scope.passwordshow = 'password';
  }

  $scope.hintpassword = 'password';
  $scope.showHint = function () {
    $scope.hintpassword = 'text';
  }
  $scope.hideHint = function () {
    $scope.hintpassword = 'password';
  }
  //end of show hide
  $scope.openModalResend = function () {
    $scope.modalResend.show();
    // modal.style.display = "block";
    // console.log('stylenya: '+modal.style);               
  }

  $scope.closeModalResend = function () {
    $scope.modalResend.hide();
  }

  function resendEmail(email) {
    if (email) {
      $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

      registerService.resendEmailActivation(email, function (response) {
        if (response[0].status == false) {
          if (response[0].message == 'account is active') {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.alert({
              title: "Failed",
              template: $filter('translate')('account_isactive'),
              okText: $filter('translate')('yes'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            document.getElementById("inputEmail").value = "";
            alertPopup.then(function (res) {
              // $window.location.reload();
              $scope.closeModalResend();
              $state.go('login');
            });
          } else if (response[0].message == 'your email is 3x sending email') {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.alert({
              title: "Failed",
              template: $filter('translate')('account_limit'),
              okText: $filter('translate')('yes'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            alertPopup.then(function (res) {
              // $window.location.reload();
              document.getElementById("inputEmail").value = "";
              $scope.closeModalResend();
              $state.go('login');
            });
          } else {
            $ionicLoading.hide();
            // var iEl = angular.element(document.querySelector('#form'));
            // iEl.empty();
            var alertPopup = $ionicPopup.alert({
              title: "Failed",
              template: $filter('translate')('no_account'),
              okText: $filter('translate')('yes'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            document.getElementById("inputEmail").value = "";
            alertPopup.then(function (res) {
              $scope.closeModalResend();
              $state.go('login');
              // $scope.appendContent();
            });
          }
        } else {
          $ionicLoading.hide();
          var alertPopup = $ionicPopup.alert({
            title: "Success",
            template: $filter('translate')('account_issend'),
            okText: $filter('translate')('yes'),
            okType: "button-stable",
            cssClass: "alertPopup"
          });
          document.getElementById("inputEmail").value = "";
          alertPopup.then(function (res) {
            // $window.location.reload();
            $scope.closeModalResend();
            $state.go('login');
          });
        }
      });
    } else {
      var alertPopup = $ionicPopup.alert({
        template: $filter('translate')('email_empty'),
        okText: $filter('translate')('yes'),
        okType: "button-stable",
        cssClass: "alertPopup"
      });
      document.getElementById("inputEmail").value = "";
      alertPopup.then(function (res) {
        $scope.closeModalResend();
        $state.go('login');
      });
    }
  }

  function registerManualService(user) {
    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    if ($scope.gender == 1) {
      $scope.gender = 2;
    }

    if (!user.fullname) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_fullname'),
        duration: 3000
      });
      $ionicLoading.show({
        template: $filter('translate')('cbe_fullname'),
        duration: 3000
      });
    } else if (!user.phone) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_phone'),
        duration: 3000
      });
    } else if (!user.email) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_email'),
        duration: 3000
      });
    } else if (!user.password) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_pass'),
        duration: 3000
      });
    } else if (user.password.length < 8) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_pass_min'),
        duration: 3000
      });
    } else if (user.confpassword != user.password) {
      $ionicLoading.show({
        template: $filter('translate')('not_equal'),
        duration: 3000
      });
    } else if (!user.checkbox1) {
      $ionicLoading.show({
        template: $filter('translate')('cbe_check1'),
        duration: 3000
      });
    } else if (user.email && user.fullname && $scope.gender && user.phone && user.password  && user.confpassword  && user.password == user.confpassword && user.checkbox1 ) {
      $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
      registerService.registerManualService(
        user.fullname,
        $scope.persons[$scope.gender - 1].value,
        user.phone,
        user.email,
        user.password,
        function (response) {
          if (response != false) {
            if (response[0].status == false) {
              $scope.messages = response[0].message;
              if ($scope.lang == 'ina') {
                $scope.messages = response[0].message_id != null ? response[0].message_id : response[0].message;
              }
              var alertPopup = $ionicPopup.alert({
                title: "ERROR",
                template: $scope.messages,
                okText: $filter('translate')('yes'),
                okType: "button-stable",
                cssClass: "alertPopup"
              });
            } else {
              if ($scope.selectLang) {
                $translate.use($scope.selectLang)
              }
              $state.go('login');
              $ionicPopup.alert({
                title: $filter('translate')('registration_success'),
                template: $filter('translate')('activate_account'),
                okText: $filter('translate')('yes'),
                okType: "button-stable",
                cssClass: "alertPopup"
              });
            }
          } else {
            console.log("masuk else");
            var alertPopup = $ionicPopup.alert({
              title: $filter('translate')('registration_failed'),
              template: $filter('translate')("email2"),
              okText: $filter('translate')('yes'),
              okType: "button-stable",
              cssClass: "alertPopup"
            })
          }
          $ionicLoading.hide();

          // ----- Analytic Screen
          if (window.ga) {
            var analyticView = 'Manual';
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Register screen', analyticView);
            console.log("Analytic - Register screen - " + analyticView);
          }

        });
    } else {
      console.log('error');
      $ionicPopup.alert({
        title: $filter('translate')('registration_failed'),
        okText: $filter('translate')('yes'),
        okType: "button-stable",
        cssClass: "alertPopup"
      })
    }
  };

  function registerGooglePlus() {

    ionic.Platform.ready(function () {

      if (window.plugins.googleplus && window.plugins) {
        window.plugins.googleplus.isAvailable(
          function (available) {

            window.plugins.googleplus.login({
              'scopes': 'profile email', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
              'webClientId': 'com.googleusercontent.apps.683716271520-acb1b36o862aotvbdh0d6gooolkn0ar8', // optional clientId of your Web application from Credentials settings of your project - On Android, this MUST be included to get an idToken. On iOS, it is not required.
              'offline': false, // optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
            },
              function (obj) {
                console.log("googleplusplugin")
                console.log(JSON.stringify(obj));
                senddatauser(obj, "google")// do something useful instead of alerting
              },
              function (msg) {
                console.log('error: ' + msg);
              });
            // ----- Analytic Screen
            if (window.ga) {
              var analyticView = 'Google Plus';
              window.ga.trackView(analyticView);
              window.ga.trackEvent('Register screen', analyticView);
              console.log("Analytic - Register screen - " + analyticView);
            }
          });
      }
      // will execute when device is ready, or immediately if the device is already ready.
    });

  }

  //with twitter
  function twitter_auth() {
    ionic.Platform.ready(function () {
      $ionicPopup.alert({
        template: $filter('translate')('soon'),
        okText: $filter('translate')('okay'),
        cssClass: "alertPopup"
      });
      // twitterlogout();

      // ----- Analytic Screen
      if (window.ga) {
        var analyticView = 'Twitter';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Register screen', analyticView);
        console.log("Analytic - Register screen - " + analyticView);
      }

      // TwitterConnect.login(
      //   function (result) {
      //     console.log('Successful login! ' + result);
      //     getshowuseremail()
      //   }, function (error) {
      //     var alertPopup = $ionicPopup.alert({
      //       title: $filter('translate')('registration_cancel'),
      //       okText: $filter('translate')('okay'),
      //       okType: "button-stable",
      //       cssClass: "alertPopup"
      //     });
      //   }
      // );
    }, function error(error) {
      // alert(JSON.stringify(error)) 
    });
  }

  function getshowuseremail() {
    TwitterConnect.showUserEmail(function (result) {
      if (result.email !== undefined) {
        savetolocal(result.id_str, result.email);
      } else {
        var data = getLocalTwitter(result.id_str);
        var object = JSON.parse(JSON.stringify(data));
        result['email'] = object.email;
      }
      senddatauser(result, "twitter");
    }, function (error) {
      console.log('Errornya: ' + error)
    })
  }

  function getLocalTwitter(id) {
    return angular.fromJson(sessionStorage[id]);
  }

  function savetolocal(id, email) {
    sessionStorage[id] = angular.toJson({
      email: email,
    });
  }

  //facebook
  function facebook_auth() {
    ionic.Platform.ready(function () {
      facebookConnectPlugin.logout(function succes(result) {
        getloginfacebook();
      }, function oneror(error) {
        getloginfacebook();
      })
      // ----- Analytic Screen
      if (window.ga) {
        var analyticView = 'Facebook';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Register screen', analyticView);
        console.log("Analytic - Register screen - " + analyticView);
      }
    });
  }

  function getloginfacebook() {
    facebookConnectPlugin.login(["public_profile", "email", "user_birthday"], function onSucces(result) {

      facebookConnectPlugin.api("me" + "/?fields=id,email,gender,birthday,name", null,
        function onSuccess(datauser) {
          console.log("Result: ", datauser);
          senddatauser(datauser, "facebook");
          facebooklogout();
        }, function onError(erroruser) {
          console.error("Failed: ", erroruser);
        }
      );
    }, function onError(error) {
      var alertPopup = $ionicPopup.alert({
        title: $filter('translate')('registration_cancel'),
        okText: $filter('translate')('okay'),
        okType: "button-stable",
        cssClass: "alertPopup"
      });
    });
  }

  //google auth
  function google_auth() {
    ionic.Platform.ready(function () {

      if (window.plugins.googleplus && window.plugins) {
        window.plugins.googleplus.isAvailable(
          function (available) {
            var params = {
              'scopes': 'profile email', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
              'webClientId': 'com.googleusercontent.apps.683716271520-acb1b36o862aotvbdh0d6gooolkn0ar8', // optional clientId of your Web application from Credentials settings of your project - On Android, this MUST be included to get an idToken. On iOS, it is not required.
              'offline': false, // optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
          };
          if (ionic.Platform.isAndroid()) {
              params = {
                  'scopes': 'profile email', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
                  'offline': false, // optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
              };
          } 
            window.plugins.googleplus.login(params,
              function (obj) {
                console.log(JSON.stringify(obj));
                senddatauser(obj, "google")// do something useful instead of alerting
              },
              function (msg) {
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_cancel'),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                console.log('error: ' + msg);
              });

          });
      }
      // will execute when device is ready, or immediately if the device is already ready.
    });
  }

  //action of login and register
  function senddatauser(data_user, sosmed) {
    $ionicLoading.show({ template: $filter('translate')('loginmessage') + "...", duration: 2000 });

    if (sosmed == "facebook") {
      var gender = 'n'
      if(data_user){ 
          if(data_user.gender){
              if (data_user.gender.toLowerCase() == "male") {
                  gender = "m"
              } else if (data_user.gender.toLowerCase() == "female") {
                  gender = "f"
              }
          }
      }

      // alert("send data from facebook")

      registerService.registerManualService(
        data_user.name,
        gender,
        '',
        data_user.email,
        Math.floor(100000000 + Math.random() * 90000000),
        function (response) {
          if (response != false) {
            if (response[0].status == false) {
              if (response[0].isactive == 't') {
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_failed'),
                  template: $filter('translate')("email2"),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                googlesignout()
              } else {
                console.log('haloo belum aktif')
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_success'),
                  template: $filter('translate')('check_email_login'),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                facebooklogout()
              }

              console.log("false")

            } else if (response[0].status == true) {

              // alert(JSON.stringify(response));
              var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('registration_success'),
                template: $filter('translate')('check_email_login'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
              });
              console.log("true")
              facebooklogout()

            }

            console.log("true tapi false api yo gak true")

          } else {
            var alertPopup = $ionicPopup.alert({
              title: $filter('translate')('registration_failed'),
              template: $filter('translate')("email2"),
              okText: $filter('translate')('okay'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            facebooklogout()

            //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
            $state.go('/login');
          }
          $ionicLoading.hide();
        });
    } else if (sosmed == "google") {

      registerService.registerManualService(
        data_user.displayName,
        "n",
        '',
        data_user.email,
        Math.floor(100000000 + Math.random() * 90000000),
        function (response) {
          // alert(JSON.stringify(response))
          if (response != false) {
            if (response[0].status == false) {
              if (response[0].isactive == 't') {
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_failed'),
                  template: $filter('translate')("email2"),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                googlesignout();
              } else {
                console.log('haloo belum aktif')
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_success'),
                  template: $filter('translate')('check_email_login'),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                googlesignout()
              }
              console.log("false")

            } else if (response[0].status == true) {
              var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('registration_success'),
                template: $filter('translate')('check_email_login'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
              });
              console.log("true")
              googlesignout()
            }
          } else {
            var alertPopup = $ionicPopup.alert({
              title: $filter('translate')('registration_failed'),
              template: $filter('translate')("email2"),
              okText: $filter('translate')('okay'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            googlesignout()

            //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
            $state.go('/login');
          }
          $ionicLoading.hide();
        });
    } else if (sosmed == "twitter") {
      console.log('data resultnyaa: ' + JSON.stringify(data_user));
      console.log("yuhu: " + data_user.name + "," + data_user.email);

      registerService.registerManualService(
        data_user.name,
        "n",
        '',
        data_user.email,
        Math.floor(100000000 + Math.random() * 90000000),
        function (response) {
          if (response != false) {
            if (response[0].status == false) {
              if (response[0].isactive == 't') {
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_failed'),
                  template: $filter('translate')("email2"),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                twitterlogout();
              } else {
                console.log('haloo belum aktif')
                var alertPopup = $ionicPopup.alert({
                  title: $filter('translate')('registration_success'),
                  template: $filter('translate')('check_email_login'),
                  okText: $filter('translate')('okay'),
                  okType: "button-stable",
                  cssClass: "alertPopup"
                });
                twitterlogout();
              }
            } else if (response[0].status == true) {
              var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('registration_success'),
                template: $filter('translate')('check_email_login'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
              });
              console.log("sukses register woi")
              twitterlogout();
            }
          } else {
            var alertPopup = $ionicPopup.alert({
              title: $filter('translate')('registration_failed'),
              template: $filter('translate')("email2"),
              okText: $filter('translate')('okay'),
              okType: "button-stable",
              cssClass: "alertPopup"
            });
            twitterlogout();

            //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
            $state.go('/login');
          }
          $ionicLoading.hide();
        });
    }
  }

  function googlesignout() {
    window.plugins.googleplus.logout(
      function (msg) {
        window.plugins.googleplus.disconnect(
          function (msg) {

          }
        );
      }
    );
  }

  function facebooklogout() {
    facebookConnectPlugin.logout(function onSucces() {
    }, function onError() { })
  }

  function twitterlogout() {
    TwitterConnect.logout(
      function () {
        console.log('Successful logout!');
      },
      function () {
        console.log('Error logging out');
      }
    );
  }



}
