angular
    .module('livein')
    .controller('useful', useful);

function useful($scope, $ionicLoading, $state, useful, $filter) {
    listNumber();
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Information Call';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    $scope.data;
    $scope.fake=[1,2,3,4];
    function listNumber() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        useful.phoneNumber(
            function (response) {
                if (response != false) {
                    $scope.data = response;
                    console.log($scope.data);
                } else {
                    $scope.data = { name: $filter('translate')('failed_get_data') };
                }
                $ionicLoading.hide();
            });
    };
}