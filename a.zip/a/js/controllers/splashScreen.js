angular
  .module('livein')
  .controller('splashScreen', splashScreen);

function splashScreen($scope, $timeout, $rootScope, $state, $filter, $localStorage, $location, AdvertiseService, Version, $stateParams) {

  // Called to navigate to the main app

  $rootScope.loadAdvertise = false;
  $scope.startApp = function () {

    console.log('Start app!');
    $state.go('app.main');

      if ($location.path("/app/main")) {
        if ($localStorage.firstOpen) {
          if(!$rootScope.loadAdvertise){
            console.log('Start $rootScope.loadAdvertise!');
            AdvertiseService.AdsOpen();
            $rootScope.loadAdvertise = true;
          }
        }
      }

    return $timeout(() => angular.noop, 3000);

  };

  // watching localStorage value change
  // $scope.$watch(function () {
  //   return angular.toJson($localStorage);
  // }, function () {
  //   $sc
    // $scope.currentUser = $localStorage.currentUser;
    // if ($scope.currentUser != null) {
    //   $scope.fullname = $scope.currentUser.data[0].fullname;
    //   $scope.currentUser.data[0].privilege == 'resident' ? $scope.showPrivillage = true : $scope.showPrivillage = false;
    //   $scope.salah = true;
    // } else {
    //   $scope.fullname = "";
    //   $scope.salah = false;
    // }
  // });
  $scope.swiper = {
    options: {
        pagination: '.custom-swiper-pagination',
        paginationClickable: true,
        loop: false,
        effect: 'coverflow',
        direction: 'horizontal',
        spaceBetween: 20,
        speed: 600
    },
    data: {}
  };
  // Called each time the slide changes
  $scope.$on("$ionicSlides.slideChangeStart", function(event, data){
    console.log('Slide change is beginning');
  });
  
  $scope.$on("$ionicSlides.slideChangeEnd", function(event, data){
    // note: the indexes are 0-based
    $scope.activeIndex = data.slider.activeIndex;
    $scope.previousIndex = data.slider.previousIndex;
    if ($scope.activeIndex <= 0) {
      $('#paginatorxx').hide();
    } else {
      $('#paginatorxx').show();
    }
  });

  function GetVersion() {

    Version.GetVersion(function (response) {
      $scope.getVer = response;
    });
  }

  $scope.getPageIdx = function() {
    return parseInt($scope.activeIndex);
  };

  GetVersion();
  $scope.activeIndex = 0;
}
