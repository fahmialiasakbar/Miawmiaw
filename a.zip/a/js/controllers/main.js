angular
    .module('livein')
    .controller('app', app)
    .controller('main', main)
    .controller('currencymain', currencymain)

    .controller('weather', weather);

function app($scope, $ionicPopover, $ionicModal, billingServices, PointService, $filter, $cordovaGeolocation, $ionicPlatform, mainService, PushNotificationService, $location, $rootScope, $state, LoginService, $localStorage, $ionicPopup, $ionicLoading, $cordovaAppAvailability) {

    $scope.afliates_sos = isSOS;

    $scope.profil = function () {
        if ($localStorage.currentUser != null) {
            $state.go('app.profile');
        } else {
            $state.go('login');
        }
    } 
    
    // if(window.hasOwnProperty('cordova')){
    //     cordova.plugins.backgroundMode.setEnabled(true);
    // }

    //drawer - side menu
    $scope.showPrivillage, $scope.subEntertaiment, $scope.subDining, $scope.subAccomodation, $scope.subShopping, $scope.subTransportation, $scope.subPublicServ, $scope.subHelp, $scope.subResident, $scope.subInformation = false;

    $scope.sorry = function () {
        var alertPopup = $ionicPopup.alert({
            template: $filter('translate')('blm_login'),
            okText: $filter('translate')('okay'),
            okType: "button-stable",
            cssClass: "alertPopup"
        });
    }

    function getMyPoints(){
        if($localStorage.currentUser){
            PointService.getMyPoint(function(response){
                if(!$localStorage.currentPoint){
                    $localStorage.currentPoint = 0;
                }
                if(response){
                    if(response.statusCode == 10){
                        $localStorage.currentPoint = response.mypoint;
                    }
                }
            });
        }       
    }
    getMyPoints();
    // watching localStorage value change
    $scope.$watch(function () {
        return angular.toJson($localStorage);
    }, function () {
        
        $scope.currentUser = $localStorage.currentUser;
        if ($scope.currentUser != null) {
            $scope.fullname = $scope.currentUser.data[0].fullname;
            if($scope.currentUser.data[0].privilege == 'resident') {
                $scope.showPrivillage = true;
                $scope.isResident = true;
                $scope.myPoints = $localStorage.currentPoint;
            } else{
                $scope.showPrivillage = false;
                $scope.isResident = false;
            }
            $scope.salah = true;
        } else {
            $scope.fullname = "";
            $scope.salah = false;
        }
    });

    $scope.showEntertaiment = function () {
        $scope.subEntertaiment == true ? $scope.subEntertaiment = false : $scope.subEntertaiment = true;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showDining = function () {
        $scope.subDining == true ? $scope.subDining = false : $scope.subDining = true;
        $scope.subEntertaiment = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showAccomodation = function () {
        $scope.subAccomodation == true ? $scope.subAccomodation = false : $scope.subAccomodation = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showShopping = function () {
        $scope.subShopping == true ? $scope.subShopping = false : $scope.subShopping = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showTransportation = function () {
        $scope.subTransportation == true ? $scope.subTransportation = false : $scope.subTransportation = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showPublicServ = function () {
        $scope.subPublicServ == true ? $scope.subPublicServ = false : $scope.subPublicServ = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subHelp = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showHelp = function () {
        $scope.subHelp == true ? $scope.subHelp = false : $scope.subHelp = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subResident = false;
        $scope.subInformation = false;
    };
    $scope.showInformation = function () {
        $scope.subInformation == true ? $scope.subInformation = false : $scope.subInformation = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subResident = false;
    };
    $scope.showResident = function () {
        $scope.subResident == true ? $scope.subResident = false : $scope.subResident = true;
        $scope.subEntertaiment = false;
        $scope.subDining = false;
        $scope.subAccomodation = false;
        $scope.subShopping = false;
        $scope.subTransportation = false;
        $scope.subPublicServ = false;
        $scope.subHelp = false;
        $scope.subInformation = false;
    };


    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    //   if ($scope.lang == 'ina') {
    //     ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran.html";
    //   } else {
    //     ketentuanLink = $filter('translate')('apilinkliveinweb') + "assets/file/city/syarat_ketentuan_pembayaran.html";
    //   }

    //   $scope.ketentuanLink = $sce.trustAsResourceUrl(ketentuanLink);


    $scope.openebilling = function () {
        console.log("haloobilling")
        $state.go('app.loginebilling');
        // $scope.modalTerms.show();

    }
    $scope.showTrain = function () {
        $ionicLoading.show({
            template: $filter('translate')('train'),
            duration: 2000
        });
    }

    //search
    $scope.navbar = true;
    $scope.searchbar = false; 

    $scope.searchbarAct = function () {
        $scope.navbar = false;
        $scope.searchbar = true;
    };

    // $rootScope.loadPopOverSort = function () {
    //     // Start:: Pop Over Filter
    //     $scope.sortBtn = false;
    //     $scope.navbar = false;
    //     $ionicPopover.fromTemplateUrl('popoverSort.html', {
    //         scope: $scope
    //     }).then(function (popover) {
    //         if (popover) $scope.sortBtn = true;
    //         $scope.popoverSort = popover;
    //     });
    // } 
    $rootScope.loadPopOverSort = function () {
        // Start:: Pop Over Sort
        $ionicPopover.fromTemplateUrl('popoverSort.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popoverSort = popover;
        });
    }
    $rootScope.loadPopOverFilter = function () {
        // Start:: Pop Over Filter
        $ionicPopover.fromTemplateUrl('popoverFilter.html', {
            scope: $scope
        }).then(function (popover) {
            $scope.popoverFilter = popover;
        });
    }

    $scope.sortbarAct = function ($event) {
        $scope.popoverSort.show($event);
    };
    $scope.closePopoverSort = function () {
        $scope.popoverSort.hide();
    };

    $scope.filterbarAct = function ($event) {
        $scope.popoverFilter.show($event);
    };

    $scope.closePopoverFilter = function () {
        $scope.popoverFilter.hide();
    };

    $rootScope.sortType = '';
    $rootScope.sortList = function (orderby) {
        $rootScope.sortType = orderby;
        $scope.closePopoverSort();
    };
    $rootScope.byCategory = '';
    $rootScope.filterList = function (filterby) {
        $rootScope.byCategory = filterby;
        $scope.closePopoverFilter();
    };

    $scope.goPoint = function(){
        $state.go('app.point');
    }

    //Cleanup the popover when we're done with it!
    // $scope.$on('$destroy', function () {
    //     $scope.popoverSort.remove();
    // });

    // Execute action on hide popover
    $scope.$on('popover.hidden', function () {
        // Execute action
    });

    // Execute action on remove popover
    $scope.$on('popover.removed', function () {
        // Execute action
    });
    // End:: Pop Over Filter
 
    $scope.navbarAct = function () {
        $scope.navbar = true;
        $scope.searchbar = false;
        $rootScope.search_page = "";

        if ($state.current.name == 'app.category') {
            if($rootScope.checkSearch) {
                $rootScope.checkSearch();    
            }
        }

        if ($state.current.name == 'app.whatsNew') {
            if($rootScope.searchWhatsNew){
                $rootScope.searchWhatsNew();
            }
        }
    };

    $scope.$on("$ionicView.beforeEnter", function () {
        if ($state.current.name == 'app.forum') {
            $ionicPopup.alert({
                template: $filter('translate')('soon'),
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup",
                okType: "button-stable"
            });
            $state.go('app.main');
            return false;
        }
    });

 
    $scope.$on("$ionicView.beforeEnter", function () {

        $scope.sortBtn = false;
        if ($state.current.name == 'app.propertylist' ||
            $state.current.name == 'app.category' ||
            $state.current.name == 'app.propertysearch' ||
            $state.current.name == 'app.eComplaint' ||
            $state.current.name == 'app.coupon' ||
            $state.current.name == 'app.download'
            // ||
            // $state.current.name == 'app.forum'
        ) {
            $scope.sortBtn = true;
            $rootScope.loadPopOverSort();
        }
        $scope.filterBtn = false;
        if ($state.current.name == 'app.propertylist' ||
            $state.current.name == 'app.propertysearch' ||
            $state.current.name == 'app.download'
        ) {
            $scope.filterBtn = true;
            $rootScope.loadPopOverFilter();
        }
 
        $rootScope.footerPoint = false;
        $rootScope.dataSort = [];
        if ($state.current.name == 'app.point' || $state.current.name == 'app.listVoucher'){
            $rootScope.footerPoint = true;
            $rootScope.footerMyPoint = false;
        } 
    });

    // start:: FUNCTION SORTING POINT
    $rootScope.showSort = function(action){
        
        if(action == 'exploreVoucher'){
            $rootScope.footerMyPoint = false;
        }else{
            $rootScope.footerMyPoint = true;
        }
        $scope.isFilter = false;
        $scope.isSort = true;
        $scope.title="sort";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
        
        if($rootScope.dataSorting){
            if($rootScope.dataSorting == "low"){
                $rootScope.dataSort.value = 1
            } else if($rootScope.dataSorting == "high"){
                $rootScope.dataSort.value = 2
            } else if($rootScope.dataSorting == "availability"){
                $rootScope.dataSort.value = 3
            }
        } else{
            $rootScope.dataSort.value = ""
        }
    }

    $rootScope.functSort = function (){
        
        if($rootScope.dataFilter == undefined){
            $rootScope.dataFilter = []
            if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
            if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
            if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
            if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
            if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
            if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        }else{
            if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
            if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
            if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
            if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
            if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
            if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        }
        
        var value = $rootScope.dataSort.value;
        $rootScope.dataSorting;
        if(value == 1){
            $rootScope.dataSorting = "low"
        } else if(value == 2){
            $rootScope.dataSorting = "high"
        } else if(value == 3){
            $rootScope.dataSorting = "availability"
        }
        if ($state.current.name == 'app.point'){
            if($rootScope.footerMyPoint) {
                
                pagenumber = 1;
                $rootScope.tabClickedMyVoucherFunc($rootScope.dataFilter.distance,
                    $scope.lat, $scope.long,
                    $rootScope.searchMyVoucherVal, $rootScope.dataSorting, pagenumber, $rootScope.dataFilter.point,
                    $rootScope.dataFilter.dateFrom, $rootScope.dataFilter.dateTo, $rootScope.dataFilter.status);    
            }
            else $state.go('app.listVoucher', {id_category:99});
        } 
        
        if ($state.current.name == 'app.listVoucher'){
            // $rootScope.idSearchPoint = 99;
            $rootScope.getDataListVoucher();
        } 

        if($state.current.name == 'app.newsearchPoint'){
            $rootScope.searchPoint($rootScope.search_point);
        }
        $scope.closemodalFilterSort();
    }

    $scope.closemodalFilterSort = function(){
        if($scope.pointFilterSortModal) $scope.pointFilterSortModal.remove();
        $scope.isFilter = false;
        $scope.isSort = false;
        $scope.filter1 = false;
        $scope.filter2 = false;
        $scope.filter3 = false;
        $scope.filter4 = false;
    }
    
    $rootScope.resetSort = function(){
        if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
        if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
        if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
        if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
        if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
        if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        
        $rootScope.dataSorting = "";
        $rootScope.dataSort = [];
        $scope.closemodalFilterSort();
        if ($state.current.name == 'app.listVoucher'){
            $rootScope.getDataListVoucher();
        } else if($state.current.name == 'app.newsearchPoint'){
            $rootScope.searchPoint($rootScope.search_point);
        }else if($rootScope.footerMyPoint){
            pagenumber = 1;
            $rootScope.tabClickedMyVoucherFunc( $rootScope.dataFilter.distance,
                $scope.lat, $scope.long,
                $rootScope.searchMyVoucherVal,"", pagenumber, $rootScope.dataFilter.point,
                $rootScope.dataFilter.dateFrom, $rootScope.dataFilter.dateTo, $rootScope.dataFilter.status);
        }
    };
    // end:: FUNCTION SORTING POINT 
        
    // start:: FUNCTION FILTER POINT
    function loadDateNow() {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!

        var yyyy = today.getFullYear();
        if(dd<10) dd='0'+dd;
        if(mm<10) mm='0'+mm;
        today = yyyy+'-'+mm+'-'+dd;
        $scope.today = today;
    }
    
    $rootScope.showFilter =  function (action){
        
        if(action == 'exploreVoucher'){
            $rootScope.footerMyPoint = false;
        }else{
            $rootScope.footerMyPoint = true;
        }

        loadDateNow()
        $scope.userPoint = $localStorage.currentPoint
        $scope.isFilter = true;
        $scope.isSort = false;
        $scope.title="filter";
        if($rootScope.dataFilter == undefined || $rootScope.dataFilter == []){
            $rootScope.dataFilter = [];
        }
        
        console.log($rootScope.dataFilter)
        $scope.tempdataPoint = ""
        $scope.tempdataVoucher = ""
        $scope.tempdataVoucher2 = ""
        $scope.tempdataQuick1 = ""
        $scope.tempdataDateTo = "";
        $scope.tempdataDateFrom = "";
        $scope.btnFilterDate = false;
        $scope.FilterEmpty = false;
        $scope.changedistance = false;
        $scope.showDistanceLow = "";
        $scope.showDistanceHigh = "";
        
        if($rootScope.tempDataFilter == undefined) {
            $rootScope.tempDataFilter = [];
        }else{
            if($rootScope.dataFilter){
                $rootScope.tempDataFilter = [];
                
                angular.forEach($rootScope.dataFilter.point, function(obj){
                    $scope.tempdataPoint = $rootScope.dataFilter.point
                    if(obj == "0-1000") $rootScope.tempDataFilter.point1 = true;
                    if(obj == "1001-5000") $rootScope.tempDataFilter.point2 = true;
                    if(obj == "5001-10000") $rootScope.tempDataFilter.point3 = true;
                    if(obj == "10000-15000") $rootScope.tempDataFilter.point4 = true;
                    if(obj == "15000") $rootScope.tempDataFilter.point5 = true;
                    $scope.FilterEmpty = true;
                })
                
                angular.forEach($rootScope.dataFilter.status1, function(obj){
                    $scope.tempdataVoucher = $rootScope.dataFilter.status1;
                    if(obj == "available") $rootScope.tempDataFilter.voucherStatus1 = true;
                    if(obj == "expiring") $rootScope.tempDataFilter.voucherStatus2 = true;
                    if(obj == "expired") $rootScope.tempDataFilter.voucherStatus3 = true;
                    $scope.FilterEmpty = true;
                })
                
                if($rootScope.dataFilter.mypoint != undefined && $rootScope.dataFilter.mypoint != "") {
                    $rootScope.tempDataFilter.quickFilter1 = true;
                    $scope.FilterEmpty = true;
                }
                if($rootScope.dataFilter.status2 != undefined && $rootScope.dataFilter.status2 != "") {
                    $rootScope.tempDataFilter.quickFilter2 = true;
                    $scope.FilterEmpty = true;
                }

                if($rootScope.dataFilter.distance != undefined && $rootScope.dataFilter.distance != ""){
                    var distance = $rootScope.dataFilter.distance.split("-");
                    $scope.showDistanceLow = distance[0];
                    $scope.showDistanceHigh = distance[1];
                    $rootScope.tempDataFilter.distancelow = distance[0];
                    $rootScope.tempDataFilter.distancehigh = distance[1];
                    $scope.FilterEmpty = true;
                    $scope.changedistance = true;
                }

                if($rootScope.dataFilter.dateFrom != undefined && $rootScope.dataFilter.dateFrom != ""){
                    var dateFrom = new Date($rootScope.dataFilter.dateFrom);
                    var dd1 = dateFrom.getDate();
                    var mm1 = dateFrom.getMonth()+1; //January is 0!
                    var yyyy1 = dateFrom.getFullYear();
                    if(dd1<10){dd1='0'+dd1;} 
                    if(mm1<10){mm1='0'+mm1;} 
                    $scope.tempdataDateFrom = dd1+'/'+mm1+'/'+yyyy1;
                    $rootScope.tempDataFilter.dateFrom = new Date($rootScope.dataFilter.dateFrom);
                    $scope.FilterEmpty = true;
                    $scope.btnFilterDate = true;
                }

                if($rootScope.dataFilter.dateTo != undefined && $rootScope.dataFilter.dateTo != ""){            
                    var dateTo = new Date($rootScope.dataFilter.dateTo);
                    var dd2 = dateTo.getDate();
                    var mm2 = dateTo.getMonth()+1; //January is 0!
                    var yyyy2 = dateTo.getFullYear();
                    if(dd2<10){dd2='0'+dd2;} 
                    if(mm2<10){mm2='0'+mm2;}
                    $scope.tempdataDateTo = dd2+'/'+mm2+'/'+yyyy2;
                    $rootScope.tempDataFilter.dateTo = new Date($rootScope.dataFilter.dateTo);
                    $scope.FilterEmpty = true;
                    $scope.btnFilterDate = true;
                }
                
            }
        }

        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
    }

    $rootScope.showHideFilter = function (id){
        $rootScope.getCheckedCheckboxesFor();
        if($scope.distanceUpdt){
            $scope.changedistanceFilter()
        }
        if(id == 1){
            $scope.filter1 = !$scope.filter1;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 2){
            $scope.filter1 = false;
            $scope.filter2 = !$scope.filter2;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 3){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = !$scope.filter3;
            $scope.filter4 = false;            
            if($rootScope.tempDataFilter.distancelow == undefined) $rootScope.tempDataFilter.distancelow = 0;
            if($rootScope.tempDataFilter.distancehigh == undefined) $rootScope.tempDataFilter.distancehigh = 50;
        } else if(id == 4){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = !$scope.filter4;
        }
    }

    $scope.cgDistance = function(){
        if(document.querySelector('#lower') || document.querySelector('#upper')){
            var lowerSlider = document.querySelector('#lower')
            var upperSlider = document.querySelector('#upper')
            var lowerVal = parseInt(lowerSlider.value);
            var upperVal = parseInt(upperSlider.value);
            
            if (upperVal < lowerVal) {
                $scope.tempDataFilter.distancehigh = lowerVal;
                $scope.tempDataFilter.distancelow = upperVal;
                $scope.showDistanceLow = upperVal;
                $scope.showDistanceHigh = lowerVal;
            }else{
                $scope.tempDataFilter.distancelow = lowerVal;
                $scope.tempDataFilter.distancehigh = upperVal;
                $scope.showDistanceLow = lowerVal;
                $scope.showDistanceHigh = upperVal;
            }
        }
        
        $scope.FilterEmpty = true;
        $scope.distanceUpdt = true;
    }

    $scope.changedistance = false;
    $scope.changedistanceFilter = function (){
        if(document.querySelector('#lower') || document.querySelector('#upper')){
            var lowerSlider = document.querySelector('#lower')
            var upperSlider = document.querySelector('#upper')
            var lowerVal = parseInt(lowerSlider.value);
            var upperVal = parseInt(upperSlider.value);
            
            if (upperVal < lowerVal) {
                $scope.tempDataFilter.distancelow = upperVal;
                $scope.showDistanceLow = upperVal;
            }else{
                $scope.tempDataFilter.distancelow = lowerVal;
                $scope.showDistanceLow = lowerVal;
            }
            
            if (lowerVal > upperVal) {
                $scope.tempDataFilter.distancehigh = lowerVal;
                $scope.showDistanceHigh = lowerVal;
            }else{
                $scope.tempDataFilter.distancehigh = upperVal;
                $scope.showDistanceHigh = upperVal;
            }

            $scope.changedistance = true;
            $scope.FilterEmpty = true;
        }
        
    }
    
    $rootScope.functFilter = function(){
        $rootScope.getCheckedCheckboxesFor();
        // start:: if data is empty
        if($rootScope.dataSorting == undefined) $rootScope.dataSorting = ''
        if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
        if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
        if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
        if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
        if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
        if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        // end:: if data is empty
        
        // start:: if temp data not empty
        // Quick Filter
        var checkboxesQuick2 = document.querySelectorAll('input[name="quickFilter2"]:checked'), valuesVoucher2 = [];
        Array.prototype.forEach.call(checkboxesQuick2, function(el) {
            if(valuesVoucher2.length > 0){
                var n = valuesVoucher2.indexOf(el.value);
                if(n == -1) valuesVoucher2.push(el.value); 
            } else{
                valuesVoucher2.push(el.value);
            }
        });
        
        if(valuesVoucher2.length > 0) {
            $scope.tempdataVoucher2 = valuesVoucher2;
        }else{
            $scope.tempdataVoucher2 = "";
        }

        //-- Quick Filter Point
        var checkboxesQuick1 = document.querySelectorAll('input[name="quickFilter1"]:checked'), valuesQuick1 = [];
        Array.prototype.forEach.call(checkboxesQuick1, function(el) {
            if(valuesQuick1.length > 0){
                var n = valuesQuick1.indexOf(el.value);
                if(n == -1) valuesQuick1.push(el.value); 
            } else{
                valuesQuick1.push(el.value);
            }
        });
        if(valuesQuick1.length > 0) {
            $scope.tempdataQuick1 = valuesQuick1;
        }else{
            $scope.tempdataQuick1 = "";
        }
        if($scope.tempdataQuick1) $rootScope.dataFilter.mypoint = $scope.tempdataQuick1;
        if($scope.tempdataQuick1 == "") $rootScope.dataFilter.mypoint = ''

        if($scope.tempdataPoint) $rootScope.dataFilter.point = $scope.tempdataPoint;
        
        if($scope.tempdataVoucher) {
            $rootScope.dataFilter.status1 = $scope.tempdataVoucher;
            $rootScope.dataFilter.status = $scope.tempdataVoucher;
        }
        
        if($scope.tempdataVoucher2 != undefined && $scope.tempdataVoucher2 != "") {
            $rootScope.dataFilter.status2 = $scope.tempdataVoucher2;
            if($rootScope.dataFilter.status){
                $rootScope.dataFilter.status = $rootScope.dataFilter.status.concat($scope.tempdataVoucher2);
            } else{
                $rootScope.dataFilter.status = $scope.tempdataVoucher2;
            }
        }else{
            $rootScope.dataFilter.status2 = "";
        }
        if($scope.tempdataDateFrom) $rootScope.dataFilter.dateFrom = $rootScope.tempDataFilter.dateFrom;
        if($scope.tempdataDateTo) $rootScope.dataFilter.dateTo = $rootScope.tempDataFilter.dateTo;
        if($rootScope.tempDataFilter.distancelow != undefined && $rootScope.tempDataFilter.distancehigh != undefined){
            $rootScope.dataFilter.distance = $scope.tempDataFilter.distancelow +"-"+$scope.tempDataFilter.distancehigh;
        }
        // end:: if temp data not empty
        $rootScope.dataFilter.push($rootScope.tempDataFilter)

        console.log($rootScope.dataFilter)
        if ($state.current.name == 'app.point'){
            if($rootScope.footerMyPoint){ 
                pagenumber = 1;
                $rootScope.tabClickedMyVoucherFunc( $rootScope.dataFilter.distance,
                $scope.lat, $scope.long,
                $rootScope.searchMyVoucherVal, $rootScope.dataSorting, pagenumber, $rootScope.dataFilter.point,
                $rootScope.dataFilter.dateFrom, $rootScope.dataFilter.dateTo, $rootScope.dataFilter.status);

                // $stateParams.id_category,$rootScope.dataFilter.mypoint,$rootScope.dataFilter.distance,$scope.lat
                // ,$scope.long,'',$rootScope.dataSorting,pagenumber,$rootScope.dataFilter.point,
                // $rootScope.dataFilter.dateFrom,$rootScope.dataFilter.dateTo,$rootScope.dataFilter.status
            }
            else $state.go('app.listVoucher', {id_category:99});
        } 
        if ($state.current.name == 'app.listVoucher'){
            // $rootScope.idSearchPoint = 99;
            $rootScope.getDataListVoucher();
        } 
        if($state.current.name == 'app.newsearchPoint'){
            $rootScope.searchPoint($rootScope.search_point);
        }
        $scope.closemodalFilterSort();
    };

    $scope.FilterEmpty = false;
    $rootScope.clickFilter = clickFilter
    function clickFilter(){
        if($scope.filter1){
            var checkboxesPoint = document.querySelectorAll('input[name="point"]:checked')
            if(checkboxesPoint.length == 0){
                $scope.FilterEmpty = false;
            }else{
                $scope.FilterEmpty = true;
            }
        } 
        
        if($scope.filter4){
            var checkboxesVoucher = document.querySelectorAll('input[name="voucherStatus"]:checked');
            if(checkboxesVoucher.length == 0){
                $scope.FilterEmpty = false;
            }else{
                $scope.FilterEmpty = true;
            }
        } 
    }

    $rootScope.clickFilter1 = clickFilter1
    $rootScope.clickFilter2 = clickFilter2
    function clickFilter1(){
        //-- Quick Filter Point
        var checkboxesQuick1 = document.querySelectorAll('input[name="quickFilter1"]:checked');
        if(checkboxesQuick1.length == 0){
            $scope.FilterEmpty = false;
        }else{
            $scope.FilterEmpty = true;
        }
    }

    function clickFilter2(){
        // Quick Filter
        var checkboxesQuick2 = document.querySelectorAll('input[name="quickFilter2"]:checked');
        if(checkboxesQuick2.length == 0){
            $scope.FilterEmpty = false;
        }else{
            $scope.FilterEmpty = true;
        }
    }

    $rootScope.resetFilter = function(){
        $scope.tempdataPoint = ""
        $scope.tempdataVoucher = ""
        $scope.tempdataVoucher2 = ""
        $scope.tempdataQuick1 = ""
        $scope.tempdataDateTo = null;
        $scope.tempdataDateFrom = null;
        $rootScope.dataFilter = [];
        $rootScope.tempDataFilter = [];
        if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
        if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
        if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
        if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
        if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
        if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        $rootScope.tempDataFilter.distance = 0;
        $scope.btnFilterDate = false;

        $scope.filter1 = false;
        $scope.filter2 = false;
        $scope.filter3 = false;
        $scope.filter4 = false;

        // distance
        $scope.showDistanceLow = ""
        $scope.showDistanceHigh = ""
        $scope.changedistance = false;

        $scope.FilterEmpty = false;
        $scope.distanceUpdt = false;

        $scope.closemodalFilterSort();
        if ($state.current.name == 'app.listVoucher'){
            $rootScope.getDataListVoucher();
        } else if($state.current.name == 'app.newsearchPoint'){
            $rootScope.searchPoint($rootScope.search_point);
        } else if($rootScope.footerMyPoint){
            $rootScope.tabClickedMyVoucherFunc("","","", "" ,$rootScope.dataSorting,"","","","","");
        }
    }

    $rootScope.getCheckedCheckboxesFor = function() {
        //-- Point
        if($scope.filter1){
            var checkboxesPoint = document.querySelectorAll('input[name="point"]:checked'), valuesPoint = [];
            Array.prototype.forEach.call(checkboxesPoint, function(el) {
                if(valuesPoint.length > 0){
                    var n = valuesPoint.indexOf(el.value);
                    if(n == -1) valuesPoint.push(el.value); 
                } else{
                    valuesPoint.push(el.value);
                }
            });
            $scope.tempdataPoint = valuesPoint;
        }
        
        //-- Voucher Status
        if($scope.filter4){
            var checkboxesVoucher = document.querySelectorAll('input[name="voucherStatus"]:checked'), valuesVoucher = [];
            Array.prototype.forEach.call(checkboxesVoucher, function(el) {
                if(valuesVoucher.length > 0){
                    var n = valuesVoucher.indexOf(el.value);
                    if(n == -1) valuesVoucher.push(el.value); 
                } else{
                    valuesVoucher.push(el.value);
                }
            });
            $scope.tempdataVoucher = valuesVoucher;
        }    
    }

    location()
    function location(){
        var posOptions = { timeout: 10000, enableHighAccuracy: true };
        $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            if(position){
                $scope.lat = position.coords.latitude;
                $scope.long = position.coords.longitude;
            }
        });
    }
    

    $scope.btnFilterDate = false;
    $scope.dateselectFrom = function(){
        $scope.tempdataDateFrom = document.getElementById("fromFilter").value;
    }

    $scope.dateselectTo = function(){
        $scope.tempdataDateTo = document.getElementById("toFilter").value;
    }
    $rootScope.saveAvailability = function(){
        if($rootScope.tempDataFilter.dateFrom != undefined && $rootScope.tempDataFilter.dateFrom != "" && $rootScope.tempDataFilter.dateTo != undefined && $rootScope.tempDataFilter.dateTo != "" ){           
            // dateFrom = new Date($scope.tempdataDateFrom);
            // dateTo = new Date($scope.tempdataDateTo);
            
            var dateFrom = new Date($rootScope.tempDataFilter.dateFrom);            
            var dateTo = new Date($rootScope.tempDataFilter.dateTo);
            if ((dateFrom > dateTo)) {
                $ionicPopup.alert({
                    template: "End date should be greater than Start date",
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
                return false;
            }

            var dd1 = dateFrom.getDate();
            var mm1 = dateFrom.getMonth()+1; //January is 0!
            var yyyy1 = dateFrom.getFullYear();
            var dd2 = dateTo.getDate();
            var mm2 = dateTo.getMonth()+1; //January is 0!
            var yyyy2 = dateTo.getFullYear();
            if(dd1<10){dd1='0'+dd1;} 
            if(mm1<10){mm1='0'+mm1;} 
            if(dd2<10){dd2='0'+dd2;} 
            if(mm2<10){mm2='0'+mm2;} 

            $scope.tempdataDateFrom = dd1+'/'+mm1+'/'+yyyy1;
            $scope.tempdataDateTo = dd2+'/'+mm2+'/'+yyyy2;
            
            $rootScope.tempDataFilter.dateFrom = yyyy1+'-'+mm1+'-'+dd1;   
            $rootScope.tempDataFilter.dateTo = yyyy2+'-'+mm2+'-'+dd2;   
            $scope.filter2 = !$scope.filter2;
            $scope.btnFilterDate = true;
            $scope.FilterEmpty = true;
        }else{
            $ionicPopup.alert({
                template: "Please insert date",
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
        }
    }

    $scope.resetDate = function(){
        $scope.tempdataDateTo = null;
        $scope.tempdataDateFrom = null;
        $rootScope.tempDataFilter.dateFrom = "";
        $rootScope.tempDataFilter.dateTo = "";
        $scope.btnFilterDate = false;
        $scope.FilterEmpty = false;
    }
    // end:: FUNCTION FILTER POINT

    function notResident(){

        $ionicPopup.alert({
            // title: $filter('translate')('login_failed'),
            template: $filter('translate')('are_resident'),
            okText: $filter('translate')('okay'),
            cssClass: "alertPopup"
        });
        $state.go('app.main');
    }

    $scope.$on("$ionicView.beforeEnter", function () {
        if ($state.current.name == 'app.eComplaint' ||
            $state.current.name == 'app.loginebilling' ||
            $state.current.name == 'app.billing' ||
            $state.current.name == 'app.cctvList' ||
            $state.current.name == 'app.eComplaintAdd'
        ) {

            if (!$localStorage.currentUser) {
                notResident();
                return false;
            }

            if ($localStorage.currentUser['data'][0]['privilege'] != "resident") {
                notResident();
                return false;
            }

            if($state.current.name == 'app.billing'){
                var email = 'samadhi.emaus@yahoo.com';
                // if ($localStorage.currentUser) {
                //     if ($localStorage.currentUser.data) {
                //         if ($localStorage.currentUser.data[0]) {
                //             if ($localStorage.currentUser.data[0].email) {
                //                 email = $localStorage.currentUser.data[0].email;
                //             }
                //         }
                //     }
                // }
    
                if (email) {
                    loginBilling(email);
                }
            }
            
        }
    });

    function loginBilling(email) {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.loginBillingServices(email, function (response) {
            $ionicLoading.hide();
            if (response) {
                if (response.status) {
                    console.log(response);
                } else if (!response.status) {
                    $ionicLoading.hide();
                    $ionicPopup.alert({
                        title: $filter('translate')('login_failed'),
                        template: response.message,
                        okText: $filter('translate')('try_again'),
                        cssClass: "alertPopup"
                    });
                    // $state.go('app.main');
                } else {
                    $ionicLoading.hide();
                    $ionicPopup.alert({
                        title: $filter('translate')('login_failed'),
                        template: $filter('translate')('check_email'),
                        okText: $filter('translate')('try_again'),
                        cssClass: "alertPopup"
                    });
                    // $state.go('app.main');
                }
            } else {
                console.log(response);
            }
        });
    }

    $scope.$on("$ionicView.beforeEnter", function () {
        if ($location.path().substr(0, 11) == "/app/search" || $location.path().substr(0, 19) == "/app/propertysearch" ||
            $location.path() == "/app/history" ||
            $location.path().substr(0, 14) == "/app/myhistory" ||
            $location.path() == "/app/profile" ||
            $location.path() == "/app/map" ||
            $location.path() == "/app/more" ||
            $location.path() == "/app/editprofile" ||
            $location.path() == "/app/iniviteFriend" ||
            $location.path() == "/app/aboutUs" ||
            $location.path() == "/app/aboutHelp" ||
            $location.path() == "/app/callCenter" ||
            $location.path() == "/app/worldclock" ||
            $location.path() == "/app/loginebilling" ||
            $location.path() == "/app/newforum" ||
            $location.path() == "/app/categories" ||
            $location.path() == "/app/loginbilling" ||
            $location.path() == "/app/payment" ||
            $location.path() == "/app/transaction" ||
            $location.path() == "/app/paymentmidtransbanktransfer" ||
            $state.current.name == 'app.forumdetail' ||
            $state.current.name == 'app.cctvDetail' ||
            $state.current.name == 'app.tenantCategory' ||
            $state.current.name == 'app.propertylist' ||
            $state.current.name == 'app.notificationDetail' ||
            $location.path() == "/app/download" ||
            $location.path().substr(0, 19) == "/app/downloadDetail" ||
            $location.path() == "/app/eComplaintAdd" ||
            $location.path() == "/app/tenantMap" ||
            $location.path() == "/app/billing") {
            $scope.navbar = false;
            $scope.searchbar = false;
        } else {
            $scope.navbar = true;
            $scope.searchbar = false;
            $rootScope.search_page = "";
        }
    });

    //goto currency
    $scope.gotocurrency = function () {
        $location.path('app/currency')
    }

    $scope.gotoYoutube = function () {
        window.open("https://www.youtube.com/watch?v=h-DvHNnlFrs", '_system', 'location=yes')
    }

    function isSOS() {

        var scheme;

        // Don't forget to add the cordova-plugin-device plugin for `device.platform`
        try {
            if (device.platform === 'iOS') {
                scheme = 'sos1health://';
            }
            else if (device.platform === 'Android') {
                scheme = 'com.app.onehealth';
            }

            // this function invokes the plugin:
            appAvailability.check(
                scheme,
                function onSucces(result) {
                    gotoApps();
                },
                function onError(error) {
                    gotoAppStore();
                }
            );
        } catch (e) {

        }

        function gotoApps() {
            window.open('sos1health://', '_system', 'location=no');
            console.log('Ambulance Siloam 1health Installed');
        }

        function gotoAppStore() {
            window.open('https://itunes.apple.com/id/app/ambulance-siloam-1health/id1126512880?mt=8', '_system', 'location=no');
            console.log('Ambulance Siloam 1health Not Installed');
        }

    }

    $scope.logoutConfirm = logoutConfirm;
    function logoutConfirm() {
        var confirmPopup = $ionicPopup.confirm({
            template: $filter('translate')('dialog_signout'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                LoginService.logoutUser();
                $rootScope.buttonDisabled = false;
                $ionicLoading.show({ template: $filter('translate')('logoutmessage') + "...", duration: 500 });
                window.plugins.googleplus.logout(
                    function (msg) {
                        window.plugins.googleplus.disconnect(
                            function (msg) {

                            }
                        );
                    }
                );
                $state.go('login');
            }
        });
    }

}

function weather($scope, $cordovaGeolocation, $filter, $localStorage, mainService) {
    console.log("test weather");
    navigator.geolocation.getCurrentPosition(function (pos) {
        lat = pos.coords.latitude
        long = pos.coords.longitude
        weatherservice($scope, $filter, lat, long)
    }, function (error) {
        navigator.geolocation.watchPosition
            (function onSucces(position) {

            }, function onMapError(error) {

            },
            { enableHighAccuracy: false });
    });

    function weatherservice($scope, $filter, lat, long) {
        mainService.reqweather(lat, long, function (weatherresponse) {

            if (weatherresponse != false) {
                $scope.data_weather = {
                    temp: parseInt(weatherresponse.main.temp - 273.15),
                    icon: parseInt($filter('filter')(weatherresponse.weather, function (d) {
                        return d.id
                    })[0].id / 100)
                }
            } else {
                console.log(error.message);
            }

        });

        function geticonweather(dt, id, sunrise, sunset) {
            if (id == 800) {
                if (dt >= sunrise && dt < sunset) {
                    icon = '&#xf00d;'
                } else {
                    icon = '&#xf02e;'
                }
            } else {
                switch (id) {
                    case 200:
                        icon = '&#xf01e;';
                        break;
                    case 300:
                        icon = '&#xf01c;';
                        break;
                    case 500:
                        icon = '&#xf019;';
                        break;
                    case 600:
                        icon = '&#xf01b;';
                        break;
                    case 700:
                        icon = '&#xf0b6;';
                        break;
                    case 800:
                        icon = '&#xf013;';
                        break;
                }
            }

            return icon;
        }

    }

}

function currencymain($scope, $localStorage) {
    console.log("test currencymain");
    try {
        $scope.currate = $localStorage.currency.currency;
    } catch (e) {
        $scope.currate = null;

    }
}

function main($scope, $filter, $localStorage) {
    $scope.title = $filter('translate')('app_name');
}




