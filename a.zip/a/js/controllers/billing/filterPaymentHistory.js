angular
    .module('livein')
    .controller('filterPaymentHistoryCtrl', filterPaymentHistory);

function filterPaymentHistory($scope, $rootScope, $ionicPopup, $filter, $localStorage) {
    var email = $localStorage.currentUser.data[0].email;
    $scope.tempPaymentMethod = [];
    $scope.tempPaymentUnit = [];
    $scope.tempNumOfUnit = [];

    if($scope.tempDataFilter == undefined) {
        $scope.tempDataFilter = [];
    }
    
    if($rootScope.dataFilterPaymentHistory.length > 0){
        $scope.tempDataFilter = [];
        var dataFilter = $rootScope.dataFilterPaymentHistory[0];

        angular.forEach(dataFilter.paymentMethod, function(obj){
            $scope.lblPaymentMethod = [];
            dataFilter.paymentMethod.forEach(function(data){
                var unit;
                if(data=="ovo") unit = $filter('translate')('with_ovo')
                if(data=="midtrans") unit = $filter('translate')('with_midtrans')
                $scope.lblPaymentMethod.push(unit);
            })
            
            $scope.tempPaymentMethod = dataFilter.paymentMethod
            if(obj == "ovo") $scope.tempDataFilter.paymentMethod1 = true;
            if(obj == "midtrans") $scope.tempDataFilter.paymentMethod2 = true;
            $scope.FilterEmpty = true;
        })
    
        angular.forEach(dataFilter.paymentUnit, function(obj){
            $scope.lblPaymentUnit = [];
            $scope.tempPaymentUnit = [];
            
            dataFilter.paymentUnit.forEach(function(data){
                var unit, valueUnit;
                if(data==email) {
                    unit = $filter('translate')('my_unit');
                    valueUnit = email;
                }
                if(data!=email) {
                    unit = $filter('translate')('others');
                    valueUnit = email;
                }
                $scope.lblPaymentUnit.push(unit);
                $scope.tempPaymentUnit.push(valueUnit);
            })

            if(obj == email) $scope.tempDataFilter.paymentUnit1 = true;
            if(obj != email) $scope.tempDataFilter.paymentUnit2 = true;
            $scope.FilterEmpty = true;
        })
        

        angular.forEach(dataFilter.numOfUnit, function(obj){
            $scope.lblNumOfUnit = [];
            dataFilter.numOfUnit.forEach(function(data){
                var unit;
                if(data=="1") unit = "1 " + $filter('translate')('unit');
                if(data=="2") unit = "> 1 " + $filter('translate')('unit');
                $scope.lblNumOfUnit.push(unit);
            })
            $scope.tempNumOfUnit = dataFilter.numOfUnit
            if(obj == "1") $scope.tempDataFilter.numOfUnit1 = true;
            if(obj == "2") $scope.tempDataFilter.numOfUnit2 = true;
            $scope.FilterEmpty = true;
        })

        if(dataFilter.dateFrom != undefined && dataFilter.dateFrom != ""){
            var dateFrom = new Date(dataFilter.dateFrom);
            var dd1 = dateFrom.getDate();
            var mm1 = dateFrom.getMonth()+1; //January is 0!
            var yyyy1 = dateFrom.getFullYear();
            if(dd1<10){dd1='0'+dd1;} 
            if(mm1<10){mm1='0'+mm1;} 
            $scope.tempdataDateFrom = dd1+'/'+mm1+'/'+yyyy1;
            $scope.tempDataFilter.dateFrom = new Date(dataFilter.dateFrom);
            $scope.FilterEmpty = true;
            $scope.lblFilterDate = true;
        }

        if(dataFilter.dateTo != undefined && dataFilter.dateTo != ""){            
            var dateTo = new Date(dataFilter.dateTo);
            var dd2 = dateTo.getDate();
            var mm2 = dateTo.getMonth()+1; //January is 0!
            var yyyy2 = dateTo.getFullYear();
            if(dd2<10){dd2='0'+dd2;} 
            if(mm2<10){mm2='0'+mm2;}
            $scope.tempdataDateTo = dd2+'/'+mm2+'/'+yyyy2;
            $scope.tempDataFilter.dateTo = new Date(dataFilter.dateTo);
            $scope.FilterEmpty = true;
            $scope.lblFilterDate = true;
        }
    }

    $scope.showHideFilter = function (id){
        $scope.getCheckedCheckboxesFor();
        if(id == 1){
            $scope.filter1 = !$scope.filter1;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 2){
            $scope.filter1 = false;
            $scope.filter2 = !$scope.filter2;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 3){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = !$scope.filter3;
            $scope.filter4 = false;      
        } else if(id == 4){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = !$scope.filter4;
        }
    }

    $scope.closemodalFilter = function(){
        $scope.filter1 = false;
        $scope.filter2 = false;
        $scope.filter3 = false;
        $scope.filter4 = false;
        $rootScope.modalFilterPaymentHistory.hide();
    }

    $scope.resetFilter = function(){
        $rootScope.dataFilterPaymentHistory = [];
        $scope.tempDataFilter = [];
        $scope.lblFilterDate = false;
        $scope.tempPaymentMethod = []
        $scope.tempPaymentUnit = []
        $scope.tempNumOfUnit = []

        $scope.filter1 = false;
        $scope.filter2 = false;
        $scope.filter3 = false;
        $scope.filter4 = false;

        $scope.FilterEmpty = false;
        $rootScope.pagenumberTrigger = "first";
        $rootScope.getBillingHistory("reset");
        $scope.closemodalFilter();
    }

    $scope.clickFilter = function (){
        if($scope.filter1){
            var cbFilter1 = document.querySelectorAll('input[name="paymentMethod"]:checked')
            if(cbFilter1.length == 0 && $scope.tempPaymentUnit.length == 0 && $scope.tempNumOfUnit.length == 0){
                $scope.FilterEmpty = false;
            }else{
                $scope.FilterEmpty = true;
            }
        } 

        if($scope.filter2){
            var cbFilter2 = document.querySelectorAll('input[name="paymentUnit"]:checked')
            if(cbFilter2.length == 0 && $scope.tempPaymentUnit.length == 0 && $scope.tempNumOfUnit.length == 0){
                $scope.FilterEmpty = false;
            }else{
                $scope.FilterEmpty = true;
            }
        } 

        if($scope.filter3){
            var cbFilter3 = document.querySelectorAll('input[name="NumOfUnit"]:checked')
            if(cbFilter3.length == 0 && $scope.tempPaymentUnit.length == 0 && $scope.tempNumOfUnit.length == 0){
                $scope.FilterEmpty = false;
            }else{
                $scope.FilterEmpty = true;
            }
        } 
    }

    $scope.dateselectFrom = function(){
        $scope.tempdataDateFrom = document.getElementById("fromFilter").value;
    }

    $scope.dateselectTo = function(){
        $scope.tempdataDateTo = document.getElementById("toFilter").value;
    }

    $scope.formatDate = function(){
        if($scope.tempDataFilter.dateFrom != undefined && $scope.tempDataFilter.dateFrom != "" && $scope.tempDataFilter.dateTo != undefined && $scope.tempDataFilter.dateTo != "" ){           
            
            var dateFrom = new Date($scope.tempDataFilter.dateFrom);            
            var dateTo = new Date($scope.tempDataFilter.dateTo);
            if ((dateFrom > dateTo)) {
                $ionicPopup.alert({
                    template: "End date should be greater than Start date",
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
                return false;
            }

            var dd1 = dateFrom.getDate();
            var mm1 = dateFrom.getMonth()+1; //January is 0!
            var yyyy1 = dateFrom.getFullYear();
            var dd2 = dateTo.getDate();
            var mm2 = dateTo.getMonth()+1; //January is 0!
            var yyyy2 = dateTo.getFullYear();
            if(dd1<10){dd1='0'+dd1;} 
            if(mm1<10){mm1='0'+mm1;} 
            if(dd2<10){dd2='0'+dd2;} 
            if(mm2<10){mm2='0'+mm2;} 

            $scope.tempdataDateFrom = dd1+'/'+mm1+'/'+yyyy1;
            $scope.tempdataDateTo = dd2+'/'+mm2+'/'+yyyy2;
            
            $scope.tempDataFilter.dateFrom = yyyy1+'-'+mm1+'-'+dd1;   
            $scope.tempDataFilter.dateTo = yyyy2+'-'+mm2+'-'+dd2;   
            
            $scope.lblFilterDate = true;
            $scope.FilterEmpty = true;
        }else{
            $ionicPopup.alert({
                template: "Please insert date",
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
        }
    }

    $scope.saveAvailability = function(){
        $scope.formatDate();
        $scope.filter4 = !$scope.filter4;
    }

    $scope.resetDate = function(){
        $scope.tempdataDateTo = null;
        $scope.tempdataDateFrom = null;
        $scope.tempDataFilter.dateFrom = "";
        $scope.tempDataFilter.dateTo = "";
        $scope.lblFilterDate = false;
        
        if($scope.tempDataFilter.paymentMethod1 == undefined && $scope.tempDataFilter.paymentMethod2 == undefined &&
            $scope.tempDataFilter.paymentUnit1 == undefined && $scope.tempDataFilter.paymentUnit2 == undefined &&
            $scope.tempDataFilter.numOfUnit1 == undefined && $scope.tempDataFilter.numOfUnit2 == undefined){
                $scope.FilterEmpty = false;
                $rootScope.dataFilterPaymentHistory = [];
                $scope.tempDataFilter = [];
            }
    }

    $scope.getCheckedCheckboxesFor = function() {
        //-- Payment Method
        if($scope.filter1){
            var cbFilter1 = document.querySelectorAll('input[name="paymentMethod"]:checked'), valFilter1 = [];
            Array.prototype.forEach.call(cbFilter1, function(el) {
                if(valFilter1.length > 0){
                    var n = valFilter1.indexOf(el.value);
                    if(n == -1) valFilter1.push(el.value); 
                } else{
                    valFilter1.push(el.value);
                }
            });
            $scope.tempPaymentMethod = valFilter1;

            $scope.lblPaymentMethod = [];
            valFilter1.forEach(function(data){
                var unit;
                if(data=="ovo") unit = $filter('translate')('with_ovo')
                if(data=="midtrans") unit = $filter('translate')('with_midtrans')
                $scope.lblPaymentMethod.push(unit);
            })
        }

        //-- Payment Unit
        if($scope.filter2){
            var cbFilter2 = document.querySelectorAll('input[name="paymentUnit"]:checked'), valFilter2 = [];
            Array.prototype.forEach.call(cbFilter2, function(el) {
                if(valFilter2.length > 0){
                    var n = valFilter2.indexOf(el.value);
                    if(n == -1) valFilter2.push(el.value); 
                } else{
                    valFilter2.push(el.value);
                }
            });

            $scope.lblPaymentUnit = [];
            $scope.tempPaymentUnit = [];
            valFilter2.forEach(function(data){
                var unit, valueUnit;
                if(data=="myunit") {
                    unit = $filter('translate')('my_unit');
                    valueUnit = email;
                }
                if(data=="other") {
                    unit = $filter('translate')('others');
                    valueUnit = "masrof@gmail.com";
                }
                $scope.lblPaymentUnit.push(unit);
                $scope.tempPaymentUnit.push(valueUnit);
            })
        }

        //-- Number Of Unit
        if($scope.filter3){
            var cbFilter3 = document.querySelectorAll('input[name="NumOfUnit"]:checked'), valFilter3 = [];
            Array.prototype.forEach.call(cbFilter3, function(el) {
                if(valFilter3.length > 0){
                    var n = valFilter3.indexOf(el.value);
                    if(n == -1) valFilter3.push(el.value); 
                } else{
                    valFilter3.push(el.value);
                }
            });
            $scope.tempNumOfUnit = valFilter3;

            $scope.lblNumOfUnit = [];
            valFilter3.forEach(function(data){
                var unit;
                if(data=="1") unit = "1 " + $filter('translate')('unit');
                if(data=="2") unit = "> 1 " + $filter('translate')('unit');
                $scope.lblNumOfUnit.push(unit);
            })
        }
    }

    $scope.functFilter = function(){
        $scope.getCheckedCheckboxesFor();
        if($scope.tempPaymentMethod) $scope.tempDataFilter.paymentMethod = $scope.tempPaymentMethod;
        if($scope.tempPaymentUnit) $scope.tempDataFilter.paymentUnit = $scope.tempPaymentUnit;
        if($scope.tempNumOfUnit) $scope.tempDataFilter.numOfUnit = $scope.tempNumOfUnit;
        if($scope.tempdataDateFrom && $scope.tempdataDateTo) $scope.formatDate();

        $rootScope.dataFilterPaymentHistory = [];
        $rootScope.dataFilterPaymentHistory.push($scope.tempDataFilter);
        $rootScope.pagenumberTrigger = "first";
        $rootScope.getBillingHistory();
        
        $scope.closemodalFilter();
    };
}