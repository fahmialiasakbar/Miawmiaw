angular
    .module('livein')
    .controller('detailHistoryBilling', detailHistoryBilling)
    .controller('needhelp', needHelp);

    function detailHistoryBilling($scope, $rootScope, $ionicHistory, billingServices, $stateParams, $state, $ionicLoading, $filter, $ionicPopup, $window) {

        $rootScope.cacheBilling = true;
        $scope.strToDate = function(date){
            var dt = moment(date, 'YYYY-MM-DD HH:mm:ss').toDate();
            return dt;
        } 
        $scope.myGoBack = function () {
            $state.go('app.billing');
            $ionicHistory.nextViewOptions({
                disableBack: true
            });
        };

        $scope.toNeedHelp = function(){
            $state.go('app.needhelp');
        }

        $scope.toDownloadPdf = function(){
            billingServices.downloadDetail($stateParams.merchanttransactionid, function(response){
                
            });

            var link = 'http://innodev.vnetcloud.com/liveinpayment/download?merchanttransactionid='+$stateParams.merchanttransactionid;
            $window.open(link, '_system', 'location=yes');
        }
        // '20181219171908865'n
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        billingServices.detailPaymentHistory($stateParams.merchanttransactionid, function(response){
            if(response.status == 'success'){
                $ionicLoading.hide();

                $scope.data = response.data;
                var datePayment = $scope.strToDate(response.data.transaction_date);
                
                if(lang=='ina'){
                    var dayNames = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
                    var monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
                }else{
                    var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
                    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                }

                var idxDay = datePayment.getDay();
                $scope.day = dayNames[idxDay] + ', ';
                var idxMonth = datePayment.getMonth();
                $scope.month = monthNames[idxMonth];
                $scope.data.transaction_date = datePayment;
                
                if(lang=='ina'){
                    $scope.data.show_status = $scope.data.status_id;
                }else{
                    $scope.data.show_status = $scope.data.status;
                }

                $scope.title = response.data.units[0].unitName +' | '+ response.data.units[0].unitNo ;
                
                $scope.payment = response.data.units;
                for(var i=0; i<$scope.payment.length; i++){
                    $scope.payment[i].id = i;
                    var bulan = $scope.payment[i].periode;
                    if(lang=='ina'){
                        bulan = bulan.replace("Januari", "JAN");
                        bulan = bulan.replace("Februari", "FEB");
                        bulan = bulan.replace("Maret", "MAR");
                        bulan = bulan.replace("April", "APR");
                        bulan = bulan.replace("Mei", "MEI");
                        bulan = bulan.replace("Juni", "JUN");
                        bulan = bulan.replace("Juli", "JUL");
                        bulan = bulan.replace("September", "AGU");
                        bulan = bulan.replace("Agustus", "SEP");
                        bulan = bulan.replace("Oktober", "OKT");
                        bulan = bulan.replace("November", "NOV");
                        bulan = bulan.replace("Desember", "DES");
                    }else{
                        bulan = bulan.replace("Januari", "JAN");
                        bulan = bulan.replace("Februari", "FEB");
                        bulan = bulan.replace("Maret", "MAR");
                        bulan = bulan.replace("April", "APR");
                        bulan = bulan.replace("Mei", "MEI");
                        bulan = bulan.replace("Juni", "JUN");
                        bulan = bulan.replace("Juli", "JUL");
                        bulan = bulan.replace("September", "AUG");
                        bulan = bulan.replace("Agustus", "SEP");
                        bulan = bulan.replace("Oktober", "OCT");
                        bulan = bulan.replace("November", "NOV");
                        bulan = bulan.replace("Desember", "DEC");
                    
                    }
                    $scope.payment[i].newPeriode = bulan;
                }
                
                $scope.payment.forEach(function(val){
                    $scope['btn_unit_'+val.id] = false;
                }); 
                
                $scope.payment_type = response.data.payment_type;
                $scope.va_number = response.data.va_number;
                $scope.credit_card = getFormattedCC(response.data.masked_card);


            }else{
                // $ionicLoading.hide();
                // $ionicPopup.alert({
                //     template: lang == 'ina' ? response.message_id : response.message,
                //     okText: $filter('translate')('close'),
                //     cssClass: "alertPopup"
                // });
            }
        })

        $scope.showHideUnitDetails = function (id){
            $scope['btn_unit_'+id] = !$scope['btn_unit_'+id];
        }

        $scope.varUnitDetails = function(id){
            return $scope['btn_unit_'+id];
        }

        function getFormattedCC(str) {
            var lip1 = str.substr(0, 4);
            var lip2 = str.substr(4, 2);
            var lip3 = str.substr(7, 4);
            var res = lip1 + " "+ lip2 +"** **** "+lip3;
            return res;
          }

    }

    function needHelp($scope, $ionicHistory, $cordovaSocialSharing){
        $scope.myGoBack = function(){
            $ionicHistory.goBack();
        }
        
        $scope.openEmail = function(){
            $cordovaSocialSharing
                .shareViaEmail(null, null, ['CS@lippo-cikarang.com'], ['', ""], [' ', ""], null)
                .then(function (result) {
                    // Success!
                }, function (err) {
                    alert("Cannot share on Email" + error);
                });
            $scope.modalMenu.hide();
        }
    }
