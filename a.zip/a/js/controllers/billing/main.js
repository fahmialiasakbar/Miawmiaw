angular
    .module('livein')
    .controller('mainBilling', mainBilling);

function mainBilling($rootScope, $window, billingServices, $ionicSlideBoxDelegate, $ionicScrollDelegate, $localStorage, $scope, $state, $ionicLoading, $ionicPlatform, $ionicPopup, $timeout, $filter, $ionicModal) {
    // general tab & property tab
    var genTab = angular.element(document.querySelector('#tab1'));
    var proTab = angular.element(document.querySelector('#tab2'));
    $scope.otherBilling = otherBilling;
    $rootScope.filterPaymentHistory = filterPaymentHistory;
    $scope.payNow = payNow;
    $scope.slideChanged = slideChanged;
    $scope.showTab1 = showTab1;
    $scope.showTab2 = showTab2;
    $scope.detailBillingStatement = detailBillingStatement;
    $scope.closeModalDetailBilling = closeModalDetailBilling;
    $scope.payNowBillingDetail = payNowBillingDetail;
    $scope.loadMore = loadMore;
    $scope.arrHistoryList = [];
    $scope.startDate='';
    $scope.endDate='';
    var pagenumber = 1;
    $rootScope.pagenumberTrigger = "first";


    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
    $scope.$on("$ionicView.beforeEnter", function () {
        if(!$rootScope.cacheBilling){
            $state.current.cache = false;
            showTab1();
        }
        
        $rootScope.cacheBilling = false;
    });

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm:ss').toDate();
        return dt;
    } 
    var email = 'samadhi.emaus@yahoo.com';

    // var email = '';
    // if ($localStorage.currentUser) {
    //     if ($localStorage.currentUser.data) {
    //         if ($localStorage.currentUser.data[0]) {
    //             if ($localStorage.currentUser.data[0].email) {
    //                 email = $localStorage.currentUser.data[0].email;
    //             }
    //         }
    //     }
    // }
    
    $rootScope.emailres = email; //params older billing 
    $scope.fakelist = [1, 2, 3, 4];
    genTab.addClass("active");
    getDataLogin();

    function showTab1() {
        $ionicSlideBoxDelegate.previous();
        $scope.tab1 = 'active';
        $scope.tab2 = '';
        $rootScope.footerPaymentHistory = false;
        $rootScope.footerBillingStatement = true;
        analyticView('Billing Statement');
    };

    function showTab2() {
        $ionicSlideBoxDelegate.next();
        $scope.tab2 = 'active';
        $scope.tab1 = '';
        $rootScope.footerPaymentHistory = true;
        $rootScope.footerBillingStatement = false;
        analyticView('History Payment');
    };


    $rootScope.getBillingHistory = function (action) {
        if ($rootScope.dataFilterPaymentHistory.length > 0) {
            if ($rootScope.pagenumberTrigger == "first") {
                $scope.arrHistoryList = [];
                pagenumber = 1;
                $rootScope.pagenumberTrigger = "second";
                goTop();
            } else {
                pagenumber++;
            }
            var dataFilter = $rootScope.dataFilterPaymentHistory[0];

            if (dataFilter.paymentMethod.length == 0) dataFilter.paymentMethod = "";
            if (dataFilter.numOfUnit.length == 0) {
                dataFilter.startNumOfUnit = "";
                dataFilter.endNumOfUnit = "";
            } else {
                if (dataFilter.numOfUnit == "1") {
                    dataFilter.startNumOfUnit = 1;
                    dataFilter.endNumOfUnit = 1;
                } else {
                    dataFilter.startNumOfUnit = 1;
                    dataFilter.endNumOfUnit = 100;
                }
            }
            if (dataFilter.dateFrom == undefined) dataFilter.dateFrom = "";
            if (dataFilter.dateTo == undefined) dataFilter.dateTo = "";

            var emailFilter = dataFilter.paymentUnit.length == 0 ? email : dataFilter.paymentUnit;
            getHistoryDetail(emailFilter, dataFilter.paymentMethod, dataFilter.startNumOfUnit, dataFilter.endNumOfUnit, dataFilter.dateFrom, dataFilter.dateTo);
        } else {
            if (action == "reset" || action == "init") {
                $scope.arrHistoryList = [];
                pagenumber = 1;
                $rootScope.pagenumberTrigger = "first";
                goTop();
            } else {
                pagenumber++;
            }

            getHistoryDetail(email, "", "", "", "", "");
        }
    }

    function loadMore() {

        $scope.$broadcast('scroll.infiniteScrollComplete');
        $rootScope.getBillingHistory();
    }

    $scope.doRefreshPaymentHistory = function(){
        $rootScope.pagenumberTrigger = "first";
        $rootScope.getBillingHistory("init");
        $scope.$broadcast('scroll.refreshComplete');
    }

    function goTop(){
        $ionicScrollDelegate.scrollTop();
    }
    
    $scope.historyList = [];
    $scope.isEmpty = true;
    function getHistoryDetail(email, payment_method, start_number_of_unit, end_number_of_unit, start_date, end_date) {
        billingServices.paymentHistory(email, payment_method, start_number_of_unit, end_number_of_unit, start_date, end_date, pagenumber, function (response) {
            
            if (response) {
                if (response.status == "success") {
                    for (var i = 0; i < response.data.length; i++) {
                        var datePayment = $scope.strToDate(response.data[i].transaction_date);
                
                        if(lang=='ina'){
                            var months = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
                        }else{
                            var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
                        }

                        var idxMonth = datePayment.getMonth();
                        response.data[i].month = months[idxMonth];
                        response.data[i].transaction_date = datePayment;

                        if(lang=='ina'){
                            response.data[i].show_status = response.data[i].status_id;
                        }else{
                            response.data[i].show_status = response.data[i].status;
                        }
                    }

                    // group by month transaction
                    if ($scope.arrHistoryList.length == 0) {
                        $scope.arrHistoryList = response.data;
                    } else {
                        $scope.arrHistoryList = $scope.arrHistoryList.concat(response.data);
                    }
                    
                    var arrHistory = $scope.arrHistoryList;
                    if(lang=='en'){
                        var monthNames = [
                            "DECEMBER", "NOVEMBER", "OCTOBER" , "SEPTEMBER",
                            "AUGUST", "JULY", "JUNE",
                            "MAY", "APRIL", "MARCH",
                            "FEBRUARY", "JANUARY"
                        ];
                    }else{
                        var monthNames = [
                            "DESEMBER", "NOVEMBER", "OKTOBER",
                            "SEPTEMBER", "AGUSTUS", "JULI", "JUNI",
                            "MEI", "APRIL", "MARET",
                            "FEBRUARI", "JANUARI"
                        ];
                    }
                    

                    function groupBy(array, f) {
                        var groups = {};
                        array.forEach(function (data) {
                            var date = f(data);
                            var idxmonth = 11-(date.getMonth());
                            var year = date.getFullYear();
                            var tempidxMonth = idxmonth + '' + year;
                            var tempMonth = monthNames[idxmonth] + ' ' + year;
                            groups[tempidxMonth] = groups[tempidxMonth] || [];
                            groups[tempidxMonth].descMonth = tempMonth;
                            groups[tempidxMonth].push(data);
                        });

                        return Object.keys(groups).map(function (result) {
                            return groups[result];
                        })
                    }

                    $scope.historyList = groupBy(arrHistory, function (item) {
                        return item.transaction_date;
                    });
                    $scope.isEmpty = false;
                    $scope.noMoreItemsAvailable = true;
                } else {
                    $scope.noMoreItemsAvailable = false;
                    $scope.isEmpty = false;
                }
            }else{
                $scope.isEmpty = true;
                $scope.historyList = [];
                $scope.noMoreItemsAvailable = false;
            }
            $scope.hideSke = true;
        });
    }

    function getDataLogin() {
        billingServices.loginBillingServices(email, function (response) {
            if (response) {
                if (response.status) {
                    $scope.dataResident = response.data;
                    $scope.dataSite = response.data.Site;
                    if (response.data.Site.length > 0) {
                        getdata(response); 
                        getBillingStatement();
                        // getHistoryDetail(email, '', '', '', '', '');
                        $rootScope.getBillingHistory("init");
                    }
                }
            } else {
                console.log(response);
            }
            $scope.hideSkeleton = true;
        });
    }

    function getdata(data) {
        $rootScope.datasite = [];
        $scope.datares = data.data['@attributes'];
        angular.forEach(data.data.Site, function (value, key) {
            $scope.datasite.push(value);
        });
    }

    function getBillingStatement() {
        // billingServices.getbilling(email, siteId, function (response) {
        //     if (response) {
        //         $scope.atributeres = response.data['@attributes'];
        //         $scope.billingoutstandingbalance = $scope.atributeres.BillingOutstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
        //         $scope.amountpaid = $scope.billingoutstandingbalance;
        //         $scope.billingName = $scope.atributeres.Name;
        //         $scope.dataPeriode = response.data;
        //     } else {
        //         console.log(response);
        //     }
        // });

        billingServices.getbillingmultiside(email, function (response) {
            if (response) {
                if(response.status == 'success'){
                    // $scope.dataMultiSite = response.data['Site'];
                    var range  = [];
                    $scope.dataMultiSite=[];

                    angular.forEach(response.data['Site'], function (value, key) {
                        $scope.pushed = true;
                        for (var i = 0; i <= range.length; i += 1) {
                            if(value['@attributes'].SiteID==range[i]){
                                $scope.pushed = false;
                            }
                        }
            
                        if($scope.pushed==true){
                            range.push(value['@attributes'].SiteID);
                            $scope.dataMultiSite.push(value);
                        }
                    });

                    $scope.amountpaid = [];
                    $scope.dataMultiSite.forEach(function(obj){
                        $scope.atributeres = obj['@attributes'];
                        if($scope.atributeres.Name) $scope.billingName = $scope.atributeres.Name;
                        if(obj['@attributes'].BillingOutstandingBalance > 0){
                            $scope.amountpaid.push(obj['@attributes'].BillingOutstandingBalance);
                        }
                    })
                }
            } else {
                console.log(response);
            }
        });
    }

    $scope.doRefreshBillingStatement = function(){
        getBillingStatement();
        $scope.$broadcast('scroll.refreshComplete');
    }

    // Called each time the slide changes
    function slideChanged(index) {
        $scope.slideIndex = index;
        if ($scope.slideIndex == 1) {
            $scope.tab1 = '';
            $scope.tab2 = 'active';
            $rootScope.footerPaymentHistory = true;
            $rootScope.footerBillingStatement = false;
            analyticView('Billing Statement');
        } else {
            $scope.tab2 = '';
            $scope.tab1 = 'active';
            $rootScope.footerPaymentHistory = false;
            $rootScope.footerBillingStatement = true;
            analyticView('History Payment');
        }
    };

    function analyticView(analyticView) {
        // ----- Analytic Screen
        if (window.ga) {
            window.ga.trackView(analyticView);
            window.ga.trackEvent('Screen View', analyticView);
            console.log("Analytic - Screen View - " + analyticView);
        }
    }

    if ($rootScope.dataFilterPaymentHistory == undefined || $rootScope.dataFilterPaymentHistory == []) {
        $rootScope.dataFilterPaymentHistory = [];
    }

    function filterPaymentHistory() {
        $ionicModal.fromTemplateUrl('partials/tabs/billing/filterPaymentHistory.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $rootScope.modalFilterPaymentHistory = modalMenu;
            $rootScope.modalFilterPaymentHistory.show();
        });
    }

    function payNow() {
        $state.go('app.billing2');
    }

    function otherBilling() {
        var confirmPopup = $ionicPopup.confirm({
            title: $filter('translate')('confirmation'),
            template: $filter('translate')('dialog_pay_other_bill'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                $state.go('app.loginebilling');
            }
        });
    }

    function detailBillingStatement(site) {
        $scope.titleUnit = site['@attributes'].SiteName;
        $scope.siteID = site['@attributes'].SiteID;
        $scope.billingOutstanding = site['@attributes'].BillingOutstandingBalance;
        $scope.dataDetailBillingStatement = site.Periode;
        $scope.month = site.Periode[0]['@attributes'].Name;
        
        var i = 0;
        $scope.dataDetailBillingStatement.forEach(function (obj, idx) {
            $scope.dataDetailBillingStatement[idx].Unit.forEach(function (obj, idy) {
                $scope.dataDetailBillingStatement[idx].Unit[idy].id = i++;
                var btn_id = $scope.dataDetailBillingStatement[idx].Unit[idy].id;
                $scope['btn_unit_' + btn_id] = false;
                var bulan = $scope.dataDetailBillingStatement[idx]['@attributes'].Name;
                if(lang=='ina'){
                    bulan = bulan.replace("Januari", "JAN");
                    bulan = bulan.replace("Februari", "FEB");
                    bulan = bulan.replace("Maret", "MAR");
                    bulan = bulan.replace("April", "APR");
                    bulan = bulan.replace("Mei", "MEI");
                    bulan = bulan.replace("Juni", "JUN");
                    bulan = bulan.replace("Juli", "JUL");
                    bulan = bulan.replace("September", "AGU");
                    bulan = bulan.replace("Agustus", "SEP");
                    bulan = bulan.replace("Oktober", "OKT");
                    bulan = bulan.replace("November", "NOV");
                    bulan = bulan.replace("Desember", "DES");
                }else{
                    bulan = bulan.replace("Januari", "JAN");
                    bulan = bulan.replace("Februari", "FEB");
                    bulan = bulan.replace("Maret", "MAR");
                    bulan = bulan.replace("April", "APR");
                    bulan = bulan.replace("Mei", "MEI");
                    bulan = bulan.replace("Juni", "JUN");
                    bulan = bulan.replace("Juli", "JUL");
                    bulan = bulan.replace("September", "AUG");
                    bulan = bulan.replace("Agustus", "SEP");
                    bulan = bulan.replace("Oktober", "OCT");
                    bulan = bulan.replace("November", "NOV");
                    bulan = bulan.replace("Desember", "DEC");
                
                }
                $scope.dataDetailBillingStatement[idx]['@attributes'].NewName = bulan;
            });
        });

        // $scope.titleUnit = periode['Unit'][0]['@attributes'].UnitCode + " | " + periode['Unit'][0]['@attributes'].UnitNo;
        // if (periode.Unit.length > 1) {
        //     $scope.titleUnit = periode.Unit.length + " " + $filter('translate')('units');
        // }
        // $scope.dataDetailBillingStatement = periode.Unit;
        // $scope.paymentMonth = periode['@attributes'].Name;

        // $scope.dataDetailBillingStatement.forEach(function (obj, idx) {
        //     $scope.dataDetailBillingStatement[idx].id = idx;
        //     $scope['btn_unit_' + idx] = false;
        // });
        
        $ionicModal.fromTemplateUrl('partials/tabs/billing/detailBillingStatementModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.modalMenu = modalMenu;
            $scope.modalMenu.show();
        });
    }

    function closeModalDetailBilling() {
        $scope.modalMenu.remove();
    }

    function payNowBillingDetail(siteID) {
        closeModalDetailBilling();
        // $state.go('app.billing2');
        $state.go('app.detailPayment', { siteId: siteID });
    }

    $scope.varUnitDetails = function (id) {
        return $scope['btn_unit_' + id];
    }

    $scope.showHideUnitDetails = function (id) {
        $scope['btn_unit_' + id] = !$scope['btn_unit_' + id];
    }

    $scope.openDownloadModal = function() {
        $ionicModal.fromTemplateUrl('partials/tabs/billing/downloadModal.html', {
            scope: $scope
        }).then(function (downloadModal) {
            $scope.downloadModal = downloadModal;
            $scope.downloadModal.show();
        });    
    }

    $scope.closeDownloadModal = function() {
        $scope.downloadModal.remove();
    }

    
    $scope.dateselectStart = function(){
        $scope.startDateTemp = document.getElementById("fromFilter").value;
        $scope.startDate = $scope.startDateTemp;    
    }

    $scope.dateselectEnd = function(){
        $scope.endDateTemp = document.getElementById("toFilter").value;
          $scope.endDate = $scope.endDateTemp;
    }

    $scope.downloadTest = function(){
        billingServices.downloadList("",$scope.startDate,$scope.endDate,function(response){
            $window.open(response.url, '_system', 'location=no');
        });
    }

}
