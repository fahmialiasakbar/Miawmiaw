angular
    .module('livein')
    .controller('point', point)
    .controller('historyPoint', historyPoint)
    .controller('searchMyPoint', searchMyPoint)
    .controller('settingVoucher', settingVoucher)
    .controller('historyVoucher', historyVoucher);

function point($rootScope, $scope, $translate, $ionicHistory, $ionicLoading, $ionicModal, PointService, billingServices, $localStorage, $cordovaGeolocation, $cordovaSocialSharing, $state, ProfileService, $ionicPopup, $filter, $timeout) {
    $scope.searchPoint = searchPoint;
    $scope.redeemVoucher = redeemVoucher;
    $scope.redeemVoucherOvo = redeemVoucherOvo; 
    $scope.redeem = redeem;
    $scope.redeemOvo = redeemOvo;
    $scope.haveOutstandingModal = haveOutstandingModal;
    $scope.getPoints = getPoints;
    $scope.scanQRCodeNow = scanQRCodeNow;
    $scope.learnMoreGetPoint = learnMoreGetPoint;
    $scope.isFilter;
    $scope.isSort;
    $scope.voucher;
    $scope.title="";
    $scope.filter1 = false;
    $scope.filter2 = false; 
    $scope.filter3 = false;
    $scope.dataFilter = [];
    $scope.dataSort = [];
    $scope.fakelist=[1,2,3,4];
    $scope.sharefacebook = sharefacebook;
    $scope.sharetwitter = sharetwitter;
    $scope.gotPointModal = gotPointModal;
    $scope.calculatdistance = calculatdistance;
    $rootScope.searchMyVoucherVal = "";
    $scope.ovoId='';
    
    $scope.myGoBack = function(){
        $ionicHistory.goBack();
        // $state.go('app.profile');
        $rootScope.footerPoint = false;
        $rootScope.footerMyPoint = false;
    }

    function searchPoint(){
        // $ionicModal.fromTemplateUrl('partials/tabs/searchMyPoint.html', {
        //     scope: $scope
        // }).then(function (modalMenu) {
        //     $scope.searchMyPoint = modalMenu;
        //     $scope.searchMyPoint.show();
        // });
        $state.go("app.searchPoint")

    }
    

    $scope.closeModalSearch = function(){
        $scope.searchMyPoint.hide();
    }

    function redeemVoucher(item){
        
        $scope.data = {point: item.point, title: item.title, title_id: item.title_id}
        $rootScope.idvoucher = item.id;
        $scope.myPoint = $localStorage.currentPoint; 
        $scope.checkCanRedeem = function(){
            
            if($scope.myPoint>=item.point && $scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher(item.expired_date)){
                return true; 
            }
            return false;
        }

        $scope.checkPoint = function(){
            if($scope.myPoint>=item.point){
                return true; 
            }
            return false;
        }
        
        $scope.checkOutstanding = function(){
            if($scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher(item.expired_date)){
                return true; 
            }
            return false;
        }

        $ionicModal.fromTemplateUrl('partials/sides/redeemModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModal = modalMenu; 
            $scope.redeemModal.show();
        });
    }

    function redeemVoucherOvo(item){
        
        $scope.data = {point: item.point, title: item.title, title_id: item.title_id}
        $rootScope.idvoucher = item.id;
        $scope.myPoint = $localStorage.currentPoint; 
        $scope.checkCanRedeem = function(){

            if($scope.myPoint>=item.point && $scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher(item.expired_date)){
                return true; 
            }
            return false;
        }
        $scope.checkPoint = function(){
            if($scope.myPoint>=item.point){
                return true; 
            }
            return false;
        }
        $scope.checkOutstanding = function(){
            if($scope.billingOutstandingStatus == 0 && !$scope.checkExpiredVoucher(item.expired_date)){
                return true; 
            }
            return false;
        }

        $ionicModal.fromTemplateUrl('partials/tabs/profile/redeemModalOvo.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModalOvo = modalMenu; 
            $scope.redeemModalOvo.show();
        });
    }
    
    $scope.closeRedeemOvo = function(){
        $scope.redeemModalOvo.hide();
    }

    function redeem(){
        var type = 'regular';
        var idvoucher = $rootScope.idvoucher;
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.redeemVoucher(idvoucher, function (response){
            if(response){
                if(response.statusCode == 10){
                    $localStorage.currentPoint = response.mypoint;
                    $scope.userpoint = $localStorage.currentPoint;
                    $rootScope.successRedeem = true;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                } else {
                    $rootScope.successRedeem = false;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                }
            }else{
            }
        });
        
    } 

    function redeemOvo(ovoid){
        
        if(!$scope.checkOutstanding()){
            $scope.haveOutstandingModal();
        }
        else{
            $ionicLoading.show({ template: $filter('translate')('loading')+"..."});
            var type = 'ovo';
            var ovoid = ovoid;
            var idvoucher = $rootScope.idvoucher;
            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
            PointService.redeemVoucherOvo(idvoucher, ovoid, function (response){
                $ionicLoading.hide();
                if(response){
                    if(response.statusCode == 10){
                        $localStorage.currentPoint = response.mypoint;
                        $scope.userpoint = $localStorage.currentPoint;
                        $rootScope.successRedeem = true;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    } else {
                        $rootScope.successRedeem = false;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    }
                }else{
                }
            });
        }
        
        
    }
    
   function haveOutstandingModal(){
        if($scope.redeemModal){
            $scope.redeemModal.hide();
        }else if($scope.redeemModalOvo){
            $scope.redeemModalOvo.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/haveOutstandingModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.haveOutstanding = modalMenu; 
            $scope.haveOutstanding.show();
        });
    }

    $scope.closeHaveOutstanding = function(){
        $scope.haveOutstanding.hide();
    }

    $scope.goPayment = function(){
        $state.go('app.billing');
        $ionicHistory.nextViewOptions({
            disableBack: true
        });
    }

    function gotPointModal(){
        $scope.messageGetPointShareSocmed = $rootScope.msgGetPointShareSocmed;
        $scope.addPoint = $rootScope.additionalPoint;
        $scope.myPoint = $localStorage.currentPoint; 
        $ionicModal.fromTemplateUrl('partials/sides/gotPointModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.gotPointModal = modalMenu;
            $scope.gotPointModal.show();
        });
    }

    $scope.closeGotPointModal = function(){
        $scope.gotPointModal.hide();
    }

    $scope.closeRedeem = function(){
        $scope.redeemModal.hide();
    }
    
      function sharefacebook() {
            var scheme, urlStore;
            // Don't forget to add the cordova-plugin-device plugin for `device.platform`
            if (device.platform === 'iOS') {
                scheme = 'fb://';
                urlStore = 'https://itunes.apple.com/us/app/facebook/id284882215?mt=8';
            }
            else if (device.platform === 'Android') {
                scheme = 'com.facebook.katana';
                urlStore = 'https://play.google.com/store/apps/details?id=com.facebook.katana';
            } 
            
            appAvailability.check(
                scheme,
                function onSucces(result) {
                    shareEventToFB();
                },
                function onError(error) {
                    window.open(urlStore, '_system', 'location=no');
                    console.log('Facebook Not Installed');
                }
            );     
         }
        
        function shareEventToFB (){
            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
            if(lang == 'ina'){
                $scope.send = $rootScope.msgSuccessScanIna;      
            }else{
                $scope.send = $rootScope.msgSuccessScanEN;
            }
            var urlStore;
            if (device.platform === 'iOS') {
                urlStore = 'https://itunes.apple.com/us/app/lippo-cikarang/id1191438061?mt=8';
            }
            else if (device.platform === 'Android') {
                urlStore = 'https://play.google.com/store/apps/details?id=lippocikarang.com';
            } 

            if (device.platform === 'iOS') {
                window.plugins.socialsharing.shareViaFacebook($scope.send,
                    null,
                    urlStore,
                    console.log('share ok'), // success callback
                    function(errormsg){
                     if(errormsg=='cancelled')
                     {
                         $ionicLoading.show({ template: $filter('translate')('cancel_share_event'), noBackdrop: true, duration: 2000 });
                     }else{
                         $scope.shareModal.hide();
                         console.log("Success Share via Facebook");
                         $rootScope.shareVia = 'Facebook';
                         getRulesDetail();
                     }
    
                }); // error callback
            }else if (device.platform === 'Android') {
                window.plugins.socialsharing.shareViaFacebook($scope.send,
                    null,
                    urlStore,
                    function(errormsg){
                        if(errormsg=='cancelled')
                        {
                            $ionicLoading.show({ template: $filter('translate')('cancel_share_event'), noBackdrop: true, duration: 2000 });
                        }else{
                            $scope.shareModal.hide();
                            console.log("Success Share via Facebook");
                            $rootScope.shareVia = 'Facebook';
                            $timeout(function () {
                                getRulesDetail();
                            }, 2000);
                        }
                    },
                    console.log("Error")
                );
            }
        }

      function sharetwitter() {
        var scheme, urlStore;
        // Don't forget to add the cordova-plugin-device plugin for `device.platform`
        if (device.platform === 'iOS') {
            scheme = 'twitter://';
            urlStore = 'https://itunes.apple.com/us/app/twitter/id333903271?mt=8';
        }
        else if (device.platform === 'Android') {
            scheme = 'com.twitter.android';
            urlStore = 'https://play.google.com/store/apps/details?id=com.twitter.android';
        }
        
        appAvailability.check(
            scheme,
            function onSucces(result) {
                shareEventToTwitter();
            },
            function onError(error) {
                window.open(urlStore, '_system', 'location=no');
                console.log('Twitter Not Installed');
            }
        );      
      }

      function shareEventToTwitter(){
          
        var urlStore;
        if (device.platform === 'iOS') {
            urlStore = 'https://itunes.apple.com/us/app/lippo-cikarang/id1191438061?mt=8';
        }
        else if (device.platform === 'Android') {
            urlStore = 'https://play.google.com/store/apps/details?id=lippocikarang.com';
        }
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        if(lang == 'ina'){
            $scope.send = $rootScope.msgSuccessScanIna;      
        }else{
            $scope.send = $rootScope.msgSuccessScanEN;
        }

        if (device.platform === 'iOS') {
            window.plugins.socialsharing.shareViaTwitter($scope.send,
                null,
                urlStore,
                console.log('share ok'), // success callback
                function(errormsg){
                 if(errormsg=='cancelled')
                 {
                     $ionicLoading.show({ template: $filter('translate')('cancel_share_event'), noBackdrop: true, duration: 2000 });
                 }else{
                     $scope.shareModal.hide();
                     console.log("Success Share via Twitter");
                     $rootScope.shareVia = 'Twitter';
                     getRulesDetail();
                 }

            }); // error callback
        }else if (device.platform === 'Android') {
            window.plugins.socialsharing.shareViaTwitter($scope.send,
                null,
                urlStore,
                function(errormsg){
                    if(errormsg=='cancelled')
                    {
                        $ionicLoading.show({ template: $filter('translate')('cancel_share_event'), noBackdrop: true, duration: 2000 });
                    }else{
                        $scope.shareModal.hide();
                        console.log("Success Share via Twitter");
                        $rootScope.shareVia = 'Twitter';
                        getRulesDetail();
                    }
                },
                console.log("Error")
            );
        }

        
      } 

      function getRulesDetail(){
        // idRules = 1 => rules for share sosmed
        var idRules = 1;
        PointService.getRulesDetail(idRules, function (response){
            if(response){
                $scope.uniquecode = response.uniquecode;
                earnSharedPoints();
            }else{ 
                showModalSuccessScan({
                    statusCode : 500,
                    message : $filter('translate')('there_has_been_an_error_our_system'),
                    message_id : $filter('translate')('there_has_been_an_error_our_system'),
                    point: 0
                });
            }
        });
      }
      
      function earnSharedPoints(){
        var socmed = $rootScope.shareVia;  
        var idtenant = $rootScope.idtenant;
        var trxCode = $scope.uniquecode+'-'+$rootScope.trxCodeScanQR;
        var title = 'Share event ' + $rootScope.titleGetPoint + ' by ' + socmed;
        var title_id = 'Membagikan acara ' + $rootScope.titleGetPoint + ' dengan ' + socmed;
        PointService.earnPoints(trxCode, idtenant, title, title_id,function(response){
            $ionicLoading.hide();
            console.log("====== PointService.shareSocmed =====");
            console.log("trxCode : "+ trxCode+" idtenant "+ idtenant);
            console.log(response);
            console.log("===========");
            response['trxCode'] = trxCode;
            if(response){
                $rootScope.additionalPoint = response.point;
                $localStorage.currentPoint = response.mypoint;
                $scope.userpoint = $localStorage.currentPoint;
                $rootScope.msgGetPointShareSocmed = response.message;
                gotPointModal();
            }else{
                $rootScope.additionalPoint = 0;
                $scope.userpoint = $localStorage.currentPoint;
                $rootScope.msgGetPointShareSocmed = $filter('translate')('there_has_been_an_error_our_system');
                gotPointModal();
            }
        });
      }

    retrievegetaccount();
    function retrievegetaccount() {
        ProfileService.retrievegetaccount(
        function (response) {
            if (response != false) {
                var account = response.account;
                var arrayLength = account.length;
                for (var i = 0; i < arrayLength; i++) {
                    $scope.avatar = account[i].avatar;
                }
            } else {
                $scope.dataaccount = { name: $filter('translate')('failed_get_data') };
            }
        });
    }

    $scope.goRedeemSuccess = goRedeemSuccess;
    function goRedeemSuccess (type){
        $scope.successRedeem = $rootScope.successRedeem;
        $scope.messageRedeem = $rootScope.messageRedeem;
        var type = type;
        if(type=='ovo'){
            $scope.redeemModalOvo.hide();
        }else if(type=='regular'){
            $scope.redeemModal.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/redeemSuccessModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemSuccessModal = modalMenu;
            $scope.redeemSuccessModal.show();
        });
    }

    $scope.closeRedeemSuccess = function(){
        $scope.redeemSuccessModal.hide();
        getVoucher();
    }

    $scope.goPoint = function(){
        $scope.redeemSuccessModal.hide();
        getVoucher();
    }

    
    $scope.goMyVoucher = function(){
        $scope.redeemSuccessModal.hide();
        tabClickedFunc(2);
    }


    $scope.goOutstanding = function (){
        $ionicModal.fromTemplateUrl('partials/sides/outstandingModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.outstandingModal = modalMenu;
            $scope.outstandingModal.show();
        });
    }

    $scope.closeOutstanding = function(){
        $scope.outstandingModal.hide();
    }
 
    $scope.openShare = function(){
        $ionicModal.fromTemplateUrl('partials/tabs/profile/shareModal.html', {
            scope: $scope
        }).then(function (shareModal) {
            $scope.shareModal = shareModal;
            $scope.successScanModal.hide();
            $scope.shareModal.show();
        });
    }

    $scope.closeShare = function(){
        $scope.shareModal.hide();
    }

    $scope.availableSoon = function(){
        $ionicPopup.alert({
            template: $filter('translate')('soon'), 
            okText: $filter('translate')('okay'),
            cssClass: "alertPopup"
        });
    }
     
    function getMyPoints(){
        PointService.getMyPoint(function(response){
            if(response){
                if(response.statusCode ==  10){
                    $localStorage.currentPoint = response.mypoint;
                    $scope.userpoint = $localStorage.currentPoint;
                }
            }
        });
    }
    
    $scope.tab1 = false;
    $scope.tab2 = false;

    $scope.doRefresh = function () {
        getMyPoints();
        if($rootScope.footerMyPoint){
            tabClickedFunc(2);
        }else{ 
            tabClickedFunc(1);
        }
         
        $scope.$broadcast('scroll.refreshComplete');
    } 
     
    $scope.doRefresh();
    $scope.tabClicked = tabClickedFunc;
    function tabClickedFunc(tab) {
        $rootScope.resetFilter();
        $rootScope.resetSort();
        
        if (tab == 1) {
            $rootScope.isRedeemed = false;
            $rootScope.tab2=false;
            $scope.tab1 = true;
            $scope.tab2 = false;
            $rootScope.footerMyPoint = false;
            $rootScope.footerPoint = true;
            if (window.ga) {
                var analyticView = 'Explore Voucher';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Screen View', analyticView);
                console.log("Analytic - Screen View - " + analyticView);
            }
            getVoucher();
        } else if (tab == 2) {
            $rootScope.isRedeemed = true;
            $scope.tab1 = false;
            $scope.tab2 = true;
            $rootScope.footerMyPoint = true;
            $rootScope.footerPoint = false;
            if (window.ga) {
                var analyticView = 'My Voucher';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Screen View', analyticView);
                console.log("Analytic - Screen View - " + analyticView);
            }

            getMyVoucher("","","","","","","","","","");
        } 
    }

    function showHideFilter(id){
        if(id == 1){
            $scope.filter1 = !$scope.filter1;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 2){
            $scope.filter1 = false;
            $scope.filter2 = !$scope.filter2;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 3){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = !$scope.filter3;
            $scope.filter4 = false;
        } else if(id == 4){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = !$scope.filter4;
        }
    }

    if ($localStorage.currentUser) {
        $scope.fullname = $localStorage.currentUser.data[0].fullname;
    } 

    function getVoucher(){
        $scope.userpoint = $localStorage.currentPoint;
        var pagenumber = 1;
        PointService.listHomeVoucher(pagenumber, function(response){
            if (response) {
                $scope.otherVoucher = null;
                getAllVoucher(response.cats);
                getOtherVoucher(response.other);
                var i = 2;
                var a = 0;
                $scope.loadMoreVoucher = function () {
                    pagenumber = i;
                    PointService.listHomeVoucher(pagenumber, function(response){
                        if (response) {       
                            var getOther = response.other;
                            if(getOther){
                                for(var i=0; i<getOther.length; i++){
                                    if(getOther[i].length != 0){
                                        var loc = calculatdistance(getOther[i].tenant.latitude+","+ getOther[i].tenant.longitude);
                                        var worth = getFormattedWorth(getOther[i].worth);

                                        $scope.otherVoucher.push({
                                            available: getOther[i].available,
                                            created_date: getOther[i].created_date,
                                            expired_date: getOther[i].expired_date,
                                            id: getOther[i].id,
                                            image: getOther[i].image,
                                            point: getOther[i].point,
                                            latitude: getOther[i].latitude,
                                            longitude: getOther[i].longitude,
                                            tenant: {
                                                name: getOther[i].tenant.name,
                                                distance: loc
                                            },
                                            type: getOther[i].type,
                                            title: getOther[i].title,
                                            title_id: getOther[i].title_id,
                                            worth: worth,
                                        })
                                    }
                                }
                            }
                        }
                        else {
                        }
                    });
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    i++;

                    
                };
      
            }
        })
    }

    $scope.searchMyVoucher = function(searchMyVoucher){
        $rootScope.searchMyVoucherVal = searchMyVoucher;
        var pagenumber = 1;
        document.activeElement.blur();
        
        $rootScope.tabClickedMyVoucherFunc($rootScope.dataFilter.distance,
            $scope.lat, $scope.long,
            $rootScope.searchMyVoucherVal, $rootScope.dataSorting, pagenumber, $rootScope.dataFilter.point,
            $rootScope.dataFilter.dateFrom, $rootScope.dataFilter.dateTo, $rootScope.dataFilter.status);    
    }

    
    $rootScope.tabClickedMyVoucherFunc = getMyVoucher;
    if($localStorage.settingMyVoucher){
        if($localStorage.settingMyVoucher.isDeleted==true){
            PointService.deleteVoucher(function(response){
                if(response){
                    if(response.status==true){
                        console.log('Voucher Expired Deleted');
                        console.log(response.message);
                    }else{
                        console.log('Get Response False from Delete MyVouche');
                        console.log(response.message);
                    }
                }else{
                    console.log('No response, maybe error');
                }
            });
        }
    }

    function getMyVoucher(distance, currentlat, currentlong, keyword, sort, pagenumber, point,
        from, to, status ){
        $rootScope.myVoucherList = null;
        $scope.userpoint = $localStorage.currentPoint;
        pagenumber = 1;        
        PointService.getMyVoucher(
            distance,
            currentlat,
            currentlong,
            keyword,
            sort,
            pagenumber,
            point,
            from,
            to,
            status, 
            function(response){
                
            if (response) {
                if(response.status){ 
                    var i = 2; 
                    var a = 0;
                    $rootScope.myVoucherList = [];
                    response.data.forEach(function(item){
                        item['checkExpiredVoucher'] = $scope.checkExpiredVoucher(item.expired_date);
                        item['checkExpiringThisMonth'] = $scope.checkExpiringThisMonth(item.expired_date);
                        item['expired_date'] = $scope.strToDate(item.expired_date);

                        item['initial'] = initialName(localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina'? item.title_id : item.title);
                        item['color1'] = randomColor();
                        item['color2'] = randomColor();   
                        item['color3'] = randomColor();
                        $rootScope.myVoucherList.push(item);
                    });

                    $scope.loadMoreMyVoucher = function () {
                        pagenumber = i;
                        
                        PointService.getMyVoucher(
                            $rootScope.dataFilter.distance,
                            $scope.lat, $scope.long,
                            $rootScope.searchMyVoucherVal, $rootScope.dataSorting, pagenumber, $rootScope.dataFilter.point,
                            $rootScope.dataFilter.dateFrom, $rootScope.dataFilter.dateTo, $rootScope.dataFilter.status, function(response){
                            if (response) {
                                if(response.status){
                                    $rootScope.myVoucherList.concat(response.data);
                                }                               
                            }
                        });
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        i++;
                    };  
                }else{
                    $rootScope.myVoucherList = [];
                }
            }else{
                $rootScope.myVoucherList = [];
            }
        })
    }
    
    function getFormattedWorth(getWorth) {
        var worth = reverseString(getWorth.toString());
        var newWorth = '';
        for (var i = 0; i < worth.toString().length; i++) {
            if (newWorth.length % 4 == 0) {
                newWorth += '.';
            }
            newWorth += worth.toString().charAt(i);
        }
        var show = newWorth.slice(1);
        return reverseString(show);
    }

    function reverseString(str) {
        return str.split("").reverse().join("");
    }

    function getAllVoucher(voucher){
        $scope.allVoucher = []//voucher;        
        var loc
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        
        angular.forEach(voucher, function (obj) {
            var catVoucher = obj;
            for(var i=0; i<catVoucher.data.length; i++){
                worth = getFormattedWorth(catVoucher.data[i].worth);
                loc = calculatdistance(catVoucher.data[i].tenant.latitude+","+ catVoucher.data[i].tenant.longitude); 
                catVoucher.data[i]['distance'] = loc;
                catVoucher.data[i]['worth'] = worth;
                catVoucher.data[i]['type'] = catVoucher.data[i].type;
                catVoucher.data[i]['initial'] = initialName(localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina'? catVoucher.data[i].title_id : catVoucher.data[i].title);
                catVoucher.data[i]['color1'] = randomColor();
                catVoucher.data[i]['color2'] = randomColor();   
                catVoucher.data[i]['color3'] = randomColor();
            }
            $scope.allVoucher.push(catVoucher);
        });
    }

    function getOtherVoucher(voucher){
        $scope.otherVoucher = []//data;
        var data = [];
        
        angular.forEach(voucher, function (obj) {
            if(obj.length != 0){
                var loc = calculatdistance(obj.tenant.latitude+","+ obj.tenant.longitude);
                var worth = getFormattedWorth(obj.worth);
                $scope.otherVoucher.push({
                    available: obj.available,
                    created_date: obj.created_date,
                    expired_date: obj.expired_date,
                    id: obj.id,
                    image: obj.image,
                    point: obj.point,
                    type: obj.type,
                    tenant: {
                        name: obj.tenant.name,
                        distance: loc,
                        latitude: obj.tenant.latitude,
                        longitude: obj.tenant.longitude
                    },
                    title: obj.title,
                    title_id: obj.title_id,
                    worth: worth, 
                    initial: initialName(localStorage.getItem('NG_TRANSLATE_LANG_KEY') == 'ina'? obj.title_id : obj.title),
                    color1: randomColor(),
                    color2: randomColor(),
                    color3: randomColor(),
                })
            } 
        });
    }

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    function randomColor(){
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    function initialName(name){
        var initial = Array.prototype.map.call(name.split(" "), function (x) { return x.substring(0, 1).toUpperCase(); }).join('');
        return initial;
    }
    function calculatdistance (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);

            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
            var dLon = deg2rad($scope.long - longtenant);
            var a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

    getBillingOutstanding();

    function getBillingOutstanding(){  
        if($localStorage.currentUser){
            if($localStorage.currentUser.data){
                if($localStorage.currentUser.data[0]){
                    if($localStorage.currentUser.data[0].email){
                        var emailBilling =  $localStorage.currentUser.data[0].email;
                        requestGetBillingOutstanding(emailBilling);
                    }
                }
            }
        }
    }

    function requestGetBillingOutstanding(emailBilling){
        var site_id = $filter('translate')('siteidapps');
        
        $scope.billingOutstandingStatus = 1; // ada tagihan billing
        if(!$localStorage.billingOutstandingBalance){
            $localStorage.billingOutstandingBalance = 0;
        }
        billingServices.getbilling(emailBilling, site_id, function (response) {
            if (response != false) { 
                if(response.data){ 
                    if(response.data['@attributes']){
                        var attributes = response.data['@attributes'];
                        $localStorage.billingOutstandingBalance = attributes.BillingOutstandingBalance;
                        if (attributes.BillingOutstandingBalance == 0) {
                            $scope.billingOutstandingStatus = 0; // tidak ada tagihan billing
                        }             
                    } 
                }else{ 
                    $scope.billingOutstandingStatus = 2;  // data tagihan billing tidak ditemukan
                    $localStorage.billingOutstandingBalance = -1; // data tagihan billing tidak ditemukan
                }
            } else {
                console.log('else respon: ' + response);
            }
        });
    }

    function getPoints(){        
            $ionicModal.fromTemplateUrl('partials/sides/getPointsBarcodeModal.html', {
                scope: $scope
            }).then(function (modalMenu) {
                $scope.getPointsBarcodeModal = modalMenu;
                $scope.getPointsBarcodeModal.show();
            });
    } 
    
    $scope.closeGetPointsBarcodeModal = function(){ 
        $scope.getPointsBarcodeModal.hide();
    }

    function showModalSuccessScan(result){
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        $scope.isSuccessScan = false;

        $scope.msgResScan = result.message;
        if(lang == 'ina'){
            $scope.msgResScan = result.message_id ? result.message_id : result.message; 
        }

        if(result.statusCode == 40 || result.statusCode == 50 || result.statusCode == 60){
            if(lang=='ina'){
                $scope.msgResScan = $scope.msgResScan.replace("Rules", "Kode QR");
            }else{
                $scope.msgResScan = $scope.msgResScan.replace("Rules", "QR Code");
            }
        }
        
        if(result.statusCode == 10 || result.statusCode == 70){
            if(result.statusCode == 10){
                $localStorage.currentPoint = result.mypoint;
                $scope.userpoint = $localStorage.currentPoint;
            }

            $scope.isSuccessScan = true;     
            if(lang=='ina'){
                $scope.titleScan = result.title_id;
            }else{
                $scope.titleScan = result.title;
            }
            
            $scope.isLimited = false;

            var a = $scope.msgResScan.includes("limit");
            var b = $scope.msgResScan.includes("Limit");
            var c = $scope.msgResScan.includes("batas");
            var d = $scope.msgResScan.includes("Batas");
            var n = a||b||c||d;

            if(n){
                $scope.isLimited = true;
            }

            var langKey= localStorage.getItem('NG_TRANSLATE_LANG_KEY');
            $translate.use('ina');
            $rootScope.msgSuccessScanIna = $filter('translate')('msg_have_checkin') + " " + $scope.msgResScan;
            $translate.use('en');
            $rootScope.msgSuccessScanEN = $filter('translate')('msg_have_checkin') + " " + $scope.msgResScan;
            $rootScope.titleGetPoint = $scope.msgResScan;
            $translate.use(langKey);
            $rootScope.trxCodeScanQR = result.trxCode;

            if(result.statusCode == 10){
                $scope.msgResScan = $filter('translate')('msg_have_checkin')+ "<br><b>" + $scope.msgResScan+ "</b>";
            }else{
                $scope.msgResScan = $scope.msgResScan + "<br><b>'" + $scope.titleScan + "'</b>";
                // $scope.msgResScan = (lang == 'ina') ? result.message_id ? result.message_id : result.message : result.message + 
                //                 "<br> <b>" + $scope.msgResScan + "</b>";
            }
            
        }

        $ionicModal.fromTemplateUrl('partials/sides/successScanModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.successScanModal = modalMenu;
            $scope.successScanModal.show();
        });
    }

    $scope.closeSuccessScanModal = function(){
        $scope.successScanModal.hide();
    }

    function IsJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }
     
    function invalidQR(){
        showModalSuccessScan({
            statusCode : 500,
            message : $filter('translate')('qr_invalid'),
            message_id : $filter('translate')('qr_invalid'),
            point: 0
        });
    }

    function scanQRCodeNow(){
        $scope.closeGetPointsBarcodeModal();
        document.addEventListener("deviceready", function () {
            $ionicLoading.show({ template: $filter('translate')('loading') + "..."});

            try {
                cordova.plugins.barcodeScanner.scan(
                    function (result) {
                        $ionicLoading.hide();
                          if(result.cancelled==0){
                              if(!IsJsonString(result.text)){
                                var decryptResult = atob(result.text);
                                console.log("====== decryptResult =====");
                                console.log(decryptResult);
                                if(IsJsonString(decryptResult)){
                                    var resScan = JSON.parse(decryptResult);
                                    if(resScan.uniqueCode || resScan.tenant){
                                        if(!resScan.tenant) resScan.tenant = "";
                                        earnPointsScan(resScan.uniqueCode, resScan.tenant);
                                    }else{
                                        invalidQR();
                                    }
                                }else{
                                    invalidQR();
                                }
                              }else{
                                invalidQR();
                              }
                            }
                    },
                    function (error) {
                        $ionicLoading.hide();
                        console.log("==============================");
                        console.log("error! Barcode data is not here");
                        console.log(error);
                        console.log("==============================");
                        scanQRCodeNow();
                    },
                    { 
                        showTorchButton : true, // iOS and Android
                        formats : "QR_CODE",
                        orientation: "portrait",
                        prompt : $filter('translate')('barcode_scanner_info'), // Android
                        resultDisplayDuration: 0, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
                    }
                 );
                 $ionicLoading.hide();
            } catch(err) {
                $ionicLoading.hide();
                $ionicPopup.alert({
                    template: "We're sorry, there's something wrong on our system", 
                    okText: $filter('translate')('okay'),
                    cssClass: "alertPopup"
                });
                console.log(err.message);
            }
        }, false);
    }

    function earnPointsScan(trxCode, idtenant){
        $ionicLoading.show({ template: $filter('translate')('loading') + "..."});
        $rootScope.idtenant = idtenant;
        PointService.earnPoints(trxCode, idtenant, "", "",function(response){
            $ionicLoading.hide();

            console.log("====== PointService.earnPoints =====");
            console.log("trxCode : "+ trxCode+" idtenant "+ idtenant);
            console.log(response);
            console.log("===========");
            if(response){
                response['trxCode'] = trxCode;
                showModalSuccessScan(response);
            }else{
                showModalSuccessScan({
                    statusCode : 500,
                    message : $filter('translate')('there_has_been_an_error_our_system'),
                    message_id : $filter('translate')('there_has_been_an_error_our_system'),
                    point:0
             }); 
            }
        });
                  
    }

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm:ss').toDate();
        return dt;
    } 

    $scope.checkExpiredVoucher = function(dateExpired){
        var date = $scope.strToDate(dateExpired);
        if(date > new Date){
            return false;
        }        
        return true;
    }

    $scope.checkExpiringThisMonth = function(dateExpired){
        var date = $scope.strToDate(dateExpired);
        
        if(date.getMonth() == (new Date).getMonth()){
            return true;
        }        
        return false;
    }

    $scope.showHideLearnMore = function (id){
        $scope['btn_lm_'+id] = !$scope['btn_lm_'+id];
    }

    $scope.varLearnMore = function(id){
        return $scope['btn_lm_'+id];
    }

    function learnMoreGetPoint(){
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        
        $ionicLoading.show({ template: $filter('translate')('loading') + "..."});
        PointService.getActiveRules(function(response){
            $ionicLoading.hide();
            if(response){
                $scope.introRules = response.intro;  
                 if($scope.lang == 'ina') $scope.introRules = response.intro_id ? response.intro_id : response.intro;              
                $scope.activeRule = response.data;

                $scope.isReadMore = false;
                if($scope.introRules.length < 150){
                    $scope.isReadMore = true;
                }
                $scope.showReadMore = function(){
                    $scope.isReadMore = !$scope.isReadMore;
                }
                $scope.activeRule.forEach(function(val){
                    $scope['btn_lm_'+val.id] = false;
                }) 

                $ionicModal.fromTemplateUrl('partials/sides/learnMorePointsModal.html', {
                    scope: $scope
                }).then(function (modalMenu) {
                    $scope.learnMoreGetPointModal = modalMenu;
                    $scope.learnMoreGetPointModal.show();
                });
            }else{
                $scope.introRules = '';
            }
        });
    }
    
    $scope.closeLearnMoreGetPointModal = function(){
        $scope.learnMoreGetPointModal.hide();
    }

    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    } 

    $scope.useVoucher = function(item){
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        // $scope.availableSoon();
        $scope.usevoucher;
        console.log(item)
        if(item){
            $scope.voucher_title = $scope.lang == 'en' ? item.title : item.title_id;
            $scope.usevoucher = item;
            if(item.expired_date == null && item.expired_date == undefined && item.expired_date == ""){
                $scope.expireddateUseVoucher = "-";
            } else{
                $scope.expireddateUseVoucher = item.expired_date;
            }
        }
        
        $ionicModal.fromTemplateUrl('partials/tabs/profile/useMyVoucher.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.usevoucherModal = modalMenu; 
            $scope.usevoucherModal.show();
        });
    }

    $scope.closeUseVoucherModal = function(){
        $scope.isSuccessUseVoucher = false;
        $scope.usevoucherModal.hide();
    }

    $rootScope.tabDetail = false;
    $scope.howgetMerchant = function(item){
        $scope.closeUseVoucherModal();
        $rootScope.tabDetail = true;
        $scope.isSuccessUseVoucher = false;
        $state.go('app.voucherDetail', {id:item.id});
    }

    

    $scope.loadListMyVoucher = function(){ 
        $scope.successUseVoucherModal.hide();
        tabClickedFunc(2);
    }

    $scope.isSuccessUseVoucher = false;
    $scope.submitVoucher = function(activationcode, data){
        $scope.closeUseVoucherModal();
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.useVoucher(data.id, activationcode, function (response){
            if(response){
                if(response.statusCode == 10){
                    $scope.isSuccessUseVoucher = true;
                    $scope.dataVoucher = response;
                    if(response.date == null && response.date == undefined && response.date == ""){
                        $scope.dataVoucher.date = "-";
                        $scope.expireddateUseVoucher = "-";
                    } else{
                        $scope.dataVoucher.date = $scope.strToDate(response.date);
                        $scope.expireddateUseVoucher = data.expired_date;
                    }
                    $scope.msgUseVoucher = ($scope.lang=='ina') ? response.message_id : response.message;
                    goUseVoucherSuccess();
                } else {
                    $scope.isSuccessUseVoucher = false;
                    $scope.msgUseVoucher = ($scope.lang =='ina') ? response.message_id : response.message;
                    goUseVoucherSuccess();
                }
            }else{
            }
        });
    }

    function goUseVoucherSuccess(){
        $ionicModal.fromTemplateUrl('partials/tabs/profile/successUseVoucher.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.successUseVoucherModal = modalMenu; 
            $scope.successUseVoucherModal.show();
        });
    }

    $scope.closesuccessUseVoucherModal = function(){
        getMyVoucher("","","","","","","","","","");
        $scope.isSuccessUseVoucher = false;
        $scope.successUseVoucherModal.hide();
    }
}

function historyPoint($scope, PointService, $localStorage, $ionicHistory, $rootScope, $state){
    $scope.myGoBack = function () {
        $state.go('app.point');
    }; 

    
    $scope.strToDate = formattedDate;
    function formattedDate(getTime){
        var d = moment(getTime, 'YYYY-MMMM-DD HH:mm').toDate();
        
        var lang =  localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        if(lang=='ina'){
            var months = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
        }else{
            var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        }
        
        var minutes = d.getMinutes();
        if(minutes.toString().length==1){
            minutes = "0"+minutes;
        }else{
            minutes = minutes;
        }
        var hours = d.getHours();
        if(hours>=12){
            if(hours>=13){
                hours = hours-12;
            }
            var aOp = 'PM';
        }else{
            var aOp = 'AM';
        }

        if(hours.toString().length==1){
            hours = "0"+hours;
        }else{
            hours = hours;
        }
        var date = d.getDate();
        if(date.toString().length==1){
            date = "0"+date;
        }else{
            date = date;
        }
        var month = months[d.getMonth()];
        var c = d.getYear();
        var year = (c-100)+2000;
        
        return date+" "+month+" "+year+" "+hours+":"+minutes+" "+aOp;
        
    }

    $rootScope.footerPoint = false;
    $rootScope.footerMyPoint = false;
    $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
    
    $scope.history=[];

    var pagenumber=1;
    PointService.getHistoryPoint(pagenumber, function (response){
        if(response){
            $scope.data = response;
            $scope.history=[];
            a=0;
            angular.forEach($scope.data, function (obj) {
                var b = a++;
                var list = $scope.data;
                var data = list[b];
                var date = $scope.strToDate(data.date);

                $scope.history.push({
                    'title': data.title,
                    'title_id': data.title_id,
                    'type': data.type,
                    'point': data.point,
                    'worth': getFormattedWorth(data.worth),
                    'tenant': data.tenant,
                    'date': date
                });

            });

            var i = 2;
            $scope.loadMore = function () {
                pagenumber=i;
                PointService.getHistoryPoint(pagenumber, function (response) {
                    if (response) {
                        var a = 0;
                        $scope.data = response;
                        angular.forEach($scope.data, function (obj) {
                            var b = a++;
                            var list = $scope.data;
                            var data = list[b];
                            var date = $scope.strToDate(data.date);
            
                            $scope.history.push({
                                'title': data.title,
                                'title_id': data.title_id,
                                'type': data.type,
                                'point': data.point,
                                'worth': getFormattedWorth(data.worth),
                                'tenant': data.tenant,
                                'date': date
                            });
            
                        });
                    } else {
                        console.log('no more data loaded');

                    }
                });

                $scope.$broadcast('scroll.infiniteScrollComplete');
                i++;
            }
        }else{ 
            $scope.showText = true;
        }
    });

    if(history==''){
        $scope.showText = true;
    }

    function getFormattedWorth(getWorth) {
        var worth = reverseString(getWorth.toString());
        var newWorth = '';
        for (var i = 0; i < worth.toString().length; i++) {
            if (newWorth.length % 4 == 0) {
                newWorth += '.';
            }
            newWorth += worth.toString().charAt(i);
        }
        var show = newWorth.slice(1);
        return reverseString(show);
    }

    function reverseString(str) {
        return str.split("").reverse().join("");
    }
}

function historyVoucher($scope, $ionicHistory, $state, PointService, $cordovaGeolocation, $rootScope){
    $scope.fakelist = [1,2,3,4];
    $rootScope.searchHistoryVoucherVal = "";
    $scope.history=[];
    $rootScope.showButton = false;


    $scope.goBack = function(){
        $rootScope.showButton = true;
        $state.go('app.point');
    }
    $scope.strToDate = function(date){
        var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
        return dt;
    }

    $scope.keyword = '';
    getData('');
        
    if(history==''){
        $scope.showText = true;
    }

    $scope.searchHistoryVoucher = function(searchHistoryVoucherVal){
        getData(searchHistoryVoucherVal);
    }
    function getData(keyword){ 
        var pagenumber=1;
        PointService.getHistoryVoucher(pagenumber, keyword, function (response){
            if(response){
                $scope.data = response.data;
                $scope.history=[];
                angular.forEach(response.data, function (getVoucher) {
                    var used_date =  $scope.strToDate(getVoucher.used_date);
                    var letters = '0123456789ABCDEF';
                    var color1 = '#';
                    for (var i = 0; i < 6; i++) {
                        color1 += letters[Math.floor(Math.random() * 16)];
                    }
                    var color2 = '#';
                    for (var i = 0; i < 6; i++) {
                        color2 += letters[Math.floor(Math.random() * 16)];
                    }
                    var color3 = '#';
                    for (var i = 0; i < 6; i++) {
                        color3 += letters[Math.floor(Math.random() * 16)];
                    }
                    var initial = Array.prototype.map.call(getVoucher.title.split(" "), function (x) { return x.substring(0, 1).toUpperCase(); }).join('');
                    
    
                    $scope.history.push({
                        id: getVoucher.id,
                        title: getVoucher.title,
                        distance: calculatdistance(getVoucher.tenant.latitude+","+ getVoucher.tenant.longitude),
                        tenant:getVoucher.tenant,
                        point:getVoucher.point,
                        worth:getFormattedWorth(getVoucher.worth),
                        used_date:used_date,
                        redeemed_date:getVoucher.redeemed_date,
                        status:getVoucher.status,
                        expired_date:getVoucher.expired_date,
                        created_date:getVoucher.created_date,
                        title_id:getVoucher.title_id,
                        image:getVoucher.image,
                        initial:initial,
                        color1: color1,
                        color2: color2,
                        color3: color3,
                    });
    
                });
    
                var i = 2;
                $scope.loadMore = function () {
                    pagenumber=i;
                    PointService.getHistoryVoucher(pagenumber, keyword, function (response) {
                        if (response) {
                            $scope.data = response;
                            angular.forEach(response.data, function (getVoucher) {
                                var used_date =  $scope.strToDate(getVoucher.used_date);
                                var letters = '0123456789ABCDEF';
                                var color1 = '#';
                                for (var i = 0; i < 6; i++) {
                                    color1 += letters[Math.floor(Math.random() * 16)];
                                }
                                var color2 = '#';
                                for (var i = 0; i < 6; i++) {
                                    color2 += letters[Math.floor(Math.random() * 16)];
                                }
                                var color3 = '#';
                                for (var i = 0; i < 6; i++) {
                                    color3 += letters[Math.floor(Math.random() * 16)];
                                }
                                var initial = Array.prototype.map.call(getVoucher.title.split(" "), function (x) { return x.substring(0, 1).toUpperCase(); }).join('');
                                
    
    
                                $scope.history.push({
                                    id: getVoucher.id,
                                    title: getVoucher.title,
                                    distance: calculatdistance(getVoucher.tenant.latitude+","+ getVoucher.tenant.longitude),
                                    tenant:getVoucher.tenant,
                                    point:getVoucher.point,
                                    worth:getFormattedWorth(getVoucher.worth),
                                    used_date:used_date,
                                    redeemed_date:getVoucher.redeemed_date,
                                    status:getVoucher.status,
                                    expired_date:getVoucher.expired_date,
                                    created_date:getVoucher.created_date,
                                    title_id:getVoucher.title_id,
                                    image:getVoucher.image,
                                    initial:initial,
                                    color1: color1,
                                    color2: color2,
                                    color3: color3,
                                });
                
                            });
                        } else {
                            console.log('no more data loaded');
                            
                        }
                    });
    
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    i++;
                }
            }else{ 
                $scope.showText = true;
            }
        });
    
    }
    
    function getFormattedWorth(getWorth) {
        var worth = reverseString(getWorth.toString());
        var newWorth = '';
        for (var i = 0; i < worth.toString().length; i++) {
            if (newWorth.length % 4 == 0) {
                newWorth += '.';
            }
            newWorth += worth.toString().charAt(i);
        }
        var show = newWorth.slice(1);
        return reverseString(show);
    }

    function reverseString(str) {
        return str.split("").reverse().join("");
    }

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    var calculatdistance = function (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);

            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
            var dLon = deg2rad($scope.long - longtenant);
            var a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

}

function searchMyPoint($localStorage, $ionicLoading, $timeout, $filter, $rootScope, $ionicModal, $state, $scope, $ionicHistory, PointService, $cordovaGeolocation, $ionicModal){
    $rootScope.footerPoint = false;
    $scope.redeemOvo = redeemOvo;
    $scope.redeemVoucher = redeemVoucher;
    $scope.redeemVoucherOvo = redeemVoucherOvo;
    $scope.haveOutstandingModal = haveOutstandingModal;
    $scope.ovoId='';
    $scope.myGoBack = function(){
        // $ionicHistory.goBack();
        $state.go('app.point');
        $scope.listSearch = [];
        $scope.resetSearchPoint();
        $rootScope.search_point = '';
    }

    $scope.isFilter;
    $scope.isSort;
    $scope.title="";
    $scope.filter1 = false;
    $scope.filter2 = false;
    $scope.filter3 = false;
    $scope.dataFilter = [];
    $scope.dataSort = [];

    $scope.functSort = function (){
        $scope.closeModal();
        console.log($scope.dataSort)
    }

    $scope.functFilter = function (){
        $scope.closeModal();
    }

    $scope.showFilter = function (){
        $scope.isFilter = true;
        $scope.isSort = false;
        $scope.title="filter";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
        $scope.dataFilter.distance = 0;
    }
    
    function redeemVoucher(item){
        
        $scope.data = {point: item.point, title: item.title, title_id: item.title_id}
        $rootScope.idvoucher = item.id;
        $scope.myPoint = $localStorage.currentPoint; 
        $scope.checkCanRedeem = function(){
            
            if($scope.myPoint>=item.point && $scope.billingOutstandingStatus == 0){
                return true; 
            }
            return false;
        }
        $scope.checkOutstanding = function(){
            
            if($scope.billingOutstandingStatus == 0){
                return true; 
            }
            return false;
        }
        $scope.checkPoint = function(){
            
            if($scope.myPoint>=item.point){
                return true; 
            }
            return false;
        }
        $ionicModal.fromTemplateUrl('partials/sides/redeemModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModal = modalMenu; 
            $scope.redeemModal.show();
        });
    }

    function redeemVoucherOvo(item){   
        $scope.data = {point: item.point, title: item.title, title_id: item.title_id}
        $rootScope.idvoucher = item.id;
        $scope.myPoint = $localStorage.currentPoint; 
        $scope.checkCanRedeem = function(){

            if($scope.myPoint>=item.point && $scope.billingOutstandingStatus == 0){
                return true; 
            }
            return false;
        }
        $scope.checkOutstanding = function(){
            
            if($scope.billingOutstandingStatus == 0){
                return true; 
            }
            return false;
        }
        $ionicModal.fromTemplateUrl('partials/tabs/profile/redeemModalOvo.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemModalOvo = modalMenu; 
            $scope.redeemModalOvo.show();
        });
    }

    $scope.closeRedeem = function(){
        $scope.redeemModal.hide();
    }
    
    $scope.closeRedeemOvo = function(){
        $scope.redeemModalOvo.hide();
    }

    $scope.redeem = redeem;
    function redeem(){
        var type = 'regular';
        var idvoucher = $rootScope.idvoucher;
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        PointService.redeemVoucher(idvoucher, function (response){
            if(response){
                if(response.statusCode == 10){
                    $localStorage.currentPoint = response.mypoint;
                    $scope.userpoint = $localStorage.currentPoint;
                    $rootScope.successRedeem = true;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                } else {
                    $rootScope.successRedeem = false;
                    if(lang=='ina'){
                        $rootScope.messageRedeem = response.message_id;
                    }else{
                        $rootScope.messageRedeem = response.message;
                    }
                    goRedeemSuccess(type);
                }
            }else{
            }
        });
        
    }
    
    function redeemOvo(ovoid){
        if(!$scope.checkOutstanding()){
            haveOutstandingModal();
        }else{
            var type = 'ovo';
            var ovoid = ovoid;
            var idvoucher = $rootScope.idvoucher;
            var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
            PointService.redeemVoucherOvo(idvoucher, ovoid, function (response){
                $ionicLoading.hide();
                if(response){
                    if(response.statusCode == 10){
                        $localStorage.currentPoint = response.mypoint;
                        $scope.userpoint = $localStorage.currentPoint;
                        $rootScope.successRedeem = true;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    } else {
                        $rootScope.successRedeem = false;
                        if(lang=='ina'){
                            $rootScope.messageRedeem = response.message_id;
                        }else{
                            $rootScope.messageRedeem = response.message;
                        }
                        goRedeemSuccess(type);
                    }
                }else{
                }
            });
        }
    }

    function haveOutstandingModal(){
        if($scope.redeemModal){
            $scope.redeemModal.hide();
        }else if($scope.redeemModalOvo){
            $scope.redeemModalOvo.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/haveOutstandingModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.haveOutstanding = modalMenu; 
            $scope.haveOutstanding.show();
        });
    }

    $scope.closeHaveOutstanding = function(){
        $scope.haveOutstanding.hide();
    }

    $scope.goPayment = function(){
        $state.go('app.billing');
        $ionicHistory.nextViewOptions({
            disableBack: true
        });
    }

    $scope.goRedeemSuccess = goRedeemSuccess;
    function goRedeemSuccess (type){
        $scope.successRedeem = $rootScope.successRedeem;
        $scope.messageRedeem = $rootScope.messageRedeem;
        var type = type;
        if(type=='ovo'){
            $scope.redeemModalOvo.hide();
        }else if(type=='regular'){
            $scope.redeemModal.hide();
        }
        $ionicModal.fromTemplateUrl('partials/sides/redeemSuccessModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.redeemSuccessModal = modalMenu;
            $scope.redeemSuccessModal.show();
        });
    }

    $scope.closeRedeemSuccess = function(){
        $scope.redeemSuccessModal.hide();
        searchPoint($rootScope.search_point);
    }

    
    $scope.showSort = function (){
        $scope.isFilter = false;
        $scope.isSort = true;
        $scope.title="sort";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
    };

    $scope.showHideFilter = function(){
        $scope.isFilter = true;
        $scope.isSort = false;
        $scope.title="filter";
        $ionicModal.fromTemplateUrl('partials/tabs/profile/pointFilterSortModal.html', {
            scope: $scope
        }).then(function (modalMenu) {
            $scope.pointFilterSortModal = modalMenu;
            $scope.pointFilterSortModal.show();
        });
        $scope.dataFilter.distance = 0;
    };

    $scope.closeModal = function(){
        $scope.pointFilterSortModal.hide();
        $scope.isFilter = false;
        $scope.isSort = false;
        resetAcc();
        resetFilter();
        resetSort();
    }

    function resetAcc(){
        $scope.filter1 = false;
        $scope.filter2 = false;
        $scope.filter3 = false;
        $scope.filter4 = false;
    }
    $scope.resetFilter = resetFilter
    function resetFilter(){
        $scope.dataFilter = [];
        $scope.dataFilter.distance = 0;
    }

    $scope.resetSort = resetSort;
    function resetSort(){
        $scope.dataSort = [];
    }

    $scope.showHideFilter = function (id){
        if(id == 1){
            $scope.filter1 = !$scope.filter1;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 2){
            $scope.filter1 = false;
            $scope.filter2 = !$scope.filter2;
            $scope.filter3 = false;
            $scope.filter4 = false;
        } else if(id == 3){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = !$scope.filter3;
            $scope.filter4 = false;
        } else if(id == 4){
            $scope.filter1 = false;
            $scope.filter2 = false;
            $scope.filter3 = false;
            $scope.filter4 = !$scope.filter4;
        }
    }

    
    // $scope.resultSearch = false;
    // $scope.popular = true;
    // $scope.no_result = false
    if($rootScope.search_point){
        searchPoint($rootScope.search_point)
    }
    $rootScope.searchPoint = searchPoint
    function searchPoint(data){
        $ionicLoading.show({ template: $filter('translate')('loading') + "..."});
        var posOptions = { timeout: 10000, enableHighAccuracy: true };
        $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
            $scope.lat = position.coords.latitude;
            $scope.long = position.coords.longitude;
        });

        document.activeElement.blur();

        $scope.popular = false;
        $scope.suggestSearch = false;
        $rootScope.search_point = data;
        var id_category = 99;
        var pagenumber = 1;
        
        if($rootScope.dataFilter == undefined) $rootScope.dataFilter = []
        if($rootScope.dataSorting == undefined) $rootScope.dataSorting = ''
        if($rootScope.dataFilter.dateFrom == undefined) $rootScope.dataFilter.dateFrom = ''
        if($rootScope.dataFilter.dateTo == undefined) $rootScope.dataFilter.dateTo = ''
        if($rootScope.dataFilter.typr == undefined) $rootScope.dataFilter.type = ''
        if($rootScope.dataFilter.status == undefined) $rootScope.dataFilter.status = ''
        if($rootScope.dataFilter.mypoint == undefined) $rootScope.dataFilter.mypoint = ''
        if($rootScope.dataFilter.point == undefined) $rootScope.dataFilter.point = ''
        if($rootScope.dataFilter.distance == undefined) $rootScope.dataFilter.distance = ''
        if($rootScope.dataFilter.distance == 0 || $rootScope.dataFilter.distance == undefined || $rootScope.dataFilter.distance == ''){
            $scope.lat = ""
            $scope.long = ""
        }
        
        $scope.dateNow = function(){
            var dt = moment('YYYY-MM-DD HH:mm').toDate();
            return dt;
        }
        
    
        $scope.strToDate = function(date){
            var dt = moment(date, 'YYYY-MM-DD HH:mm').toDate();
            return dt;
        } 

        function getFormattedWorth(getWorth) {
            var worth = reverseString(getWorth.toString());
            var newWorth = '';
            for (var i = 0; i < worth.toString().length; i++) {
                if (newWorth.length % 4 == 0) {
                    newWorth += '.';
                }
                newWorth += worth.toString().charAt(i);
            }
            var show = newWorth.slice(1);
            return reverseString(show);
        }
    
        function reverseString(str) {
            return str.split("").reverse().join("");
        }
    
        

        $timeout(function(){
            // PointService.getVoucher(id_category,'','','','',data,$rootScope.dataSorting,pagenumber,'','','','',function(response){
                PointService.getVoucher(id_category,$rootScope.dataFilter.mypoint,$rootScope.dataFilter.distance,$scope.lat,$scope.long,data,$rootScope.dataSorting,pagenumber,$rootScope.dataFilter.point,$rootScope.dataFilter.dateFrom,$rootScope.dataFilter.dateTo,$rootScope.dataFilter.status,function(response){
                    if(response.length){
                        $scope.no_result = false
                        $scope.resultSearch = true;
                        $rootScope.footerPoint = true;
                        $scope.listSearch=[];
                        if (response) {       
                            var a=0;
                            angular.forEach(response, function(){
                                var b = a++;
                                var expired = $scope.strToDate(response[b].expired_date);
                                if(expired > new Date){
                                    var setatis = 'available';
                                    console.log(setatis);
                                }else{
                                    var setatis = 'expired';
                                    console.log(setatis);
                                }
                                dataLoadmore = [{
                                    id : response[b].id,
                                    title : response[b].title,
                                    tenant : response[b].tenant,
                                    point : response[b].point,
                                    available : response[b].available,
                                    type: response[b].type,
                                    status: setatis,
                                    expired_date : response[b].expired_date,
                                    created_date : response[b].created_date,
                                    worth : getFormattedWorth(response[b].worth),
                                    image : response[b].image,
                                    distanceSearch : calculatdistance(response[b].tenant.latitude+","+ response[b].tenant.longitude)
                                }];
                                $scope.listSearch = $scope.listSearch.concat(dataLoadmore);
                            })
                            
                        } else {
                            console.log('no more data loaded');
                            $ionicLoading.hide()
                        }
                        $ionicLoading.hide()
                        for(var i=0; i<response.length; i++){
                            $scope.distanceSearch = calculatdistance(response[i].tenant.latitude+","+ response[i].tenant.longitude);
                        }
        
                        if (window.ga) {
                            var analyticView = 'Search ' + data;
                            window.ga.trackView(analyticView);
                            window.ga.trackEvent("Screen View", analyticView);
                            if($rootScope.dataSorting != undefined && $rootScope.dataSorting != "") {
                                window.ga.trackEvent("Sorting", $rootScope.dataSorting, analyticView);
                                console.log("Analytic - Sorting - " + $rootScope.dataSorting +"-"+ analyticView);
                            }
                            if($rootScope.dataFilter.dateFrom != undefined && $rootScope.dataFilter.dateFrom != "" && $rootScope.dataFilter.dateTo != undefined && $rootScope.dataFilter.dateTo != "") {
                                window.ga.trackEvent("Filter Availability", $rootScope.dataFilter.dateFrom +" - "+$rootScope.dataFilter.dateTo, analyticView);
                                console.log("Analytic - Filter Availability - " + $rootScope.dataFilter.dateFrom +"-"+$rootScope.dataFilter.dateTo +"-"+ analyticView);
                            }
                            
                            if($rootScope.dataFilter.status != undefined && $rootScope.dataFilter.status != "") {
                                window.ga.trackEvent("Filter Voucher Status", $rootScope.dataFilter.status, analyticView);
                                console.log("Analytic - Filter Voucher Status - " + $rootScope.dataFilter.status +"-"+ analyticView);
                            }
                            if($rootScope.dataFilter.mypoint != undefined && $rootScope.dataFilter.mypoint != "") {
                                window.ga.trackEvent("Filter Current Point", $rootScope.dataFilter.mypoint, analyticView);
                                console.log("Analytic - Filter Current Point - " + $rootScope.dataFilter.mypoint +"-"+ analyticView);
                            }
                            if($rootScope.dataFilter.point != undefined && $rootScope.dataFilter.point != "") {
                                window.ga.trackEvent("Filter Point", $rootScope.dataFilter.point, analyticView);
                                console.log("Analytic - Filter Point - " + $rootScope.dataFilter.point +"-"+ analyticView);
                            }
                            if($rootScope.dataFilter.distance != undefined && $rootScope.dataFilter.distance != "") {
                                window.ga.trackEvent("Filter Distance", $rootScope.dataFilter.distance, analyticView);
                                console.log("Analytic - Filter Distance - " + $rootScope.dataFilter.distance +"-"+ analyticView);
                            }
                            console.log("Analytic - Screen View - " + analyticView);
                        }
        
                    var i = 2;
                    $scope.loadMore = function () {
                        pagenumber = i;
                        // PointService.getVoucher(id_category,'','','','',data,$rootScope.dataSorting,pagenumber,'','','','',function(response) {
                            PointService.getVoucher(id_category,$rootScope.dataFilter.mypoint,$rootScope.dataFilter.distance,$scope.lat,$scope.long,data,$rootScope.dataSorting,pagenumber,$rootScope.dataFilter.point,$rootScope.dataFilter.dateFrom,$rootScope.dataFilter.dateTo,$rootScope.dataFilter.status,function(response){
                            if (response) {       
                                var a=0;
                                angular.forEach(response, function(){
                                    var b = a++;
                                    var expired = $scope.strToDate(response[b].expired_date);
                                    if(expired>new Date){
                                        var setatis = 'available';
                                        console.log(setatis);
                                    }else{
                                        var setatis = 'expired';
                                        console.log(setatis);
                                    }
                                    dataLoadmore = [{
                                        id : response[b].id,
                                        title : response[b].title,
                                        tenant : response[b].tenant,
                                        point : response[b].point,
                                        available : response[b].available,
                                        type: response[b].type,
                                        status: setatis,
                                        expired_date : response[b].expired_date,
                                        created_date : response[b].created_date,
                                        worth : getFormattedWorth(response[b].worth),
                                        image : response[b].image,
                                        distanceSearch : calculatdistance(response[b].tenant.latitude+","+ response[b].tenant.longitude)
                                    }];
                                    $scope.listSearch = $scope.listSearch.concat(dataLoadmore);
                                })
                                
                            } else {
                                console.log('no more data loaded');
                                $ionicLoading.hide()
                            }
                        });
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        i++;
                    };
        
                    }else{
                        $scope.no_result = true
                        $scope.resultSearch = false;
                        $ionicLoading.hide()
                    }
                })
        }, 2000)
        
    }

    $scope.suggestSearch = false;
    $scope.suggest = function(data){
        $scope.search_point = data;
        $scope.popular = false;
        $scope.suggestSearch = true;
        if(document.getElementById("reset-btn")){
            document.getElementById("reset-btn").style.display="block";
        }
        $scope.no_result = false
        // var id_category = 99;
        // var pagenumber = 1
        // PointService.searchVoucher(id_category, pagenumber, data, function(response){
        //     $scope.listSuggest = response;
        // })
    }

    $rootScope.resetSearchPoint = resetSearchPoint;
    function resetSearchPoint (){
        document.getElementById("myform").reset();
        if(document.getElementById("reset-btn")){
            document.getElementById("reset-btn").style.display="none";
        }        
        $scope.resultSearch = false;
        $scope.popular = true;
        $scope.no_result = false;
        $rootScope.dataSort = [];
        $rootScope.dataFilter = [];
        $rootScope.dataSort.value = "";
        $rootScope.dataSorting = "";
        $rootScope.footerPoint = false;
        $rootScope.search_point = '';
    }

    

    var calculatdistance = function (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);
            if($scope.lat == ""){
                var posOptions = { timeout: 10000, enableHighAccuracy: true };
                $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
                    $scope.lat = position.coords.latitude;
                    $scope.long = position.coords.longitude;
                });
                
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
                var dLon = deg2rad($scope.long - longtenant);
                
                var a =
                    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2);
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                var d = R * c; // Distance in km
            }else{
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
                var dLon = deg2rad($scope.long - longtenant);
                
                var a =
                    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2);
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
                var d = R * c; // Distance in km
            }
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
}

function settingVoucher($scope, $state, $localStorage, $ionicHistory, $rootScope){
    $scope.myGoBack = function(){
        $rootScope.footerMyPoint=true;
        $state.go('app.point');
    }

    $rootScope.footerMyPoint=false;
    $rootScope.footerPoint=false;
    
    if(!$localStorage.settingMyVoucher){
        $localStorage.settingMyVoucher = {
            isReminder: false,
            isDeleted: false,
        }
    }

    $scope.isReminder = $localStorage.settingMyVoucher.isReminder;
    $scope.isDeleted = $localStorage.settingMyVoucher.isDeleted;

    $scope.settingDeleted = function(isDeleted){
        if(isDeleted){
            $scope.isDeleted = true;
            $localStorage.settingMyVoucher.isDeleted = true;
        }else{
            $scope.isDeleted = false;
            $localStorage.settingMyVoucher.isDeleted = false;
        }
    }
    
    $scope.settingReminder = function(isReminder){
        if(isReminder){
            $scope.isReminder = true;
            $localStorage.settingMyVoucher.isReminder = true;
        }else{
            $scope.isReminder = false;
            $localStorage.settingMyVoucher.isReminder = false;
        }
    }
    
}
