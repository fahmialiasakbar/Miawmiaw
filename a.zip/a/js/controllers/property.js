angular
    .module('livein')
    .controller('property', property)
    .controller('propertyDetail', propertyDetail)
    .controller('sendEmail', sendEmail)
    .controller('homeProperty', homeProperty);

function property($scope, $filter, $state, $stateParams, $rootScope, $window, PropertyService, $ionicLoading, $ionicPopup) {
    $scope.insertBookmarkProperty = insertBookmarkProperty;
    $scope.deleteBookmarkProperty = deleteBookmarkProperty;
    $scope.searchProperty = $stateParams.name;
    $scope.fake=[1,2,3];
    $scope.showSkeleton=true;
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Property' + $stateParams.name;
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    listProperty();
    $scope.searchval = $stateParams.searchval;
    $scope.propertyDetail = function (idproperty) {
        $state.go("app.propertyDetail", { idproperty: idproperty });
    }

    $scope.doRefresh = function () {
        listProperty();
        $scope.$broadcast('scroll.refreshComplete');
    }
    
    function listProperty() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
        $scope.data = [];

        var pagenumber = 1;
        PropertyService.listproperty($stateParams.status, pagenumber, function (response) {
            if (response != false) {
                for (i = 0; i < response.length; i++) {
                    var result = response[i];
                    var price = parseInt(result.price);
                    result.price = price;
                    $scope.data.push(result);
                }
                // $scope.data = response; 
                //
                var i = 2;
                $scope.loadMore = function () {
                    pagenumber = i;

                    PropertyService.listproperty($stateParams.status, pagenumber, function (response) {
                        if (response) {
                            $scope.data = $scope.data.concat(response);
                        } else {
                            console.log('no more data loaded');
                        }
                    });

                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    i++;
                };
                //

                $scope.favorites = false;
            } else {
                $scope.showSkeleton=false;
                $scope.data = [{ name: $filter('translate')('no_property') }];
            }
            $ionicLoading.hide();
        });

        PropertyService.propertycategory(function (response) {
            if (response != false) {
                $scope.category = response;
                $rootScope.categoryData = [];
                var a = 0;
                angular.forEach($scope.category, function () {
                    var b = a++;
                    var list = $scope.category;
                    var data = list[b];

                    var categoryname = data.categoryname;
                    var categoryKey = categoryname.toLowerCase('');
                    categoryKey = categoryKey.replace(/ +|&/g, '_');

                    $rootScope.categoryData.push({
                        'categoryValue': categoryname,
                        'categoryName': $filter('translate')(categoryKey)
                    });
                    //$scope.list = $filter('translate')(categoryname);                        
                });

            } else {
                $scope.category = [{ name: $filter('translate')('no_category') }];
            }
            $ionicLoading.hide();
        });
    };

    function insertBookmarkProperty(idproperty) {
        $ionicLoading.show({ template: $filter('translate')('post_bookmark_property_success'), duration: 5000 });
        PropertyService.insertBookmarkProperty(
            idproperty,
            function (response) {
                if (response != false) {

                    if (response[0].status == true) {
                        $ionicLoading.show({ template: $filter('translate')('success_favorite'), duration: 5000 });
                        listProperty();
                    } else {
                        $ionicLoading.show({ template: response[0].message, duration: 5000 });
                        listProperty();
                    }

                } else {
                    $ionicLoading.show({ template: $filter('translate')('failed_favorite'), duration: 5000 });
                    listProperty();
                }
            });
    };

    function deleteBookmarkProperty(idbookmark) {
        $ionicLoading.show({ template: $filter('translate')('delete_bookmark_property_success'), duration: 5000 });
        PropertyService.deleteBookmarkProperty(
            idbookmark,
            function (response) {
                if (response != false) {
                    $ionicLoading.show({ template: $filter('translate')('remove_favorite_success'), duration: 5000 });
                    listProperty();
                } else {
                    $ionicLoading.show({ template: $filter('translate')('remove_favorite_failed'), duration: 5000 });
                    listProperty();
                }
            });
    };
}

function propertyDetail($scope, $timeout, $stateParams, $ionicSlideBoxDelegate, $ionicHistory, PropertyService, $ionicLoading, $filter, $localStorage, $ionicModal, $ionicSlideBoxDelegate) {
    if ($localStorage.currentUser != null) {
        $scope.salah = true;
    } else {
        $scope.salah = false;
    }

    $ionicModal.fromTemplateUrl('partials/sides/propertyDetailImage.html', {
        scope: $scope
    }).then(function (modalImage) {
        $scope.modalImage = modalImage;
    });


    $scope.openModalImage = function (idproperty, index) {
        // $scope.idtenant = idtenant;
        $scope.modalImage.show();
        $scope.resultsImgGallery = [];
        angular.forEach($scope.resultsImg, function (obj, index) {
            obj['number'] = index + 1;
            $scope.resultsImgGallery.push(obj);
        });

        $scope.len = $scope.resultsImgGallery.length;

        $scope.activeSlideIdx = index;
        $ionicSlideBoxDelegate.update();
    }

    $scope.openModalImageAvatar = function (avatar) {
        $scope.modalImage.show();
        $scope.activeSlideIdx = 0;
        $scope.resultsImgGallery = [{
            image: avatar,
            number: 1,
            title: '',
        }];
        $scope.len = $scope.resultsImgGallery.length;
        
        $scope.next = function () {
            $ionicSlideBoxDelegate.next();
        };

        $scope.previous = function () {
            $ionicSlideBoxDelegate.previous();
        };

        $scope.slideChanged = function () {
            $ionicSlideBoxDelegate.update();
        };
    };

    

    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };

    $scope.closeModalImage = function () {
        $scope.modalImage.hide();
        $scope.activeSlideIdx = 0;
    }

    $scope.lalapo = function () {
        var getStatus = $ionicPopup.alert({
            template: $filter('translate')('blm_emailAgen'),
            okText: $filter('translate')('okay'),
            okType: "button-stable",
            cssClass: "alertPopup"
        });
    }

    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });

    $scope.next = next;
    $scope.previous = previous;
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    $scope.$on('$ionicView.beforeEnter', function (event, viewData) {
        viewData.enableBack = true;
    });

    PropertyService.retriveGetProperty(lang, $stateParams.idproperty, function (response) {

        $timeout(function () {
            if (response != false) {
                $ionicSlideBoxDelegate.update();
                $scope.roomlist = ['0', '0', '0', '0', '0', '0'];

                angular.forEach(response.detail, function (value, key) {
                    $scope.propertydata = value;
                });

                // ----- Analytic Screen
                if (window.ga) {
                    var analyticView = $scope.propertydata.name;
                    window.ga.trackView(analyticView);
                    window.ga.trackEvent('Property', analyticView);
                    console.log("Analytic - Property - " + analyticView);
                }

                var a = 0;
                angular.forEach(response.room, function (value, key) {
                    var b = a++;
                    var list = response.room;
                    var data = list[b];
                    var idproperty = data.idproperty;
                    var idroom = data.idroom
                    var name = data.name
                    var jumlah = data.jumlah

                    if (name == "bedroom") {
                        $scope.roomlist[0] = jumlah;
                    } else if (name == "bathroom") {
                        $scope.roomlist[1] = jumlah;
                    } else if (name == "garage") {
                        $scope.roomlist[2] = jumlah;
                    } else if (name == "kitchen") {
                        $scope.roomlist[3] = jumlah;
                    } else if (name == "diningroom") {
                        $scope.roomlist[4] = jumlah;
                    } else if (name == "livingroom") {
                        $scope.roomlist[5] = jumlah;
                    }
                });

                
                $scope.avatar = response.detail[0].avatar;

                var gall = $stateParams.index;
                $scope.gall = gall;

                if (!response.gallery) {
                    
                    $scope.gall = gall;
                    $scope.isEmptyImg = true;
                    $scope.resultsImg = [
                        { image: $scope.avatar ? $scope.avatar : "img/items/property_add_photo.png" },
                    ];
                } else {
                    $scope.isEmptyImg = false;
                    $scope.resultsImg = response.gallery;
                }


            } else {
                $scope.propertydata = [{ name: $filter('translate')('no_property') }];
                    $scope.isEmptyImg = true;
                    $scope.resultsImg = [
                        { image: $scope.avatar ? $scope.avatar : "img/items/property_add_photo.png" },
                    ];
            }
            $ionicLoading.hide();
        }, 1000);
    });
    $scope.slideChanged = function () {
        $ionicSlideBoxDelegate.update();
    };

    function next() {
        $ionicSlideBoxDelegate.next();
    };

    function previous() {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };
}

function sendEmail($scope, $state, $stateParams, $location, PropertyService, $ionicPopup, $ionicLoading, $ionicHistory, $filter, $localStorage) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Send Email Property';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    $scope.getRandomSpan = Math.floor((Math.random() * 14532));
    var memeSize = 200;
    var canvas = document.getElementById('memecanvas');
    ctx = canvas.getContext('2d');


    // Set the text style to that to which we are accustomed
    canvas.width = 250;
    canvas.height = 60;

    //  Grab the nodes
    var img = document.getElementById('start-image');
    var topText = document.getElementById('top-text');

    // When the image has loaded...
    img.onload = function () {
        drawMeme()
    }

    function drawMeme() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.drawImage(img, 0, 0, memeSize, memeSize);
        ctx.lineWidth = 4;
        ctx.font = '30pt sans-serif';
        ctx.strokeStyle = 'black';
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';

        var text1 = document.getElementById('top-text').value;
        text1 = text1.toUpperCase();
        x = memeSize / 2;
        y = 0;

        wrapText(ctx, text1, x, y, 200, 28, false);
    }

    function wrapText(context, text, x, y, maxWidth, lineHeight, fromBottom) {

        var pushMethod = (fromBottom) ? 'unshift' : 'push';

        lineHeight = (fromBottom) ? -lineHeight : lineHeight;

        var lines = [];
        var y = y;
        var line = '';
        var words = text.split(' ');

        for (var n = 0; n < words.length; n++) {
            var testLine = line + ' ' + words[n];
            var metrics = context.measureText(testLine);
            var testWidth = metrics.width;

            if (testWidth > maxWidth) {
                lines[pushMethod](line);
                line = words[n] + ' ';
            } else {
                line = testLine;
            }
        }
        lines[pushMethod](line);

        for (var k in lines) {
            //context.strokeText(lines[k], x, y + lineHeight * k);
            context.fillText(lines[k], x, y + lineHeight * k);
        }


    }

    console.log($stateParams.idproperty);
    var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');

    PropertyService.retriveGetProperty(lang, $stateParams.idproperty, function (response) {
        if (response != false) {
            console.log(response.detail)
            angular.forEach(response.detail, function (value, key) {
                $scope.propertydata = value;
                console.log($scope.propertydata);
            });
            // angular.forEach(response.detail, function(value, key) {
            //     $scope.propertydata = value;
            //     console.log('ini property data: '+$scope.propertydata)
            // });
 
        } else {
            $scope.propertydata = [{ name: $filter('translate')('no_property') }];
        }
        $ionicLoading.hide();
    });

    $scope.sending = function (email) {
        if(!email.desc){
            $ionicPopup.alert({
                template:  $filter('translate')('description') + " "+ $filter('translate')('not_empty'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });
            return false;
        }

        if (email.cap == $scope.getRandomSpan) {
            var bodyemail = '<div><p>' + email.desc + '</p></div>';
            if (bodyemail != "") {
                $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
                PropertyService.emailProperty(bodyemail,
                    function (response) {
                        if (response != false) {
                            var captchabenar = $ionicPopup.alert({
                                template: $filter('translate')('captcha_true'),
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });

                            captchabenar.then(function (res) {
                                if (res) {
                                    $state.go('app.propertyDetail', {idproperty: $stateParams.idproperty })
                                }
                            });
                        } else {
                            $ionicPopup.alert({
                                template: $filter('translate')('failed'),
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });
                        }
                        $ionicLoading.hide();
                    });
            }
        } else {
            $ionicPopup.alert({
                template: $filter('translate')('captcha_false'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup"
            });

        }
    };
}

function homeProperty() {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Property Start';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
};