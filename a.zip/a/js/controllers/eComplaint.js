angular
    .module('livein')
    .controller('eComplaint', eComplaint)
    .controller('eComplaintList', eComplaintList)
    .controller('eComplaintDetail', eComplaintDetail)
    .controller('eComplaintAdd', eComplaintAdd);

function eComplaint($ionicPlatform, $sce, $ionicModal, $window, $ionicSlideBoxDelegate, $localStorage, $rootScope, $scope, $state, eComplaintService, $ionicLoading, $ionicPopup, $timeout, $location, $cordovaFile, $cordovaFileTransfer, $cordovaFileOpener2, $filter) {
    $scope.fake=[1,2,3,4,5,6,7];
    $scope.dataList;
    
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'E-Complaint List';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    ionic.Platform.ready(function () {

        $scope.at = localStorage.getItem('at');
        eComplaintService.getToken(function (response) {
            if (response != false) {
                var at = response.access_token;
                var tt = response.token_type;
                localStorage.setItem('at', at);

                if (localStorage.getItem('at') != null) {
                    var pp = localStorage.getItem('at');
                    console.log('get at : ', pp);
                } else {
                    localStorage.setItem('at', at);
                    console.log('set item : ', at);
                    var pp = localStorage.getItem('at');
                    console.log(localStorage.getItem('at'));
                }

                localStorage.setItem('tt', tt);

            } else {
                eComplaintService.getToken(function (response) {
                    var at = response.access_token;
                    var tt = response.token_type;
                    localStorage.setItem('at', at);
                    localStorage.setItem('tt', tt);
                })
            }
        });

        // Open modal detail
        $ionicModal.fromTemplateUrl('partials/sides/eComplaintDetail.html', {
            scope: $scope
        }).then(function (modalDetail) {
            $scope.modalDetail = modalDetail;
        });

        $scope.openModalDetail = function (item) {
            eComplaintDetail(item.CaseNumber, item.HelpName);
            $scope.modalDetail.show();
        }

        $scope.closemodalDetail = function () {
            $scope.modalDetail.hide();
        }

        eComplaintList();
        function eComplaintList() {
            $scope.images = [];
            $scope.data = {};
            $scope.checking = false;

            //Tambahkan
            var at = localStorage.getItem('at');

            if (at != null) {
                $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
                eComplaintService.getUnit(at, function (response) {
                    if (response != false) {
                        $scope.pps = response.PsCode;
                        var pp = $scope.pps;
                        console.log(pp);

                        localStorage.setItem('pp', pp);
                        console.log('set pps : ', pp);

                        $scope.dataUnit = response;
                        $scope.unit = response.ListUnit;

                        $ionicLoading.hide();
                    } else {
                        $ionicLoading.hide();
                    }
                });
            } else {
                console.log('gabisa ambil local storage');
            }

            $scope.changedUnit = function () {
                var id = $scope.data.index;
                //$scope.data.concern = 0;
                if (id != null) {
                    var at = localStorage.getItem('at', JSON.stringify(at));
                    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
                    eComplaintService.getHelpname(at, id, function (response) {
                        if (response != false) {
                            $scope.nameDropDown = response.ListHelpName;
                        } else {
                            $ionicLoading.hide();
                        }
                    });
                    $ionicLoading.hide();
                }
            }
            $rootScope.detailDataList = [];
            $rootScope.allDataList = [];
            //getlistcase
            loadData();

            $scope.doRefresh = function () {
                loadData();
                console.log("refresh")
            }
            $scope.colorBorderCard = function (statusCase) {
                var border = null;
                if (statusCase == 'Assigned to PIC') {
                    border = { 'border-left-color': '#79d8ff' };
                } else if (statusCase == 'In Progress') {
                    border = { 'border-left-color': '#f29339' };
                } else if (statusCase == 'Progress Complete') {
                    border = { 'border-left-color': '#30d581' };
                } else if (statusCase == 'Cancelled') {
                    border = { 'border-left-color': '#e42112' };
                }
                return border;
            }

            function loadData() {
                $scope.dataList = [];
                $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

                eComplaintService.getListCase(at, function (response) {
                    if (response != false) {
                        $scope.list = response;
                        $scope.dataList = response.ListCase;
                        if ($scope.dataList) {
                            $scope.dataList.forEach(function (itemlist, indexlist, arrlist) {
                                $scope.dataList[indexlist].tanggal = new Date($scope.dataList[indexlist].CreatedOn).toISOString();
                            });
                            //console.log('Response : ',JSON.stringify($scope.dataList));
                            $rootScope.allDataList = $scope.dataList;

                            for (var i = 0; i < 5; i++) {
                                var item = $scope.dataList[i];
                                $rootScope.detailDataList = item;
                                console.log('ini rootScope data list detail : ', JSON.stringify($rootScope.detailDataList));
                            }
                        }
                        $ionicLoading.hide();
                    } else {
                        $ionicLoading.hide();
                    }
                    $scope.$broadcast('scroll.refreshComplete');
                });

            }

            function convertImgToBase64URL(url, callback, outputFormat) {
                var img = new Image();
                img.crossOrigin = 'Anonymous';
                img.onload = function () {
                    var canvas = document.createElement('CANVAS'),
                        ctx = canvas.getContext('2d'), dataURL;
                    canvas.height = this.height;
                    canvas.width = this.width;
                    ctx.drawImage(this, 0, 0);
                    dataURL = canvas.toDataURL(outputFormat);
                    callback(dataURL);
                    canvas = null;
                };
                img.src = url;
            }

            $scope.generals = 'active';

            // general tab & property tab
            var genTab = angular.element(document.querySelector('#generaltab'));
            var proTab = angular.element(document.querySelector('#propertytab'));
            genTab.addClass("active");

            $scope.general = function () {
                $ionicSlideBoxDelegate.previous();
                $scope.generals = 'active';
                $scope.propertys = '';
            };
            $scope.property = function () {
                $ionicSlideBoxDelegate.next();
                $scope.propertys = 'active';
                $scope.generals = '';
            };
            // Called each time the slide changes
            $scope.slideChanged = function (index) {
                $scope.slideIndex = index;
                if ($scope.slideIndex == 1) {
                    $scope.generals = '';
                    $scope.propertys = 'active';
                } else {
                    $scope.propertys = '';
                    $scope.generals = 'active';
                }
            };

        }

        function eComplaintDetail(caseNumber, title) {
            $scope.title = title;
            $scope.images = [];
            $scope.datanya = [];
            
            $scope.searchText = caseNumber;

            $scope.checking = false;
            //$scope.newCase = newCase;
            //Tambahkan

            var at = localStorage.getItem('at');
            if (at != null) {
                eComplaintService.getUnit(at, function (response) {
                    if (response != false) {

                        $scope.pps = response.PsCode;
                        var pp = $scope.pps;
                        localStorage.setItem('pp', pp);
                        console.log('haiiii : ', pp);

                        $scope.dataUnit = response;
                        $scope.unit = response.ListUnit;

                    } else {
                        console.log('haha kasian ');
                    }
                });
            } else {
                console.log('gabisa ambil local storage');
            }

            $scope.detail = [];
            //getlistcase
            eComplaintService.getListCase(at, function (response) {
                if (response != false) {

                    $scope.list = response;
                    $scope.dataList = response.ListCase;

                    $scope.dataList.forEach(function (itemlist, indexlist, arrlist) {
                        $scope.dataList[indexlist].tanggal = new Date($scope.dataList[indexlist].CreatedOn).toISOString();
                    });

                    $scope.dataImg = $sce.trustAsResourceUrl($scope.dataList[0].ListImage[0]);
                    $scope.dataImgg = $sce.trustAsResourceUrl($scope.dataList[0].ListImage[1]);
                    console.log('gambarnyaaa1: ', JSON.stringify($scope.dataImg));
                    console.log('gambarnyaaa2: ', JSON.stringify($scope.dataImgg));
                    /*if($scope.detail != null){
                        for (var i = 0; i < $scope.detail.length; i++) {
                            if($scope.detail[i].CaseNumber == $stateParams.CaseNumber){
                                $scope.detailList = $scope.detail[i];

                                var canvas = document.getElementById("c");
                                var ctx = canvas.getContext("2d");

                                var image = new Image();
                                image.onload = function() {
                                    ctx.drawImage(image, 0, 0);
                                };
                                image.src = $scope.detailList.ListImage[0];
                            } else {
                                console.log('gak podo');
                            }
                        }
                    } else {
                        console.log('scope.detail is null')
                    }*/

                } else {
                    console.log('huft kasian ', response);
                }
            });
            $scope.listCaseHistory = [];
            eComplaintService.getCaseHistory(caseNumber, function (response) {
                if (response != false) {
                    $scope.listCaseHistory = response.ListCaseHistory;
                    $scope.listCaseHistory.forEach(function (itemlist, indexlist, arrlist) {
                        $scope.listCaseHistory[indexlist].ModifiedDate = new Date($scope.listCaseHistory[indexlist].ModifiedDate).toISOString();
                    });
                } 
            });

            $scope.generals = 'active';

            // general tab & property tab
            var genTab = angular.element(document.querySelector('#generaltab'));
            var proTab = angular.element(document.querySelector('#propertytab'));
            genTab.addClass("active");

            $scope.general = function () {
                $ionicSlideBoxDelegate.previous();
                $scope.generals = 'active';
                $scope.propertys = '';
            };
            $scope.property = function () {
                $ionicSlideBoxDelegate.next();
                $scope.propertys = 'active';
                $scope.generals = '';
            };
            // Called each time the slide changes
            $scope.slideChanged = function (index) {
                $scope.slideIndex = index;
                if ($scope.slideIndex == 1) {
                    $scope.generals = '';
                    $scope.propertys = 'active';
                } else {
                    $scope.propertys = '';
                    $scope.generals = 'active';
                }
            };
        }
    });
};

function eComplaintList($ionicSlideBoxDelegate, $rootScope, $localStorage, $scope, $state, eComplaintService, $ionicLoading, $ionicPlatform, $ionicPopup, $timeout, $location, $cordovaFileOpener2, $filter, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice, $cordovaActionSheet, $window, $cordovaImagePicker, $ionicModal) {
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'E-Complaint List';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    if (!$localStorage.currentUser) {
        return false;
    }
    $scope.images = [];
    $scope.data = {};
    $scope.checking = false;

    //Tambahkan
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    var at = localStorage.getItem('at');

    if (at != null) {
        eComplaintService.getUnit(at, function (response) {
            if (response != false) {
                $scope.pps = response.PsCode;
                var pp = $scope.pps;
                console.log(pp);

                localStorage.setItem('pp', pp);
                console.log('set pps : ', pp);

                $scope.dataUnit = response;
                $scope.unit = response.ListUnit;

                $ionicLoading.hide();
            } else {
                console.log('haha kasian ');
                $ionicLoading.hide();
            }
        });
    } else {
        console.log('gabisa ambil local storage');
        $ionicLoading.hide();
    }

    $scope.changedUnit = function () {
        var id = $scope.data.index;
        //$scope.data.concern = 0;
        if (id != null) {
            var at = localStorage.getItem('at', JSON.stringify(at));
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            eComplaintService.getHelpname(at, id, function (response) {
                if (response != false) {
                    $scope.nameDropDown = response.ListHelpName;
                } else {
                    console.log('huft');
                }
            });
            $ionicLoading.hide();
        }
    }
    $rootScope.detailDataList = [];
    $rootScope.allDataList = [];
    //getlistcase
    loadData();

    $scope.doRefresh = function () {
        loadData();
    }

    function loadData() {
        $scope.dataList = [];

        eComplaintService.getListCase(at, function (response) {
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            if (response != false) {
                $scope.list = response;
                $scope.dataList = response.ListCase;
                $scope.dataList.forEach(function (itemlist, indexlist, arrlist) {
                    $scope.dataList[indexlist].tanggal = new Date($scope.dataList[indexlist].CreatedOn).toISOString();
                });
                //console.log('Response : ',JSON.stringify($scope.dataList));
                $rootScope.allDataList = $scope.dataList;

                for (var i = 0; i < 5; i++) {
                    var item = $scope.dataList[i];
                    $rootScope.detailDataList = item;
                    console.log('ini rootScope data list detail : ', JSON.stringify($rootScope.detailDataList));
                }
            } else {
                console.log('huft kasian ', response);
            }
            $ionicLoading.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });

    }

    function convertImgToBase64URL(url, callback, outputFormat) {
        var img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = function () {
            var canvas = document.createElement('CANVAS'),
                ctx = canvas.getContext('2d'), dataURL;
            canvas.height = this.height;
            canvas.width = this.width;
            ctx.drawImage(this, 0, 0);
            dataURL = canvas.toDataURL(outputFormat);
            callback(dataURL);
            canvas = null;
        };
        img.src = url;
    }

    $scope.generals = 'active';

    // general tab & property tab
    var genTab = angular.element(document.querySelector('#generaltab'));
    var proTab = angular.element(document.querySelector('#propertytab'));
    genTab.addClass("active");

    $scope.general = function () {
        $ionicSlideBoxDelegate.previous();
        $scope.generals = 'active';
        $scope.propertys = '';
    };
    $scope.property = function () {
        $ionicSlideBoxDelegate.next();
        $scope.propertys = 'active';
        $scope.generals = '';
    };
    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
        if ($scope.slideIndex == 1) {
            $scope.generals = '';
            $scope.propertys = 'active';
        } else {
            $scope.propertys = '';
            $scope.generals = 'active';
        }
    };

};

function eComplaintDetail($sce, $ionicSlideBoxDelegate, $stateParams, $rootScope, $localStorage, $scope, $state, eComplaintService, $ionicLoading, $ionicPlatform, $ionicPopup, $timeout, $location, $cordovaFileOpener2, $filter, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice, $cordovaActionSheet, $window, $cordovaImagePicker) {
    // console.log('ini 5 data : ', JSON.stringify($rootScope.detailDataList));
    // console.log('ini semua data : ', JSON.stringify($rootScope.allDataList));
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'E-Complaint Detail';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    $scope.title = $stateParams.CaseNumber;
    $scope.images = [];
    $scope.datanya = [];

    $scope.searchText = $stateParams.CaseNumber;

    $scope.checking = false;
    //$scope.newCase = newCase;
    //Tambahkan

    var at = localStorage.getItem('at');
    if (at != null) {
        eComplaintService.getUnit(at, function (response) {
            if (response != false) {

                $scope.pps = response.PsCode;
                var pp = $scope.pps;
                localStorage.setItem('pp', pp);
                console.log('haiiii : ', pp);

                $scope.dataUnit = response;
                $scope.unit = response.ListUnit;

            } else {
                console.log('haha kasian ');
            }
        });
    } else {
        console.log('gabisa ambil local storage');
    }

    $scope.detail = [];
    //getlistcase
    eComplaintService.getListCase(at, function (response) {
        if (response != false) {

            $scope.list = response;
            $scope.dataList = response.ListCase;

            $scope.dataList.forEach(function (itemlist, indexlist, arrlist) {
                $scope.dataList[indexlist].tanggal = new Date($scope.dataList[indexlist].CreatedOn).toISOString();
            });

            $scope.dataImg = $sce.trustAsResourceUrl($scope.dataList[0].ListImage[0]);
            $scope.dataImgg = $sce.trustAsResourceUrl($scope.dataList[0].ListImage[1]);
            console.log('gambarnyaaa1: ', JSON.stringify($scope.dataImg));
            console.log('gambarnyaaa2: ', JSON.stringify($scope.dataImgg));
            /*if($scope.detail != null){
                for (var i = 0; i < $scope.detail.length; i++) {
                    if($scope.detail[i].CaseNumber == $stateParams.CaseNumber){
                        $scope.detailList = $scope.detail[i];

                        var canvas = document.getElementById("c");
                        var ctx = canvas.getContext("2d");

                        var image = new Image();
                        image.onload = function() {
                            ctx.drawImage(image, 0, 0);
                        };
                        image.src = $scope.detailList.ListImage[0];
                    } else {
                        console.log('gak podo');
                    }
                }
            } else {
                console.log('scope.detail is null')
            }*/

        } else {
            console.log('huft kasian ', response);
        }
    });

    $scope.generals = 'active';

    // general tab & property tab
    var genTab = angular.element(document.querySelector('#generaltab'));
    var proTab = angular.element(document.querySelector('#propertytab'));
    genTab.addClass("active");

    $scope.general = function () {
        $ionicSlideBoxDelegate.previous();
        $scope.generals = 'active';
        $scope.propertys = '';
    };
    $scope.property = function () {
        $ionicSlideBoxDelegate.next();
        $scope.propertys = 'active';
        $scope.generals = '';
    };
    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
        if ($scope.slideIndex == 1) {
            $scope.generals = '';
            $scope.propertys = 'active';
        } else {
            $scope.propertys = '';
            $scope.generals = 'active';
        }
    };

};


function eComplaintAdd($ionicSlideBoxDelegate, $rootScope, $localStorage, $scope, $state, eComplaintService, $ionicLoading, $ionicPlatform, $ionicPopup, $timeout, $location, $cordovaFileOpener2, $filter, $cordovaCamera, $cordovaFile, $cordovaFileTransfer, $cordovaDevice, $cordovaActionSheet, $window, $cordovaImagePicker, $ionicModal) {
    $scope.images = [];
    $scope.data = {};
    $scope.checking = false;
    //$scope.newCase = newCase;

    $ionicModal.fromTemplateUrl('partials/sides/imageComplaintModal.html', {
        scope: $scope
    }).then(function (modalImage) {
        $scope.modalImage = modalImage;
    });
 
    $scope.openModalImage = function () {
        if($scope.images.length == 2){
            var alertPopup = $ionicPopup.alert({
                template: $filter('translate')('max_image'),
                okText: $filter('translate')('okay'),
                okType: "button-stable",
                cssClass: "alertPopup2"
            });
        }else{  
            $scope.modalImage.show();
        }
    }

    $scope.closeModalImage = function () {
        $scope.modalImage.hide();
    }

    
    $ionicModal.fromTemplateUrl('partials/sides/eComplaintImageModal.html', {
        scope: $scope
    }).then(function (imageModal) {
        $scope.imageModal = imageModal;
    });

    $scope.imageModalOpen = function(data){
        $scope.url="data:image/png;base64,"+data;
        $scope.imageModal.show();
    }
    $scope.imageModalClose = function(){
        $scope.imageModal.hide();
    }

    //Tambahkan
    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
    var at = localStorage.getItem('at');

    if (at != null) {
        eComplaintService.getUnit(at, function (response) {
            if (response != false) {
                $scope.pps = response.PsCode;
                var pp = $scope.pps;
                console.log(pp);

                localStorage.setItem('pp', pp);
                console.log('set pps : ', pp);

                $scope.dataUnit = response;
                $scope.unit = response.ListUnit;

            } else {
                console.log('haha kasian ');
            }
        });
    } else {
        console.log('gabisa ambil local storage');
    }
    $ionicLoading.hide();

    $scope.newCase = function (data, at) {
        var confirmPopup = $ionicPopup.confirm({
            template: $filter('translate')('newCase'),
            okText: $filter('translate')('yes'),
            cancelText: $filter('translate')('no'),
            okType: "button-stable"
        });

        confirmPopup.then(function (res) {
            if (res) {
                var at = localStorage.getItem('at');
                console.log('isole : ', $localStorage.pp);
                var pp = localStorage.getItem('pp');
                var email = $localStorage.currentUser.data[0].email;
                var fullname = $localStorage.currentUser.data[0].fullname;
                var phone = $localStorage.currentUser.data[0].phone;
                var unit = $scope.unit[0].IdDropDown;
                var concern = $scope.data.concern;
                //var pps = $scope.pps;
                var linkImg = $scope.images;

                if (data.description == '_' || data.description == undefined) {
                    var alertPopup = $ionicPopup.alert({
                        template: $filter('translate')('desc_empty'),
                        okText: $filter('translate')('okay'),
                        okType: "button-stable",
                        cssClass: "alertPopup2"
                    });
                } else if (unit == null) {
                    var alertPopup = $ionicPopup.alert({
                        template: $filter('translate')('unit_empty'),
                        okText: $filter('translate')('okay'),
                        okType: "button-stable",
                        cssClass: "alertPopup2"
                    });
                } else if (concern == null) {
                    var alertPopup = $ionicPopup.alert({
                        template: $filter('translate')('concern_empty'),
                        okText: $filter('translate')('okay'),
                        okType: "button-stable",
                        cssClass: "alertPopup2"
                    });
                } else {
                    $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
                    eComplaintService.insertCase(
                        at,
                        pp,
                        email,
                        fullname,
                        phone,
                        unit,
                        concern,
                        data.description,
                        linkImg,
                        function (response) {
                            var responseReason = response.ResponseReason;
                            if (response != false) {
                                $ionicLoading.hide();

                            var messageRes = $filter('translate')('e_success');
                                if(response.ResponseCode != 0){
                                    messageRes = $filter('translate')('e_failed');
                                    insertError(email, responseReason);
                                }

                                var alertPopup = $ionicPopup.alert({
                                    title: 'eComplaint',
                                    template: messageRes,
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });

                                alertPopup.then(function (res) {
                                    // $state.go($state.current);
                                    // $window.location.reload();
                                    $scope.images = [];
                                    $scope.data = {};
                                    $state.go('app.eComplaint');
                                });
                            } else {
                                $ionicLoading.hide();
                                var alertPopup = $ionicPopup.alert({
                                    title: 'eComplaint',
                                    template: $filter('translate')('e_failed'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });

                                alertPopup.then(function (res) {
                                    insertError(email, responseReason);
                                });
                            }
                        });
                    // ----- Analytic Screen
                    if (window.ga) {
                        var analyticView = 'Post E-Complaint';
                        window.ga.trackView(analyticView);
                        window.ga.trackEvent('Screen View', analyticView);
                        console.log("Analytic - Screen View - " + analyticView);
                    }
                }
            }
        });
    }

    function insertError(email, message) {
        var place = "eComplaint";
        eComplaintService.insertError(email, place, message, function (response) {
            if (response != false) {
                console.log("sukses insert error");
            } else {
                console.log("njaayyy");
            }
        });
    }

    $scope.changedUnit = function () {
        var id = $scope.data.index;
        //$scope.data.concern = 0;
        if (id != null) {
            var at = localStorage.getItem('at', JSON.stringify(at));
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            eComplaintService.getHelpname(at, id, function (response) {
                if (response != false) {
                    $scope.nameDropDown = response.ListHelpName;
                    
                } else {
                    console.log('huft');
                }
            });
            $ionicLoading.hide();
        }
    }
    $rootScope.detailDataList = [];
    $rootScope.allDataList = [];
    //getlistcase
    loadData();

    $scope.doRefresh = function () {
        loadData();
    }

    function loadData() {
        $scope.dataList = [];

        eComplaintService.getListCase(at, function (response) {
            $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
            if (response != false) {
                $scope.list = response;
                $scope.dataList = response.ListCase;
                if (response.ListCase == null) {
                    $ionicLoading.hide();
                    return;
                }
                $scope.dataList.forEach(function (itemlist, indexlist, arrlist) {
                    $scope.dataList[indexlist].tanggal = new Date($scope.dataList[indexlist].CreatedOn).toISOString();
                });
                //console.log('Response : ',JSON.stringify($scope.dataList));
                $rootScope.allDataList = $scope.dataList;

                for (var i = 0; i < 5; i++) {
                    var item = $scope.dataList[i];
                    $rootScope.detailDataList = item;
                    console.log('ini rootScope data list detail : ', JSON.stringify($rootScope.detailDataList));
                }
            } else {
                console.log('huft kasian ', response);
            }
            $ionicLoading.hide();
            $scope.$broadcast('scroll.refreshComplete');
        });

    }

    function convertImgToBase64URL(url, callback, outputFormat) {
        var img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = function () {
            var canvas = document.createElement('CANVAS'),
                ctx = canvas.getContext('2d'), dataURL;
            canvas.height = this.height;
            canvas.width = this.width;
            ctx.drawImage(this, 0, 0);
            dataURL = canvas.toDataURL(outputFormat);
            callback(dataURL);
            canvas = null;
        };
        img.src = url;
    }

    // from gallery
    $scope.Pick = function () {
        var options = {
            maximumImagesCount: 1,
            width: 500,
            height: 500,
            quality: 50
        };
        var sizeImg = [];
        var date = new Date();
        var year = date.getFullYear();
        var month = ('0' + date.getMonth()).slice(-2);
        var day = ('0' + date.getDate()).slice(-2);

        var hours = ('0' + date.getHours()).slice(-2);
        var minutes = ('0' + date.getMinutes()).slice(-2);
        var seconds = ('0' + date.getSeconds()).slice(-2);
        var tgl = year+''+''+month+''+''+day;
        var waktu = hours+''+''+minutes+''+''+seconds;

        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        $cordovaImagePicker.getPictures(options)
            .then(function (results) {
                for (var i = 0; i < results.length; i++) {
                    // if (results[i].length <= 15000) {                        
                    window.resolveLocalFileSystemURI(results[i],
                        function (fileEntry) {
                            // convert to Base64 string

                            fileEntry.file(
                                function (file) {
                                    //got file
                                    var reader = new FileReader();
                                    reader.onload = function (evt) {
                                        var imgData = evt.target.result;
                                        var dataIni = btoa(imgData); // this is your Base64 string
                                        sizeImg.push(imgData.length);
                                        $scope.sum = sizeImg.reduce(add, 0);
                                        $rootScope.total = $scope.sum;
                                        
                                        // 15728640 -> 15MB ; 2097152 -> 2MB
                                        if ($scope.sum > 2097152 && sizeImg.length == 2) {
                                            var alertPopup = $ionicPopup.alert({
                                                template: 'Sorry, max images size is 2MB',
                                                okText: $filter('translate')('okay'),
                                                okType: "button-stable",
                                                cssClass: "alertPopup2"
                                            });
                                            $scope.images = [];
                                            $scope.modalImage.hide();
                                            $scope.checking = false;
                                        } else {
                                            $scope.images.push({
                                                filename: "LC_Complaint_"+ tgl + "_" + waktu,
                                                Base64String: dataIni, 
                                                filepath: dataIni
                                            });
                                            $scope.checking = true;
                                            $scope.showText = false;
                                            $scope.modalImage.hide();
                                        }
                                    };
                                    reader.readAsBinaryString(file);
                                },
                                function (evt) {
                                    //failed to get file
                                    $scope.checking = false;
                                });
                        },
                        // error callback
                        function () {
                            $scope.checking = false;
                        }
                    );
                }
                $scope.results = results;

                $ionicLoading.hide();
                $scope.progressUpload = true;

                $timeout(function () {
                    $scope.progressUpload = false;
                }, 6000);

            }, function (error) {
                $scope.checking = false;
                console.log('Error: ' + JSON.stringify(error)); // In case of error
            })
    }

    function add(a, b) {
        return a + b;
    }

    $scope.pathForImage = function (images) {
        if (images === null) {
            return ''
        } else {
            return cordova.file.dataDirectory + images
        }
    }
    $scope.clearImages = function (index) {
        // $scope.images = [];        
        $scope.images.splice(index, 1);
        $scope.checking = false;
        $scope.checkLoc = true;
    }
    //end of image

    //take a picture
    $scope.takeImage = function () {
        location();
        var options = {
            destinationType: Camera.DestinationType.DATA_URL,
            sourceType: Camera.PictureSourceType.CAMERA, // Camera.PictureSourceType.PHOTOLIBRARY
            allowEdit: false,
            encodingType: Camera.EncodingType.JPEG,
            popoverOptions: CameraPopoverOptions,
            quality: 50,
            targetWidth: 500,
            targetHeight: 500,
            correctOrientation: true,
        };
        var date = new Date();
        var year = date.getFullYear();
        var month = ('0' + date.getMonth()).slice(-2);
        var day = ('0' + date.getDate()).slice(-2);

        var hours = ('0' + date.getHours()).slice(-2);
        var minutes = ('0' + date.getMinutes()).slice(-2);
        var seconds = ('0' + date.getSeconds()).slice(-2);
        var tgl = year+''+''+month+''+''+day;
        var waktu = hours+''+''+minutes+''+''+seconds;

        $cordovaCamera.getPicture(options).then(function (imageData) {
            console.log("imgdt: " + imageData);

            $scope.images.push({
                filename: "LC_Complaint_" + tgl + "_" + waktu,
                Base64String: imageData,
                filepath: imageData
            });
            $scope.modalImage.hide();
            $scope.checking = true;
            $scope.showText = true;
            $scope.checkLoc = true;
            
        }, function (err) {
            console.log("eh ada error: " + err);
            $scope.modalImage.hide();
        });

        function makeid() {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

            for (var i = 0; i < 5; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }
            return text;
        }

        function location() {
            navigator.geolocation.watchPosition
                (function onSucces(position) {
                    lat = position.coords.latitude;
                    long = position.coords.longitude;
                    $scope.location = "(" + lat + ", " + long + ")";
                }, function onMapError(error) {
                    console.log("error location: " + error);
                },
                { enableHighAccuracy: false });
        }
    }
    //

    $scope.generals = 'active';

    // general tab & property tab
    var genTab = angular.element(document.querySelector('#generaltab'));
    var proTab = angular.element(document.querySelector('#propertytab'));
    genTab.addClass("active");

    $scope.general = function () {
        $ionicSlideBoxDelegate.previous();
        $scope.generals = 'active';
        $scope.propertys = '';
    };
    $scope.property = function () {
        $ionicSlideBoxDelegate.next();
        $scope.propertys = 'active';
        $scope.generals = '';
    };
    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
        if ($scope.slideIndex == 1) {
            $scope.generals = '';
            $scope.propertys = 'active';
        } else {
            $scope.propertys = '';
            $scope.generals = 'active';
        }
    };

};
