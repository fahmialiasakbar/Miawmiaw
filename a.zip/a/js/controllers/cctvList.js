angular
    .module('livein')
    .controller('cctv', cctv);

function cctv($scope, $ionicLoading, $state, cctv, $filter) {
    $scope.data;
    $scope.fake=[1,2,3,4,5,6];
    
    // ----- Analytic Screen
    if(window.ga){
        var analyticView = 'CCTV List';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }
    
    if(window.hasOwnProperty('StatusBar')){
        StatusBar.show();
    }

    cctvList();
    function cctvList() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
        cctv.cctvList(
            function (response) {
                if (response != false) {
                    $scope.data = response;
                } else {
                    $scope.data = { name: $filter('translate')('failed_get_data') };
                }
                $ionicLoading.hide();
            });
    };
}
