angular
    .module('livein')
    .controller('category', category)
    .controller('categoryRecomended', categoryRecomended)
    .controller('categoryList', categoryList)
    .controller('tenantCategory', tenantCategory)
    .filter('rounded', rounded);

function rounded() {
    return function (val) {
        return val.toFixed(0);
    }
}

function categoryList($scope, $ionicHistory) {
    $scope.populars = [
        {
            title: 'house_property',
            image: 'img/listCategory/ic_home.png',
            link: 'app.category({idcategory:40})'
        },
        {
            title: 'traditional_food',
            image: 'img/listCategory/ic_local_dining.png',
            link: 'app.category({idcategory:33})'
        },
        {
            title: 'hotel',
            image: 'img/listCategory/ic_hotel.png',
            link: 'app.category({idcategory:45})'
        },
        {
            title: 'bakery',
            image: 'img/listCategory/ic_cake.png',
            link: 'app.category({idcategory:36})'
        },
        {
            title: 'apartment_property',
            image: 'img/listCategory/ic_domain.png',
            link: 'app.category({idcategory:47})'
        },
        {
            title: 'gym',
            image: 'img/listCategory/ic_fitness_center.png',
            link: 'app.category({idcategory:21})'
        },
        {
            title: 'commercial_property',
            image: 'img/listCategory/ic_location_city.png',
            link: 'app.category({idcategory:43})'
        },
        {
            title: 'spa___treatment',
            image: 'img/listCategory/ic_spa.png',
            link: 'app.category({idcategory:30})'
        },
        {
            title: 'electronic',
            image: 'img/listCategory/ic_dvr.png',
            link: 'app.category({idcategory:53})'
        },
        {
            title: 'cafe_lounge_bar',
            image: 'img/listCategory/ic_local_bar.png',
            link: 'app.category({idcategory:37})'
        },
        {
            title: 'outdoor_sport',
            image: 'img/listCategory/ic_golf_course.png',
            link: 'app.category({idcategory:22})'
        }

    ];

    $scope.allCategory = [
        {
            title: 'property_market',
            image: 'img/listCategory/ic_home.png',
            link: 'app.property'
        },
        {
            title: 'dining',
            image: 'img/listCategory/ic_local_dining.png',
            link: 'app.tenantCategory({idcategory:12})'
        },
        {
            title: 'accomodation',
            image: 'img/listCategory/ic_hotel.png',
            link: 'app.tenantCategory({idcategory:13})'
        },
        {
            title: 'entertaiment',
            image: 'img/listCategory/ic_local_movies.png',
            link: 'app.tenantCategory({idcategory:11})'
        },
        {
            title: 'shopping',
            image: 'img/listCategory/ic_local_mall.png',
            link: 'app.tenantCategory({idcategory:14})'
        },
        {
            title: 'education',
            image: 'img/listCategory/ic_school.png',
            link: 'app.tenantCategory({idcategory:65})'
        },
        {
            title: 'transportation',
            image: 'img/listCategory/ic_directions_bus.png',
            link: 'app.tenantCategory({idcategory:15})'
        },
        {
            title: 'health_care',
            image: 'img/listCategory/ic_local_hospital.png',
            link: 'app.tenantCategory({idcategory:69})'
        },
        {
            title: 'public_services',
            image: 'img/listCategory/ic_public.png',
            link: 'app.tenantCategory({idcategory:72})'
        },
        {
            title: 'industrial_info',
            image: 'img/listCategory/ic_assignment_late.png',
            link: 'app.tenantCategory({idcategory:82})'
        },
        {
            title: 'my_billing_nav',
            image: 'img/listCategory/ic_public.png',
            link: 'app.loginebilling({isMenu:"listCategory"})'
        },
        {
            title: 'useful_information',
            image: 'img/listCategory/ic_info.png',
            link: 'app.tenantCategory({idcategory:1})'
        }

    ];

    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };
}

function tenantCategory($stateParams, $scope, $ionicHistory, $localStorage, TenantService, $filter) {
    $scope.myGoBack = function () {
        $ionicHistory.goBack();
    };

    // watching localStorage value change
    $scope.$watch(function () {
        return angular.toJson($localStorage);
    }, function () {
        $scope.currentUser = $localStorage.currentUser;
        if ($scope.currentUser != null) {
            $scope.fullname = $scope.currentUser.data[0].fullname;
            $scope.currentUser.data[0].privilege == 'resident' ? $scope.showPrivillage = true : $scope.showPrivillage = false;
            $scope.salah = true;
        } else {
            $scope.fullname = "";
            $scope.salah = false;
        }
    });

    $scope.sorry = function () {
        var alertPopup = $ionicPopup.alert({
            template: $filter('translate')('blm_login'),
            okText: $filter('translate')('okay'),
            okType: "button-stable",
            cssClass: "alertPopup"
        });
    }

    listAllChild();
    function listAllChild() {
        TenantService.listChild($stateParams.idcategory, function (response) {
            //$timeout(function(){
            if (response != false) {
                $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
                var parentname = response[0].parentname;
                if ($scope.lang == 'ina') {
                    parentname = response[0].parentname_id != null ? response[0].parentname_id : response[0].parentname;
                }

                var id = $stateParams.idcategory;
                $scope.categoryData = [];
                $scope.subcategorys = parentname; 
                console.log(parentname) 
                if (response[0].parentname == "Dining") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_local_dining.png',
                            link: 'app.recommended({idcategory:12})'
                        }
                    ]
                } else if (response[0].parentname == "Accomodation") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_hotel.png',
                            link: 'app.recommended({idcategory:13})'
                        }
                    ]
                } else if (response[0].parentname == "Entertainment") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_local_movies.png',
                            link: 'app.recommended({idcategory:11})'
                        }
                    ]
                } else if (response[0].parentname == "Shopping") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_local_mall.png',
                            link: 'app.recommended({idcategory:14})'
                        }
                    ]
                } else if (response[0].parentname == "Transportation") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('public_transportation'),
                            link: 'app.publictransportation'
                        },
                        {
                            title: $filter('translate')('bus'),
                            link: 'app.bus'
                        },
                    ]
                } else if (response[0].parentname == "Public Services") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_public.png',
                            link: 'app.recommended({idcategory:72})'
                        }
                    ]
                } else if (response[0].parentname == "Education") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_school.png',
                            link: 'app.recommended({idcategory:65})'
                        }
                    ]
                } else if (response[0].parentname == "Health Care") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_local_hospital.png',
                            link: 'app.recommended({idcategory:69})'
                        }
                    ]
                } else if (response[0].parentname == "Industry") {
                    $scope.categoryData = [
                        {
                            title: $filter('translate')('recommended') + ' ' + parentname,
                            image: 'img/listCategory/ic_assignment_late.png',
                            link: 'app.recommended({idcategory:82})'
                        }
                    ]
                }

                for (var i = 0; i < response.length; i++) {
                    var categoryname = response[i].categoryname;
                    if ($scope.lang == 'ina') {
                        categoryname = response[i].categoryname_id != null ? response[i].categoryname_id : response[i].categoryname;
                    }

                    $scope.categoryData.push({
                        title: categoryname,
                        link: 'app.category({idcategory:' + response[i].idcategory + '})'
                    });
                }
            } else {
                var id = $stateParams.idcategory;
                if (id == 1) {
                    $scope.categoryData = [];
                    $scope.subcategorys = $filter('translate')('useful_information');

                    if ($scope.salah == true) {
                        $scope.linkDiscount = 'app.coupon'
                    } else if ($scope.salah == false) {
                        $scope.linkDiscount = 'login'
                    }

                    $scope.categoryData = [
                        {
                            title: $filter('translate')('discount') + ' ' + $filter('translate')('coupon'),
                            image: '',
                            link: 'app.coupon'
                        },
                        {
                            title: $filter('translate')('city_gallery'),
                            image: '',
                            link: 'app.gallery'
                        },
                        {
                            title: $filter('translate')('city_info'),
                            image: '',
                            link: 'app.cityInfo'
                        },
                        {
                            title: $filter('translate')('helpful_number'),
                            image: '',
                            link: 'app.helpfulNumber'
                        },
                        {
                            title: $filter('translate')('world_clock'),
                            image: '',
                            link: 'app.worldclock'
                        }
                    ]
                }
            }
            //}, 1000);
        });
    }
}

function category($scope, $cordovaGeolocation, $timeout, $stateParams, TenantService, $ionicLoading, $filter, $ionicScrollDelegate) {

    //$timeout(function(){
    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 2000 });

    $scope.tab1 = false;
    $scope.tab2 = false;
    $scope.tab3 = false;
    listAllChild();
    filterByCategory();
    tabClickedFunc(1);

    function listAllChild() {
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY'); 
        TenantService.listAllChild($stateParams.idcategory, function (response) {
            $timeout(function () {
                if (response != false) {
                    var id = $stateParams.idcategory;
                    if (id == 17 || id == 18 || id == 20 || id == 50 || id == 65 || id == 69 || id == 82 || id == 82) {
                        $scope.subcategorys = response[0].parentname;
                        if($scope.lang == 'ina'){
                            $scope.subcategorys = response[0].parentname_id != null ? response[0].parentname_id : response[0].parentname;
                        }
                        console.log('subcat 26 : ' + $scope.subcategorys);
                        $scope.categoryData = [];
                        var categoryKey = $scope.subcategorys.toLowerCase('');
                        categoryKey = $scope.subcategorys.replace(/ +|&/g, '_');

                        $scope.categoryData.push({
                            'categoryValue': $scope.subcategorys,
                            'categoryName': $scope.subcategorys
                        });

                        $scope.catName = $scope.categoryData[0].categoryValue;
                        if ($scope.categoryData != null) {
                            $timeout(function () {
                                $scope.ini = $scope.categoryData;
                            }, 0);
                        } else {
                            $timeout(function () {
                                $scope.ini = $scope.categoryData;
                            }, 1000);
                        }
                    } else {
                        $scope.subcategorys = response[0].categoryname;
                        if($scope.lang == 'ina'){
                            $scope.subcategorys = response[0].categoryname_id != null ? response[0].categoryname_id : response[0].categoryname;
                        }
                        console.log('subcat 30 : ' + $scope.subcategorys);
                        $scope.categoryData = [];
                        var categoryKey = $scope.subcategorys.toLowerCase('');
                        categoryKey = $scope.subcategorys.replace(/ +|&/g, '_');

                        $scope.categoryData.push({
                            'categoryValue': $scope.subcategorys,
                            'categoryName': $scope.subcategorys
                        });

                        $scope.catName = $scope.categoryData[0].categoryValue;
                        console.log('allo ini catDat : ' + JSON.stringify($scope.categoryData));
                        console.log($scope.catName);
                        // ----- Analytic Screen
                        if (window.ga) {
                            var analyticView = 'List '+$scope.catName;
                            window.ga.trackView(analyticView);
                            window.ga.trackEvent('Tenant List', analyticView);
                            console.log("Analytic - Screen View - " + analyticView);
                        }
                    }
                }
            }, 1000);
        });
    }

    function filterByCategory() {
        TenantService.filterByCategory($stateParams.idcategory, function (response) {
            $timeout(function () {
                if (response != false) {
                    $scope.categorys = response;
                    //
                    $scope.categoryData = [];
                    var a = 0;
                    angular.forEach($scope.categorys, function () {
                        var b = a++;
                        var list = $scope.categorys;
                        var data = list[b];

                        var categoryname = data.categoryname;
                        var categoryKey = categoryname.toLowerCase('');
                        categoryKey = categoryKey.replace(/ +|&/g, '_');

                        $scope.categoryData.push({
                            'categoryValue': categoryname,
                            'categoryName': $filter('translate')(categoryKey)
                        });
                        if ($scope.categoryData != null) {
                            $timeout(function () {
                                $scope.ini = $scope.categoryData;
                            }, 0);
                        } else {
                            $timeout(function () {
                                $scope.ini = $scope.categoryData;
                            }, 1000);
                        }
                        //$scope.list = $filter('translate')(categoryname);
                    });
                } else {
                    $scope.categorys = [{ name: $filter('translate')('no_user') }];
                }
            }, 1000);
        });
    }

    function listTenant() {
        $ionicLoading.show({ template: $filter('translate')('loading') + "..." });

        TenantService.listTenant($stateParams.idcategory, function (response) {
            $timeout(function () {
                if (response != false) {

                    var id = $stateParams.idcategory;

                    //inisialisation of filter
                    if (id == 17 || id == 18 || id == 20 || id == 49 || id == 50 || id == 65 || id == 69 || id == 82) {
                        $scope.filter = true;
                    } else {
                        $scope.filter = false;
                    }
                    
                    $scope.showText = false;
                    $scope.hideSkeleton=false;
                    $scope.data = response;
                    $scope.tenantdata = [];
                    var a = 0;
                    angular.forEach($scope.data, function (obj) {
                        var b = a++;
                        var list = $scope.data;
                        var data = list[b];
                        var idcategory = data.idcategory;
                        var categoryname = data.categoryname;
                        var level = data.level;
                        var idtenant = data.idtenant;
                        var avatar = data.avatar;
                        var tenantsname = data.tenantsname;
                        var address = data.address;
                        var longlat = calculatdistance(data.longlat);
                        var premium = data.premium;
                        var phone = data.phone;
                        var link = data.link;
                        var logo = data.logo;
                        var color = data.color;
                        var rate = parseFloat(data.rate).toFixed(1);
                        var open = data.open;
                        var openhour = data.openhour;
                        var closehour = data.closehour;

                        $scope.tenantdata.push({
                            'idcategory': idcategory,
                            'categoryname': categoryname,
                            'level': level,
                            'idtenant': idtenant,
                            'avatar': avatar,
                            'tenantsname': tenantsname,
                            'address': address,
                            'longlat': longlat,
                            'premium': premium,
                            'phone': phone,
                            'link': link,
                            'logo': logo,
                            'color': color,
                            'rate': rate,
                            'open': open,
                            'openhour': openhour,
                            'closehour': closehour
                        });
                    });
                    $ionicLoading.hide();
                } else {
                    $scope.showText=true;
                    $scope.hideSkeleton=true;
                    $scope.data = [{ name: $filter('translate')('no_user') }];
                    $ionicLoading.hide();
                }
                $scope.$broadcast('scroll.refreshComplete');
            }, 2000);

        });
    }

    $scope.tabClicked = tabClickedFunc;

    $scope.doRefresh = function () {
        if ($scope.tab1) {
            listTenant();
        } else if ($scope.tab2) {
            listRecomendedTenant();
        } else if ($scope.tab3) {
            listBookmarkedTenant();
        }
    }
    function tabClickedFunc(tabName) {
        if (tabName === 1) {
            $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 2000 });
            $scope.tab1 = true;
            $scope.tab2 = false;
            $scope.tab3 = false;
            listTenant();
        } else if (tabName === 2) {
            $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 2000 });
            $scope.tab1 = false;
            $scope.tab2 = true;
            $scope.tab3 = false;
            $scope.tenantdata = [];
            listRecomendedTenant();
        } else if (tabName === 3) {
            $scope.tab1 = false;
            $scope.tab2 = false;
            $scope.tab3 = true;
            $scope.tenantdata = [];
            listBookmarkedTenant();
        }
        
        $ionicScrollDelegate.scrollTop();
    }


    function listRecomendedTenant() {
        TenantService.listRecomendedTenant($stateParams.idcategory, function (response) {
            if (response[0].status != false) {
                $scope.data = response;
                $scope.tenantdata = [];
                $scope.showText = false;
                $scope.hideSkeleton = false;
                if (response.length > 0) {
                    if (response[0].status == undefined) {
                        var a = 0;
                        angular.forEach($scope.data, function (obj) {
                            var b = a++;
                            var list = $scope.data;
                            var data = list[b];
                            var idcategory = data.idcategory;
                            var categoryname = data.categoryname;
                            var level = data.level;
                            var idtenant = data.idtenant;
                            var avatar = data.avatar;
                            var tenantsname = data.tenantsname;
                            var address = data.address;
                            var longlat = calculatdistance(data.longlat);
                            var premium = data.premium;
                            var phone = data.phone;
                            var link = data.link;
                            var logo = data.logo;
                            var color = data.color;
                            var rate = parseFloat(data.rate).toFixed(1);
                            var open = data.open;
                            var openhour = data.openhour;
                            var closehour = data.closehour;
                            var bookmarked = data.bookmarked;

                            $scope.tenantdata.push({
                                'idcategory': idcategory,
                                'categoryname': categoryname,
                                'level': level,
                                'idtenant': idtenant,
                                'avatar': avatar,
                                'tenantsname': tenantsname,
                                'address': address,
                                'longlat': longlat,
                                'premium': premium,
                                'phone': phone,
                                'link': link,
                                'logo': logo,
                                'color': color,
                                'rate': rate,
                                'open': open,
                                'openhour': openhour,
                                'closehour': closehour,
                                'bookmarked': bookmarked
                            });
                        });
                    }
                }
            } else {
                $scope.showText = true;
                $scope.hideSkeleton=true;
                $scope.data = [{ name: $filter('translate')('no_user') }];
            }

            $ionicLoading.hide();
            $scope.$broadcast('scroll.refreshComplete');

        });

    }

    function listBookmarkedTenant() {
        TenantService.listBookmarkedTenant($stateParams.idcategory, function (response) {
            if (response != false) {
                $scope.data = response;
                $scope.tenantdata = [];
                $scope.showText = false;
                var a = 0;
                angular.forEach($scope.data, function (obj) {
                    var b = a++;
                    var list = $scope.data;
                    var data = list[b];
                    var idcategory = data.idcategory;
                    var categoryname = data.categoryname;
                    var level = data.level;
                    var idtenant = data.idtenant;
                    var avatar = data.avatar;
                    var tenantsname = data.tenantsname;
                    var address = data.address;
                    var longlat = calculatdistance(data.longlat);
                    var premium = data.premium;
                    var phone = data.phone;
                    var link = data.link;
                    var logo = data.logo;
                    var color = data.color;
                    var rate = parseFloat(data.rate).toFixed(1);
                    var open = data.open;
                    var openhour = data.openhour;
                    var closehour = data.closehour;
                    var bookmarked = data.bookmarked;

                    $scope.tenantdata.push({
                        'idcategory': idcategory,
                        'categoryname': categoryname,
                        'level': level,
                        'idtenant': idtenant,
                        'avatar': avatar,
                        'tenantsname': tenantsname,
                        'address': address,
                        'longlat': longlat,
                        'premium': premium,
                        'phone': phone,
                        'link': link,
                        'logo': logo,
                        'color': color,
                        'rate': rate,
                        'open': open,
                        'openhour': openhour,
                        'closehour': closehour,
                        'bookmarked': bookmarked
                    });
                });
            } else {
                $scope.showText = true;
                $scope.hideSkeleton=true;
                $scope.data = [{ name: $filter('translate')('no_user') }];
            }

            $ionicLoading.hide();
            $scope.$broadcast('scroll.refreshComplete');

        });

    }



    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    calculatdistance = function (longlat) {
        if (longlat) {
            datalonglat1 = longlat.replace('(', '');
            datalonglat2 = datalonglat1.replace(')', '');
            lattenant = (datalonglat2.split(',')[0]);
            longtenant = (datalonglat2.split(',')[1]);

            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
            var dLon = deg2rad($scope.long - longtenant);
            var a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            var d = R * c; // Distance in km
        }
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
    // }, 1000);
}

function categoryRecomended($scope, $cordovaGeolocation, $stateParams, TenantService, $ionicLoading, $filter) {
    $ionicLoading.show({ template: $filter('translate')('loading') + "...", duration: 1000 });
    $scope.categoryname = $filter('translate')('recommended');

    listRecomendedTenant();

    function listRecomendedTenant() {
        TenantService.listRecomendedTenant($stateParams.idcategory, function (response) {
            if (response != false) {
                $scope.data = response;
                $scope.tenantdata = [];
                var a = 0;
                angular.forEach($scope.data, function (obj) {
                    var b = a++;
                    var list = $scope.data;
                    var data = list[b];
                    var idcategory = data.idcategory;
                    var categoryname = data.categoryname;
                    var level = data.level;
                    var idtenant = data.idtenant;
                    var avatar = data.avatar;
                    var tenantsname = data.tenantsname;
                    var address = data.address;
                    var longlat = calculatdistance(data.longlat);
                    var premium = data.premium;
                    var phone = data.phone;
                    var link = data.link;
                    var logo = data.logo;
                    var color = data.color;
                    var rate = parseFloat(data.rate).toFixed(1);
                    var open = data.open;
                    var openhour = data.openhour;
                    var closehour = data.closehour;
                    var bookmarked = data.bookmarked;

                    $scope.tenantdata.push({
                        'idcategory': idcategory,
                        'categoryname': categoryname,
                        'level': level,
                        'idtenant': idtenant,
                        'avatar': avatar,
                        'tenantsname': tenantsname,
                        'address': address,
                        'longlat': longlat,
                        'premium': premium,
                        'phone': phone,
                        'link': link,
                        'logo': logo,
                        'color': color,
                        'rate': rate,
                        'open': open,
                        'openhour': openhour,
                        'closehour': closehour,
                        'bookmarked': bookmarked
                    });
                });
            } else {
                $scope.data = [{ name: $filter('translate')('no_user') }];
            }

            $ionicLoading.hide();

        });

    }

    var posOptions = { timeout: 10000, enableHighAccuracy: true };
    $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
        $scope.lat = position.coords.latitude;
        $scope.long = position.coords.longitude;
    });

    calculatdistance = function (longlat) {
        datalonglat1 = longlat.replace('(', '');
        datalonglat2 = datalonglat1.replace(')', '');
        lattenant = (datalonglat2.split(',')[0]);
        longtenant = (datalonglat2.split(',')[1]);

        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad($scope.lat - lattenant); // deg2rad below
        var dLon = deg2rad($scope.long - longtenant);
        var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad($scope.lat)) * Math.cos(deg2rad(lattenant)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        if (!d) d = 0;
        return d;
    }

    function deg2rad(deg) {
        return deg * (Math.PI / 180);
    }

}
