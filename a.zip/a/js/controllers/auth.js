angular
    .module('livein')
    .controller('login', login);

function login($window, $scope, $rootScope, Notification, LoginService, $ionicPopup, $ionicLoading, $state, registerService, AdvertiseService, $filter, $location, $localStorage, $timeout) {
    $scope.data = {};
    $scope.credentials = loginManualService;
    $scope.facebook_auth = facebookAuth;
    $scope.google_auth = google_auth;
    $scope.twitter_auth = twitter_auth;

    initController();
    // ----- Analytic Screen
    if (window.ga) {
        var analyticView = 'Login';
        window.ga.trackView(analyticView);
        window.ga.trackEvent('Screen View', analyticView);
        console.log("Analytic - Screen View - " + analyticView);
    }

    function initController() {
        // reset login status
        LoginService.logoutUser();

    };

    $scope.passpor = 'password';
    $scope.showFunction = function () {
        $scope.passpor = 'text';
    }
    $scope.hideFunction = function () {
        $scope.passpor = 'password';
    }

    $scope.startApp = function () {
        $state.go('app.main', {}, { reload: true });
    }

    // Login By Credentials
    function loginManualService(data) {
        $scope.lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        if (data.email && data.password) {
            $ionicLoading.show({ template: $filter('translate')('loginmessage') + "...", duration: 2000 });

            LoginService.loginUser(
                data.email,
                data.password,
                function (response) {
                    if (response[0].status == true) {

                        $scope.users = response;
                        $state.go('app.main');
                        $scope.data.email = "";
                        $scope.data.password = "";
                        // $scope.myForm.$setPristine();

                        $rootScope.StartEvent = false;

                        if ($location.path() == "/app/main") {

                            var getStatus = $ionicPopup.alert({
                                template: $filter('translate')('hello') + '! ' + $scope.users[0].fullname + '. ' + $filter('translate')('welcome_dialog') + ' <strong>' + $scope.users[0].privilege + '!</strong> ',
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });

                            getStatus.then(function (res) {
                                if (res) {
                                    AdvertiseService.AdsLogin();
                                }
                            });

                            $ionicLoading.hide();

                        }
                    } else {
                        $scope.messages = response[0].messages;
                        if($scope.lang == 'ina'){
                            $scope.messages = response[0].messages_id != null ? response[0].messages_id : response[0].messages;
                        }
                        $ionicLoading.show({
                            template: $scope.messages,
                            duration: 2000
                        });
                    }

                });
            // ----- Analytic Screen
            if (window.ga) {
                var analyticView = 'Login Manual';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Login', analyticView);
                console.log("Analytic - Login - " + analyticView);
            }
        } else {
            $ionicLoading.show({
                template: $filter('translate')('enter_credential'),
                duration: 2000
            });
        }
    }

    // Facebook Auth
    function facebookAuth() {
        ionic.Platform.ready(function () {
            facebookConnectPlugin.logout(function succes(result) {
                getloginfacebook();
            }, function oneror(error) {
                getloginfacebook();
            })
            // ----- Analytic Screen
            if (window.ga) {
                var analyticView = 'Facebook';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Login', analyticView);
                console.log("Analytic - Login - " + analyticView);
            }
        });
    }

    function getloginfacebook() {
        facebookConnectPlugin.login(["public_profile", "email", "user_birthday"], function onSucces(result) {

            facebookConnectPlugin.api("me" + "/?fields=id,email,gender,birthday,name", null,
                function onSuccess(datauser) {
                    console.log("Resultnya: ", datauser);
                    senddatauser(datauser, "facebook");
                },
                function onError(erroruser) {
                    console.error("Failed: ", erroruser);
                }
            );
        }, function onError(error) {
            var alertPopup = $ionicPopup.alert({
                title: $filter('translate')('user_cancelled'),
                okText: $filter('translate')('okay'),
                okType: "button-stable", 
                cssClass: "alertPopup"
            });
        });

    }

    // Google Plus Auth
    function google_auth() {

        ionic.Platform.ready(function () {
            // ----- Analytic Screen
            if (window.ga) {
                var analyticView = 'Google Plus';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Login', analyticView);
                console.log("Analytic - Login - " + analyticView);
            }
            if (window.plugins.googleplus && window.plugins) {
                window.plugins.googleplus.isAvailable(
                    function (available) {

                        var params = {
                            'scopes': 'profile email', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
                            'webClientId': 'com.googleusercontent.apps.683716271520-acb1b36o862aotvbdh0d6gooolkn0ar8', // optional clientId of your Web application from Credentials settings of your project - On Android, this MUST be included to get an idToken. On iOS, it is not required.
                            'offline': false, // optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
                        };
                        if (ionic.Platform.isAndroid()) {
                            params = {
                                'scopes': 'profile email', // optional, space-separated list of scopes, If not included or empty, defaults to `profile` and `email`.
                                'offline': false, // optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
                            };
                        } 
                        window.plugins.googleplus.login(params,
                            function (obj) {
                                console.log(JSON.stringify(obj));
                                senddatauser(obj, "google") // do something useful instead of alerting
                            },
                            function (msg) {
                                var alertPopup = $ionicPopup.alert({
                                    title: $filter('translate')('user_cancelled'),
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });
                                console.log('error: ' + msg);
                            });

                    });
            }
            // will execute when device is ready, or immediately if the device is already ready.
        });

    }

    // Twitter Auth
    function twitter_auth() {
        ionic.Platform.ready(function () {
            
            $ionicPopup.alert({
                template: $filter('translate')('soon'), 
                okText: $filter('translate')('okay'),
                cssClass: "alertPopup"
            });
            // twitterlogout();

            // ----- Analytic Screen
            if (window.ga) {
                var analyticView = 'Twitter';
                window.ga.trackView(analyticView);
                window.ga.trackEvent('Login', analyticView);
                console.log("Analytic - Login - " + analyticView);
            }

            // TwitterConnect.login(
            //     function (result) {
            //         console.log('Successful login!');
            //         console.log(result);
            //         getshowuseremail();
            //     },
            //     function (error) {
            //         var alertPopup = $ionicPopup.alert({
            //             title: $filter('translate')('user_cancelled'),
            //             okText: $filter('translate')('okay'),
            //             okType: "button-stable",
            //             cssClass: "alertPopup"
            //         });
            //     }
            // );
            // console.log("udah masuk ready")
        }, function error(error) { console.log(JSON.stringify(error)) });
    }

    function getshowuseremail() {
        TwitterConnect.showUserEmail(function (result) {
            if (result.email !== undefined) {
                savetolocal(result.id_str, result.email);
            } else {
                var data = getLocalTwitter(result.id_str);
                var object = JSON.parse(JSON.stringify(data));
                result['email'] = object.email;
            }
            senddatauser(result, "twitter");
        }, function (error) {
            console.log('Errornya: ' + error)
        })
    }

    function getLocalTwitter(id) {
        return angular.fromJson(sessionStorage[id]);
    }

    function savetolocal(id, email) {
        sessionStorage[id] = angular.toJson({
            email: email,
        });
    }

    //action of login and register
    function senddatauser(data_user, sosmed) {

        $ionicLoading.show({ template: $filter('translate')('loginmessage') + "...", duration: 2000 });

        if (sosmed == "facebook") {
            var gender = 'n';
            if(data_user){ 
                if(data_user.gender){
                    if (data_user.gender.toLowerCase() == "male") {
                        gender = "m"
                    } else if (data_user.gender.toLowerCase() == "female") {
                        gender = "f"
                    }
                }
            }

            registerService.registerManualService(
                data_user.name,
                gender,
                '',
                data_user.email,
                Math.floor(100000000 + Math.random() * 90000000),
                function (response) {
                    if (response != false) {
                        if (response[0].status == false) {
                            if (response[0].isactive == 't') {

                                $localStorage.currentUser = { data: response };

                                Notification.countUnreadNotif(function (response) {
                                    if(window.hasOwnProperty('cordova')){
                                        cordova.plugins.notification.badge.set(response);
                                    }
                                });
                                $state.go('app.main');

                                var alertPopup = $ionicPopup.alert({
                                    template: $filter('translate')('hello') + ' ' + response[0].fullname + '. ' + $filter('translate')('welcome_dialog') + ' <strong>' + response[0].privilege + '!</strong> ',
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });

                                alertPopup.then(function (res) {
                                    if (res) {
                                        AdvertiseService.AdsLogin();
                                    }
                                });
                            } else {
                                var alertPopup = $ionicPopup.alert({
                                    title: $filter('translate')('login_success'),
                                    template: $filter('translate')('check_email_login'),
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });
                                facebooklogout()
                            }
                        } else if (response[0].status == true) {
                            var alertPopup = $ionicPopup.alert({
                                title: $filter('translate')('login_success'),
                                template: $filter('translate')('check_email_login'),
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });
                            console.log("true")
                            facebooklogout()
                        }
                    } else {
                        var alertPopup = $ionicPopup.alert({
                            title: $filter('translate')('login_failed'),
                            template: $filter('translate')('email2'),
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                        facebooklogout()

                        //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
                        $state.go('/login');
                    }
                    $ionicLoading.hide();
                });
        } else if (sosmed == "google") {

            registerService.registerManualService(
                data_user.displayName,
                "n",
                '',
                data_user.email,
                Math.floor(100000000 + Math.random() * 90000000),
                function (response) {
                    if (response != false) {
                        if (response[0].status == false) {
                            if (response[0].isactive == 't') {
                                $state.go('app.main');
                                $localStorage.currentUser = { data: response };
                                Notification.countUnreadNotif(function (response) {
                                    if(window.hasOwnProperty('cordova')){
                                        cordova.plugins.notification.badge.set(response);
                                    }
                                });
                                var alertPopup = $ionicPopup.alert({
                                    template: $filter('translate')('hello') + ' ' + response[0].fullname + '. ' + $filter('translate')('welcome_dialog') + ' <strong>' + response[0].privilege + '!</strong> ',
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });

                                alertPopup.then(function (res) {
                                    if (res) {
                                        AdvertiseService.AdsLogin();
                                    }
                                });
                            } else {
                                console.log('haloo belum aktif')
                                var alertPopup = $ionicPopup.alert({
                                    title: $filter('translate')('login_failed'),
                                    template: $filter('translate')('not_register'),
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });
                                googlesignout()
                            }

                            console.log("false")

                        } else if (response[0].status == true) {
                            var alertPopup = $ionicPopup.alert({
                                title: $filter('translate')('login_success'),
                                template: $filter('translate')('check_email_login'),
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });
                            console.log("true")
                            googlesignout()

                        }

                    } else {
                        var alertPopup = $ionicPopup.alert({
                            title: $filter('translate')('login_failed'),
                            template: $filter('translate')('email2'),
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                        googlesignout();

                        //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
                        $state.go('/login');
                    }
                    $ionicLoading.hide();
                });
        } else if (sosmed == "twitter") {
            console.log('data resultnyaa: ' + JSON.stringify(data_user));

            registerService.registerManualService(
                data_user.name,
                "n",
                '',
                data_user.email,
                Math.floor(100000000 + Math.random() * 90000000),
                function (response) {
                    if (response != false) {
                        if (response[0].status == false) {
                            if (response[0].isactive == 't') {
                                $localStorage.currentUser = { data: response };
                                Notification.countUnreadNotif(function (response) {
                                    if(window.hasOwnProperty('cordova')){
                                        cordova.plugins.notification.badge.set(response);
                                    }
                                });
                                $state.go('app.main');

                                var alertPopup = $ionicPopup.alert({
                                    template: $filter('translate')('hello') + ' ' + response[0].fullname + '. ' + $filter('translate')('welcome_dialog') + ' <strong>' + response[0].privilege + '!</strong> ',
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });

                                alertPopup.then(function (res) {
                                    if (res) {
                                        AdvertiseService.AdsLogin();
                                    }
                                });
                            } else {
                                console.log('haloo belum aktif')
                                var alertPopup = $ionicPopup.alert({
                                    title: $filter('translate')('registration_success'),
                                    template: $filter('translate')('check_email_login'),
                                    okText: $filter('translate')('okay'),
                                    okType: "button-stable",
                                    cssClass: "alertPopup"
                                });
                                twitterlogout()
                            }
                        } else if (response[0].status == true) {
                            var alertPopup = $ionicPopup.alert({
                                title: $filter('translate')('login_success'),
                                template: $filter('translate')('check_email_login'),
                                okText: $filter('translate')('okay'),
                                okType: "button-stable",
                                cssClass: "alertPopup"
                            });
                            console.log("sukses register woi")
                            twitterlogout()
                        }
                    } else {
                        var alertPopup = $ionicPopup.alert({
                            title: $filter('translate')('login_failed'),
                            template: $filter('translate')('email2'),
                            okText: $filter('translate')('okay'),
                            okType: "button-stable",
                            cssClass: "alertPopup"
                        });
                        twitterlogout()

                        //tetap di halaman register//muncul alert phone or email alredy exist->dari api persis
                        $state.go('/login');
                    }
                    $ionicLoading.hide();
                });
        }
    }


    function googlesignout() {
        window.plugins.googleplus.logout(
            function (msg) {
                window.plugins.googleplus.disconnect(
                    function (msg) {

                    }
                );
            }
        );
    }

    function facebooklogout() {
        facebookConnectPlugin.logout(function onSucces() {

        }, function onError() {

        })
    }

    function twitterlogout() {
        TwitterConnect.logout(
            function () {
                console.log('Successful logout!');
            },
            function () {
                console.log('Error logging out');
            }
        );
    }

    // function gotosetting() {
    //     if(typeof cordova.plugins.settings.openSetting != undefined){
    //         cordova.plugins.settings.open(function(){
    //                 console.log("opened settings")
    //             },
    //             function(){
    //                 console.log("failed to open settings")
    //             });
    //     }
    // }

}