angular
	.module('livein')
	.controller('busSchedule', busSchedule);

function busSchedule($scope, $localStorage, BusScheduleService, $rootScope, $state, $compile, $ionDrawerVerticalDelegate, $ionicSlideBoxDelegate, $ionicLoading, $ionicPopup, $filter, $ionicPlatform, $interval) { //, trackingVehiclesFactory) {
	$scope.daily = 'active';
	const maxLoadData = 3;
	
	$scope.fakeList = [];
	for(var fake=1; fake<=maxLoadData; fake++){
		$scope.fakeList.push(fake);
	}

	loadBusData();

	// ----- Analytic Screen
	if (window.ga) {
		var analyticView = 'Transportation Bus';
		window.ga.trackView(analyticView);
		window.ga.trackEvent('Screen View', analyticView);
		console.log("Analytic - Screen View - " + analyticView);
	}
 
	function loadBusData() {
		$scope.dataRoute = [];
		$scope.subRoute = [];
		BusScheduleService.getRoute(function (response) {
			if (response != false) { 
				for (var i = 0; i < maxLoadData; i++) {
					var route = response[i];
					$scope.dataRoute.push(route);
					dataWeekday1(route.idroute);
					// dataWeekday2(route.idroute);
					dataWeekend1(route.idroute);
					// dataWeekend2(route.idroute);
				}
				
				if($scope.dataRoute[3]) $scope.last = $scope.dataRoute[3].routename;
			}
		}); 
	}

	function checkString(string) {
		if (string == null) {
			return string = '';
		} else {
			return string = string.substring(0, 5);
		}
	}

	function dataWeekday1(idroute) {
		var iddays = 1;
		var pagenumber = 1;
		var pagesize = 100;
		$scope.data1 = [];
		$scope.data2 = [];
		$scope.data3 = [];
		BusScheduleService.getBus(iddays, idroute, pagenumber, pagesize, function (response) {
			$scope.routename1 = $scope.dataRoute[0].routename;
			$scope.routename2 = $scope.dataRoute[1].routename;
			$scope.routename3 = $scope.dataRoute[2].routename;
			if (response != null || response.length != 0) {
				for (i = 0; i < response.length; i++) {
					var depart = checkString(response[i].departure);
					if ($scope.dataRoute[0].idroute == idroute) {
						response[i].departure = depart;
						$scope.data1.push(response[i]);
					} else if ($scope.dataRoute[1].idroute == idroute) {
						response[i].departure = depart;
						$scope.data2.push(response[i]);
					} else if ($scope.dataRoute[2].idroute == idroute) {
						response[i].departure = depart;
						$scope.data3.push(response[i]);
					}
					
					$scope.data1.length == 0 ? $scope.check1 = true : $scope.check1 = false;
					$scope.data2.length == 0 ? $scope.check2 = true : $scope.check2 = false;
					$scope.data3.length == 0 ? $scope.check3 = true : $scope.check3 = false;
				}
			}
		});
	}

	function dataWeekday2(idroute) {
		var iddays = 1;
		var pagenumber = 2;
		var pagesize = 24;
		$scope.data4 = [];
		$scope.data5 = [];
		$scope.data6 = [];
		BusScheduleService.getBus(iddays, idroute, pagenumber, pagesize, function (response) {
			$scope.routename4 = $scope.dataRoute[0].routename;
			$scope.routename5 = $scope.dataRoute[1].routename;
			$scope.routename6 = $scope.dataRoute[2].routename;
			if (response != null || response.length != 0) {
				for (i = 0; i < response.length; i++) {
					var depart = checkString(response[i].departure);	
					if ($scope.dataRoute[0].idroute == idroute) {
						response[i].departure = depart;
						$scope.data4.push(response[i]);
					} else if ($scope.dataRoute[1].idroute == idroute) {
						response[i].departure = depart;
						$scope.data5.push(response[i]);
					} else if ($scope.dataRoute[2].idroute == idroute) {
						response[i].departure = depart;
						$scope.data6.push(response[i]);
					}
				}
				
				$scope.data4.length == 0 ? $scope.check4 = true : $scope.check4 = false;
				$scope.data5.length == 0 ? $scope.check5 = true : $scope.check5 = false;
				$scope.data6.length == 0 ? $scope.check6 = true : $scope.check6 = false;
			}
		});
	}

	function dataWeekend1(idroute) {
		var iddays = 2;
		var pagenumber = 1;
		var pagesize = 100;
		$scope.weekend1 = [];
		$scope.weekend2 = [];
		$scope.weekend3 = [];
		$scope.rangeWeekend = [];
		BusScheduleService.getBus(iddays, idroute, pagenumber, pagesize, function (response) {
			$scope.routenamewk1 = $scope.dataRoute[0].routename;
			$scope.routenamewk2 = $scope.dataRoute[1].routename;
			$scope.routenamewk3 = $scope.dataRoute[2].routename;
			if (response != null || response.length != 0) {
				for (i = 0; i < response.length; i++) {
					var depart = checkString(response[i].departure);
					var arriv = checkString(response[i].arrival);

					if ($scope.dataRoute[0].idroute == idroute) {
						response[i].departure = depart;
						$scope.weekend1.push(response[i]);
					} else if ($scope.dataRoute[1].idroute == idroute) {
						response[i].departure = depart;
						$scope.weekend2.push(response[i]);
					} else if ($scope.dataRoute[2].idroute == idroute) {
						response[i].departure = depart;
						response[i].arrival = arriv;
						$scope.weekend3.push(response[i]);
					}
					// jika arrival nya ditampilkan
					//  else if ($scope.dataRoute[3].idroute == idroute) { 
					// 	response[i].departure = depart;
					// 	response[i].arrival = arriv; 
					// 	$scope.rangeWeekend.push(response[i]);
					// }
				}
			
				$scope.weekend1.length == 0 ? $scope.wk1 = true : $scope.wk1 = false;
				$scope.weekend2.length == 0 ? $scope.wk2 = true : $scope.wk2 = false;
				$scope.weekend3.length == 0 ? $scope.wk3 = true : $scope.wk3 = false;
				// $scope.rangeWeekend.length == 0 ? $scope.range = true : $scope.range = false;
			}
		});
	}

	function dataWeekend2(idroute) {
		var iddays = 2;
		var pagenumber = 2;
		var pagesize = 24;
		$scope.weekend4 = [];
		$scope.weekend5 = [];
		$scope.weekend6 = [];
		BusScheduleService.getBus(iddays, idroute, pagenumber, pagesize, function (response) {
			$scope.routenamewk4 = $scope.dataRoute[0].routename;
			$scope.routenamewk5 = $scope.dataRoute[1].routename;
			$scope.routenamewk6 = $scope.dataRoute[2].routename;
			if (response != null || response.length != 0) {
				for (i = 0; i < response.length; i++) {
					var depart = checkString(response[i].departure);
					if ($scope.dataRoute[0].idroute == idroute) {
						response[i].departure = depart;
						$scope.weekend4.push(response[i]);
					} else if ($scope.dataRoute[1].idroute == idroute) {
						response[i].departure = depart;
						$scope.weekend5.push(response[i]);
					} else if ($scope.dataRoute[2].idroute == idroute) {
						response[i].departure = depart;
						$scope.weekend6.push(response[i]);
					}
				}

				$scope.weekend4.length == 0 ? $scope.wk4 = true : $scope.wk4 = false;
				$scope.weekend5.length == 0 ? $scope.wk5 = true : $scope.wk5 = false;
				$scope.weekend6.length == 0 ? $scope.wk6 = true : $scope.wk6 = false;
			}
		});
	}

	$ionicPlatform.ready(function () {
		if (ionic.Platform.isIOS() || ionic.Platform.isAndroid()) {
			try {
				cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
					if (enabled == true) {
						ionicToast.show($filter('translate')('gps_on'), 'bottom', false, 5000);
					}
					if (enabled == false) {
						console.log("masuk popup");
						var confirmPopup = $ionicPopup.confirm({
							title: $filter('translate')('dialog_title_gps'),
							template: $filter('translate')('dialog_content_gps')
						});
						confirmPopup.then(function (res) {
							if (res) {
								cordova.plugins.diagnostic.switchToLocationSettings();
							} else {
								console.log('You are not sure');
							}
						});

					}
				}, function (error) {
					alert("The following error occurred: " + error);
				});
			} catch (e) {

			}
		}
	});


	// navigator.geolocation.watchPosition
	// 	(function onSucces(position) {
	// 		$scope.location = new google.maps.LatLng(lat, long);

	// 	}, function onMapError(error) {
	// 		$scope.location = undefined;

	// 	}, { enableHighAccuracy: false });

	function popupconfirm() {
		var confirmPopup = $ionicPopup.confirm({
			title: "Permission ",
			template: "To show user's current location and buses location"
		});
		confirmPopup.then(function (res) {
			if (res) {
				confirm_status = 1;
				$localStorage.permission_transportation = { transportationMap: confirm_status };
				$ionicPlatform.ready(function () { $scope.location });
			} else {
				getdirection(undefined, $scope.tujuan)
			}
		});

	}


	//  marker
	var infowindow = new google.maps.InfoWindow;

	//ion Drawer Vertical Delegate
	$scope.toggleDrawer = function (handle) {
		$ionDrawerVerticalDelegate.$getByHandle(handle).toggleDrawer();
	}
	$scope.drawerIs = function (state) {
		return $ionDrawerVerticalDelegate.getState() == state;
	}

	//ionic SlideBox Delegate
	$scope.next = function () {
		$ionicSlideBoxDelegate.next();
		$scope.weekend = 'active';
		$scope.daily = '';
	};
	$scope.previous = function () {
		$ionicSlideBoxDelegate.previous();
		$scope.daily = 'active';
		$scope.weekend = '';
	};
	// Called each time the slide changes
	$scope.slideChanged = function (index) {
		$scope.slideIndex = index;
		if ($scope.slideIndex == 1) {
			$scope.weekend = 'active';
			$scope.daily = '';
		} else {
			$scope.daily = 'active';
			$scope.weekend = '';
		}
	};

	function loadMap(map, result) {

		/* Start : Tracking Bus */
		var settings = {
			"async": true,
			"crossDomain": true,
			"url": "http://fleettestlive.cartrack.id/api/index.php",
			"method": "POST",
			"headers": {
				"authorization": "Basic WExRUTAwMDAxOkFPbGNAMTAtNzA=",
				"soapaction": "fleettestlive.cartrack.id/api/#get_vehicle_last_positions",
				"content-type": "text/xml; charset=utf-8",
				"cache-control": "no-cache"
			},
			"data": '<x:Envelope xmlns:x="http://schemas.xmlsoap.org/soap/envelope/" xmlns:api="fleettestlive.cartrack.id/api/"><x:Body><api:endpoint.get_vehicle_last_positions></api:endpoint.get_vehicle_last_positions></x:Body></x:Envelope>'
		};

		$.ajax(settings).done(function (response) {
			var locations = [];
			function xmlToJson(xml) {
				// Create the return object
				var obj = {};

				if (xml.nodeType == 1) { // element
					// do attributes
					if (xml.attributes.length > 0) {
						obj["@attributes"] = {};
						for (var j = 0; j < xml.attributes.length; j++) {
							var attribute = xml.attributes.item(j);
							obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
						}
					}
				} else if (xml.nodeType == 3) { // text
					obj = xml.nodeValue;
				}

				// do children
				if (xml.hasChildNodes()) {
					for (var i = 0; i < xml.childNodes.length; i++) {
						var item = xml.childNodes.item(i);
						var nodeName = item.nodeName;
						if (typeof (obj[nodeName]) == "undefined") {
							obj[nodeName] = xmlToJson(item);
						} else {
							if (typeof (obj[nodeName].push) == "undefined") {
								var old = obj[nodeName];
								obj[nodeName] = [];
								obj[nodeName].push(old);
							}
							obj[nodeName].push(xmlToJson(item));
						}
					}
				}
				return obj;
			};

			var xml = new XMLSerializer().serializeToString(response);
			var xmlDoc = new DOMParser().parseFromString(xml, "text/xml");
			var json = xmlToJson(xmlDoc);
			var item = json["SOAP-ENV:Envelope"]["SOAP-ENV:Body"]["ns1:endpoint.get_vehicle_last_positionsResponse"]["SqlResult0"]["item"];

			item.forEach(function (element, index) { 
				var registration = element.out_registration ? element.out_registration["#text"] ? element.out_registration["#text"] : ''  : '';
				var latitude = element.out_latitude ? element.out_latitude["#text"] ? element.out_latitude["#text"] : ''  : '';
				var longitude = element.out_longitude ? element.out_longitude["#text"] ? element.out_longitude["#text"] : ''  : '';
				var description = element.out_event_description ? element.out_event_description["#text"] ? element.out_event_description["#text"] : ''  : '';
				var speed = element.out_speed ? element.out_speed["#text"] ? element.out_speed["#text"] : ''  : '';
				
				var result = ['<center><strong>' + registration + '</strong> <br> ' + description + '</center>', latitude, longitude, speed];
				locations.push(result);
			}, this);

			// console.log(JSON.stringify(item));
			result(locations);
		});
		/* End : Tracking Bus */

	} // End Load Map Function  

	function loadLocation() {
		try {
			if ($localStorage.permission_transportation.transportationMap == 1) {
				var id = navigator.geolocation.watchPosition(function onSucces(position) {
					lat = position.coords.latitude;
					long = position.coords.longitude;
					$scope.location = new google.maps.LatLng(lat, long);
					if ($scope.location != null || $scope.location != undefined) {
						navigator.geolocation.clearWatch(id);
						if ($scope.myLatlng != undefined) {
							$scope.myLatlng.setMap(null);
						}
						myLocation = new google.maps.Marker({
							position: $scope.location,
							map: $scope.map,
							title: "background"
						})
						loadAll();
					}

				}, function onMapError(error) {

					$scope.location = undefined;

				},
					{ enableHighAccuracy: false });

			} else {
				popupconfirm();
			}
		} catch (e) {
			popupconfirm();
		}
	}

	function loadAll() {
		var currentLoc = $scope.location;
		var map = new google.maps.Map(document.getElementById("map"), {
			center: currentLoc,
			zoom: 13,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			// mapTypeControl : false,
			// navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
		});
		// var markers = new Array(locations.length);

		var markers = [];
		var infowindow = new google.maps.InfoWindow();
		var icon = {
			url: "img/ic_destination.png", // url
			scaledSize: new google.maps.Size(40, 40), // scaled size
			origin: new google.maps.Point(0, 0), // origin
			anchor: new google.maps.Point(0, 0) // anchor
		};

		var loc = JSON.parse(JSON.stringify(currentLoc));
		var markerCurrentLocation = new google.maps.Marker({
			position: new google.maps.LatLng(loc.lat, loc.lng),
			animation: google.maps.Animation.DROP,
			align: 'center',
			map: map
		});
		google.maps.event.addListener(markerCurrentLocation, 'click', (function (marker) {
			return function () {
				infowindow.setContent('You are Here');
				infowindow.open(map, marker);
			}
		})(markerCurrentLocation, -1));

		setInterval(function () {
			loadMap(map, function (locations) {
				if (markers.length > 0) {
					for (var i = 0; i < markers.length; i++) {
						markers[i].setMap(null);
					}
					markers = [];
				}

				for (var i = 0; i < locations.length; i++) {
					markerData = new google.maps.Marker({
						position: new google.maps.LatLng(locations[i][1], locations[i][2]),
						animation: google.maps.Animation.DROP,
						align: 'center',
						icon: icon,
						map: map
					});
					markers.push(markerData);

					google.maps.event.addListener(markers[i], 'click', (function (marker, i) {
						return function () {
							infowindow.setContent(locations[i][0]);
							infowindow.open(map, marker);
						}
					})(markers[i], i));
				}
			});
		}, 10000);
		// $ionicLoading.hide();
	}

	$scope.$on('$ionicView.enter', function () {
		// $ionicLoading.show({ template: $filter('translate')('loading') + "..." });
		if (window.google) {
			if (window.google.maps) {
				if ($scope.map === undefined) {
					loadLocation();
				}
			} else {
				$scope.loadGMapsbus(); //then load the map
			}
		} else {
			console.log("google isn't...");
			$scope.loadGLoaderbus(); //then load maps, then load the map
		}
	});

	$scope.loadGLoaderbus = function () {
		if (!window.google || !window.google.loader) {
			console.log("loading gloader");
			$http.get("http://maps.googleapis.com/maps/api/js?key=AIzaSyAZ4939bfDLme2qmuIsfwg-ilYmsG3CeBw&libraries=places")
				.success(function (json) {
					var scriptElem = document.createElement('script');
					document.getElementsByTagName('head')[0].appendChild(scriptElem);
					scriptElem.text = json;
					locations.loadGMaps();
				});
		} else {
			if (!window.google.maps || !window.google.maps) {
				console.log("no gmaps");
				$rootScope.loadGMapsbus();
			}
		}
	};
	$scope.loadGMapsbus = function () {
		if (window.google && window.google.loader && window.google.maps === undefined) {
			console.log("loading gmaps");
			try {
				google.load("maps", "3.21", {
					callback: mappingCallback,
					other_params: "libraries=geometry&sensor=true&language=en"
				});
			} catch (e) { }
		}
	};

}