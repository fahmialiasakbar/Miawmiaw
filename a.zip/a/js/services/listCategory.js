angular
    .module('livein')
    .service('TenantService', TenantService);

function TenantService($http, $localStorage, $filter) {
    var service = {};

    service.listAllChild = listAllChild;
    service.listChild = listChild;
    service.listTenant = listTenant;
    service.retriveGetTenant = retriveGetTenant;
    service.retriveGetTenantImage = retriveGetTenantImage;
    service.listRecomendedTenant = listRecomendedTenant;
    service.filterByCategory = filterByCategory;
    service.listBookmarkedTenant = listBookmarkedTenant;
    service.categoryTenant = categoryTenant;
    service.listTenantHome = listTenantHome;
    service.listTenantSearch = listTenantSearch;
    
    return service;

    function listAllChild(idcategory, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Category?action=listallchild&idcategory=' + idcategory
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }
    
    function listChild(idcategory, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Category?action=listchild&idcategory=' + idcategory
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function listTenant(idcategory,pagenumber, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Tenant/?action=listbycategory&idcategory=' + idcategory + '&pagenumber='+pagenumber+'&pagesize=8'
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function listRecomendedTenant(idcategory, pagenumber, pagesize, callback) {
        if ($localStorage.currentUser != null) {
            var accountid = $localStorage.currentUser.data[0].idaccount;;
        } else {
            var accountid = "";
        }
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Tenant/?action=listcategoryfilterbyrecommended&idcategory=' + idcategory + '&idaccount=' + accountid + '&pagenumber='+pagenumber+'&pagesize='+pagesize+'&keyword=%%'
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function listBookmarkedTenant(idcategory,pagenumber, callback) {
        if ($localStorage.currentUser != null) {
            var accountid = $localStorage.currentUser.data[0].idaccount;
        } else {
            var accountid = "";
        }

        var req = {
            method: 'GET',        
            url: $filter('translate')('apilink') + 'api/Tenant/?action=listTenantByBookmark&idcategory=' + idcategory + '&idaccount=' + accountid + '&pagenumber='+pagenumber+'&pagesize=8'
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function retriveGetTenant(idtenant, callback) {

        if ($localStorage.currentUser != null) {
            var accountid = $localStorage.currentUser.data[0].idaccount;;
        } else {
            var accountid = "";
        }

        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Tenant/?action=retrieve_get&idtenant=' + idtenant + '&idaccount=' + accountid
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function retriveGetTenantImage(idtenant, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Gallerytenant/?action=listgallery&pagenumber=1&pagesize=1000' + idtenant
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function filterByCategory(idcategory, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Category?action=listallchild&idcategory=' + idcategory
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function categoryTenant(idcategory, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Category?action=categorytenant&idcategory=' + idcategory
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function listTenantHome(idcategory, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Tenant/?action=listtenanthome&idcategory='+ idcategory +'&pagenumber=1&pagesize=10'
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }

    function listTenantSearch(idcategory, pagenumber, keyword, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Tenant/?action=listcategoryfilterbyname&idcategory='+ idcategory +'&pagenumber='+pagenumber+'&pagesize=8&keyword=%25'+keyword+'%25'
        }

        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function() {
                callback(false);
            });
    }
}