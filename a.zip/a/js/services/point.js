angular
  .module('livein')
  .service('PointService', PointService);

  function PointService($http, $filter, $localStorage) {
    var service = {};
    service.listHomeVoucher = listHomeVoucher;
    service.listVoucher = listVoucher;
    service.detailVoucher = detailVoucher; 
    service.searchVoucher = searchVoucher;
    service.sortlistVoucher = sortlistVoucher; 
    service.getVoucher = getVoucher;
    service.earnPoints = earnPoints;
    service.getActiveRules = getActiveRules;
    service.getRulesDetail = getRulesDetail; 
    service.getMyPoint = getMyPoint;
    service.getHistoryPoint = getHistoryPoint;
    service.getHistoryVoucher = getHistoryVoucher;
    service.getMyVoucher = getMyVoucher;
    service.redeemVoucher = redeemVoucher;
    service.redeemVoucherOvo = redeemVoucherOvo;
    service.useVoucher = useVoucher;
    service.getVoucherExpired = getVoucherExpired;
    service.deleteVoucher = deleteVoucher;

    return service;

    function listHomeVoucher(pagenumber, callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher?id_account='+$localStorage.currentUser.data[0].idaccount+'&pagenumber='+pagenumber+'&pagesize=10'
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }

    function listVoucher(id_category,pagenumber,callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher/List?id_account='+$localStorage.currentUser.data[0].idaccount+'&id_category='+id_category+'&mypoint&distance&currentlat&currentlong&keyword&sort&pagenumber='+pagenumber+'&pagesize=10&startpoint&endpoint&from&to'
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }


    function detailVoucher(id, callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher/detail?id_account='+$localStorage.currentUser.data[0].idaccount+'&id='+id
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }

    function searchVoucher(id_category, pagenumber, keyword, callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher/List?id_account='+$localStorage.currentUser.data[0].idaccount+'&id_category='+id_category+'&mypoint&distance&currentlat&currentlong&keyword='+keyword+'&sort&pagenumber='+pagenumber+'&pagesize=10&startpoint&endpoint&from&to'
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }

    function sortlistVoucher(id_category,pagenumber,sort,callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher/List?id_account='+$localStorage.currentUser.data[0].idaccount+'&id_category='+id_category+'&mypoint&distance&currentlat&currentlong&keyword&sort='+sort+'&pagenumber='+pagenumber+'&pagesize=10&startpoint&endpoint&from&to'
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }

    function getVoucher(id_category,mypoint,distance,currentlat,currentlong,keyword,sort,pagenumber,point,from,to,status,callback) {
      var req = {
        method: 'GET',
        url: $filter('translate')('apilink') + 'api/Voucher/List?id_account='+$localStorage.currentUser.data[0].idaccount+
        '&id_category='+id_category+'&mypoint='+mypoint+'&distance='+distance+
        '&currentlat='+currentlat+'&currentlong='+currentlong+
        '&keyword='+keyword+'&sort='+sort+'&pagenumber='+pagenumber+
        '&pagesize=10&point='+point+
        '&from='+from+'&to='+to+'&status='+status
      }

      $http(req)
        .success(function(response) {
          callback(response);
        })
        .error(function(error) {
          callback(error);
        });
    }

    
    function earnPoints(trxCode, id_tenant, title, title_id, callback) {
      var data = 'trxCode=' + trxCode +
                '&idaccount=' + $localStorage.currentUser.data[0].idaccount+
                '&idtenant=' + id_tenant;

      if(title || title_id){
        data = 'trxCode=' + trxCode +
                '&idaccount=' + $localStorage.currentUser.data[0].idaccount+
                '&idtenant=' + id_tenant+
                '&title=' + title +
                '&title_id=' + title_id;
      }
      var req = {
          method: 'POST', 
          url: $filter('translate')('apilink') + 'api/Point/charge',
          headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
          },
          data: data,
      }
      
      console.log("====== earnPoints params =====");
      console.log(req.data);
      console.log("===========");

      $http(req)
          .success(function (response) {
              callback(response);
          })
          .error(function (response) {
              callback(response);
          });
  }
  
  function getActiveRules(callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Rules/listactive'
    }

    $http(req)
      .success(function(response) { 
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }

  function getRulesDetail(idRules, callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Rules/detail/'+ idRules
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }

  function getMyPoint(callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Point/mypoint/' + $localStorage.currentUser.data[0].idaccount
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }

  
  function getHistoryPoint(pagenumber, callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Point/history/' + $localStorage.currentUser.data[0].idaccount +'?pagenumber='+pagenumber+'&pagesize=10' 
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }

  function getHistoryVoucher(pagenumber, keyword, callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Voucher/history?idaccount=' + $localStorage.currentUser.data[0].idaccount + '&keyword='+ keyword + '&pagenumber=' + pagenumber +'&pagesize=10'
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }
  
  function getMyVoucher(distance, currentlat, currentlong,
    keyword, sort, pagenumber, point, from, to, status, callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Voucher/myvoucher?idaccount='+$localStorage.currentUser.data[0].idaccount+
        '&distance='+distance+
        '&currentlat='+currentlat+
        '&currentlong='+currentlong+
        '&keyword='+keyword+'&sort='+sort+'&pagenumber='+pagenumber+
        '&pagesize=10&point='+point+
        '&from='+from+'&to='+to+'&status='+status
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) {
        callback(error);
      });
  }

  function redeemVoucher(idvoucher, callback) {
    var req = {
        method: 'POST', 
        url: $filter('translate')('apilink') + 'api/Voucher/redeem',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: 'idaccount=' + $localStorage.currentUser.data[0].idaccount+
        '&idvoucher=' + idvoucher
    }

    $http(req)
        .success(function (response) {
            callback(response);
        })
        .error(function (response) {
            callback(response);
        });
  }

  function redeemVoucherOvo(idvoucher, ovoid, callback) {
    var req = {
        method: 'POST', 
        url: $filter('translate')('apilink') + 'api/Voucher/redeem',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: 'idaccount=' + $localStorage.currentUser.data[0].idaccount+
        '&idvoucher=' + idvoucher +
        '&ovoid=' + ovoid
    }

    $http(req)
        .success(function (response) {
            callback(response);
        })
        .error(function (response) {
            callback(response);
        });
  }

  function useVoucher(idvoucher, activationcode, callback) {
    var req = {
        method: 'POST', 
        url: $filter('translate')('apilink') + 'api/Voucher/use',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: 'idaccount=' + $localStorage.currentUser.data[0].idaccount+
              '&idvoucher=' + idvoucher+
              '&activationcode=' + activationcode
    }

    $http(req)
        .success(function (response) {
            callback(response);
        })
        .error(function (response) {
            callback(response);
        });
  }

  function getVoucherExpired(callback){
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Voucher/expirednotif?idaccount='+$localStorage.currentUser.data[0].idaccount
    }

    $http(req)
      .success(function(response) {
        callback(response);
      })
      .error(function(error) { 
        callback(error);
      });
  }

  function deleteVoucher(callback) {
   
    var req = {
        method: 'POST', 
        url: $filter('translate')('apilink') + 'api/Voucher/autodelete',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: 'idaccount=' + $localStorage.currentUser.data[0].idaccount
    }

    $http(req)
        .success(function (response) {
            callback(response);
        })
        .error(function (response) {
            callback(response);
        });
  }
}
