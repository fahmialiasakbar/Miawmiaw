angular
    .module('livein')
    .service('LoginService', LoginService);

function LoginService($http, $localStorage, $filter, Notification) {
    var service = {};

    service.loginUser = loginUser;
    service.logoutUser = logoutUser;
    service.getEmailTwitter = getEmailTwitter;

    return service;

    function loginUser(email, password, callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilink') + 'api/Account/',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: 'action=login' + '&email=' + email + '&password=' + password
        }

        $http(req)
            .success(function(response) {
                if (response[0].status != false && response[0].status != "inactive") {
                    $localStorage.currentUser = { data: response };
                    
                    Notification.countUnreadNotif(function (response) {
                        if(window.hasOwnProperty('cordova')){
                            cordova.plugins.notification.badge.set(response);
                        }
                    });
                }
                callback(response);
            })
            .error(function(response) {
                callback(response);
            });
    }

    function logoutUser() {
        // remove user from local storage and clear http auth header
        delete $localStorage.currentUser;
        delete $localStorage.notifBefore;
        delete $localStorage.settingMyVoucher;
        delete $localStorage.idNotificationVoucher;
        delete $localStorage.currentPoint;
        
        $localStorage.idNotification = 0;
        // if(window.hasOwnProperty('cordova')){
        //     cordova.plugins.notification.badge.clear();
        // } 
        // firebase.auth().signOut().then(function() {
        //     console.log("suksescuyy");
        //   }).catch(function(error) {
        //     console.log("gagalahh");
        //     // An error happened.
        //   });

        // var auth2 = gapi.auth2.getAuthInstance();
        // auth2.signOut().then(function () {
        // //   console.log('suksesouttt');
        // });
    }

    function getEmailTwitter(token, callback) {
            url = "https://api.twitter.com/1.1/account/verify_credentials.json?include_email=true";
            var req = {
                method : 'GET',
                url : url,
                headers : {
                    'Authorization' : 'oauth_token=""'
                }
            }

            $http(req)
            .success(function(response) {                
                callback(response);
            })
            .error(function(error) {
                callback(error);
            });
    }

}