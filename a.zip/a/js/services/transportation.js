angular
  .module('livein')
  .service('BusScheduleService', BusScheduleService);

function BusScheduleService($http, $filter) {
  var service = {};
  service.getRoute = getRoute;
  service.getBus = getBus;

  return service;

  function getRoute(callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Transport/?action=listroute'
    }

    $http(req)
      .success(function (response) {
        callback(response);
      })
      .error(function () {
        callback(false);
      });
  }

  function getBus(iddays, idroute, pagenumber, pagesize, callback) {
    var req = {
      method: 'GET',
      url: $filter('translate')('apilink') + 'api/Transport/?action=listbus&iddayschedule=' + iddays + '&idroute=' + idroute + '&pagenumber=' + pagenumber + '&pagesize='+pagesize
    }

    $http(req)
      .success(function (response) {
        callback(response);
      })
      .error(function () {
        callback(false);
      });
  }
}