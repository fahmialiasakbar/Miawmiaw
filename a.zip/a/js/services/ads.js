angular
    .module('livein')
    .service('AdvertisementService', AdvertisementService);

function AdvertisementService($http, $filter, $localStorage) {
    var service = {};

    service.getAdsbyFilter = getAdsbyFilter;
    service.getAdsDetail = getAdsDetail;
    
    return service;

    function getAdsbyFilter(idtype, pagenumber, pagesize, keyword, idcategory, callback) {
        var idAccount = "";
        if($localStorage.currentUser){
            if($localStorage.currentUser.data){
                if($localStorage.currentUser.data[0]){
                    if($localStorage.currentUser.data[0].idaccount){
                        idAccount = $localStorage.currentUser.data[0].idaccount;
                    }
                }
            }
        }
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Ads/list/'+idtype+'?pagenumber='+pagenumber+'&pagesize='+pagesize+'&keyword='+keyword+'&idcategory='+idcategory+'&idaccount='+idAccount
        }
        
        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function(err) {
                callback(err);
            });
    }

    function getAdsDetail(idads, callback) {
        var idAccount = "";
        if($localStorage.currentUser){
            if($localStorage.currentUser.data){
                if($localStorage.currentUser.data[0]){
                    if($localStorage.currentUser.data[0].idaccount){
                        idAccount = $localStorage.currentUser.data[0].idaccount;
                    }
                }
            }
        }
        var req = {
            method: 'GET',
            url: $filter('translate')('apilink') + 'api/Ads/detail/'+idads+'?idaccount='+idAccount
        }
        
        $http(req)
            .success(function(response) {
                callback(response);
            })
            .error(function(err) {
                callback(err);
            });
    }
}