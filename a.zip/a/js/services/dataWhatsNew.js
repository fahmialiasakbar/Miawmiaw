angular
    .module('livein')
    .service('dataWhatsNew', dataWhatsNew);

    function dataWhatsNew($http, $filter, $localStorage) {
        var service = {};

        service.getDataWhatsNew = getDataWhatsNew;
        service.getDataWhatsNewSide = getDataWhatsNewSide;
        service.retriveGetNews = retriveGetNews;
        service.searchingNews = searchingNews;
        return service; 

        function getDataWhatsNew(lang,pagesize,callback) {
            var req = {
                    method: 'GET',
                    cache: true,
                    url: $filter('translate')('apilink') + 'api/News/?action=listnews&pagenumber=1&pagesize='+pagesize+'&lang='+lang
                }

            $http(req)
                .success(function(response) {
                    callback(response);
                })
                .error(function() {
                    callback(false);
                });
        }

        function getDataWhatsNewSide(pagenumber,lang,callback) {
            var req = {
                    method: 'GET',
                    cache: true,
                    url: $filter('translate')('apilink') + 'api/News/?action=listnews&pagenumber='+pagenumber+'&pagesize=8&lang='+lang
                }
            $http(req)
                .success(function(response) {
                    callback(response);
                })
                .error(function() {
                    callback(false);
                });
        }

        function retriveGetNews(lang, idnews, callback) {
            
            
            var req = {
                method: 'GET',
                url: $filter('translate')('apilink') + 'api/News/?action=retrieve_get&idnews=' + idnews
            }
            $http(req)
                .success(function (response) {
                    callback(response);                    
                })
                .error(function () {
                    callback(false);
                });
        }

        function searchingNews(pagenumber, pagesize, name, lang, callback) {
            var req = {
                method: 'GET',
                url: $filter('translate')('apilink') + 'api/News/?action=listnewsfilterbyname&pagenumber=' + pagenumber + '&pagesize=' + pagesize + '&keyword=' + name + '&lang=' + lang,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            };
            $http(req)
                .success(function (response) {
                    callback(response);
                })
                .error(function () {
                    callback(false);
                });
        }    

    }