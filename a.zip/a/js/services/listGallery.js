angular
    .module('livein')
    .service('listGallery', listGallery);

    function listGallery($http, $filter) {
        var service = {};

        service.getlistGallery = getlistGallery;
        service.getlistGallery2 = getlistGallery2;        
        service.getSearchGallery = getSearchGallery;
        service.saveGallery = saveGallery;        
        // service.gethastag = gethastag;
        service.getListInstagram = getListInstagram;

        return service;

        function getlistGallery(callback) {
            var req = {
                method: 'GET',
                url: $filter('translate')('apilink') + 'api/City/?action=listgallery&pagesize=30&pagenumber=1&idcity=1'
            }

            $http(req)
                .success(function(response) {
                    callback(response);
                })
                .error(function() {
                    callback(false);
                });
        }

        function getlistGallery2(pagenumber, callback) {
            var req = {
                method: 'GET',
                url: $filter('translate')('apilink') + 'api/City/?action=listgallery&pagesize=20&pagenumber='+pagenumber+'&idcity=1'
            }

            $http(req)
                .success(function(response) {
                    callback(response);                                        
                })
                .error(function() {
                    callback(false);
                });
        }


        // function gethastag (pagenumber,size,callback){
        //     url = $filter('translate')('apilink') +"api/Gallery/?action=" + "listhashtag" +"&pagenumber=" + pagenumber+"&pagesize=" + size ;
        //     var req = {
        //         method : 'GET',
        //         url:  "http://innodev.vnetcloud.com/LiveIn/index.php/api/Gallery/?action=listhashtag&pagenumber="+pagenumber+"&pagesize=" +size         
        //     }

        //     $http(req)
        //     .success(function(response) {
                
        //         callback(response);
        //     })
        //     .error(function(error) {
        //         callback(false);
        //     });
        // }

        function getListInstagram (callback){
            // hastag = hastag.substring(1);
            ACCESS_TOKEN = "4869748408.5fb6f49.35f59ad9547d4e6a99a90491e11395a9"; //officiallc
            // ACCESS_TOKEN = "6237503080.ad08c85.7d31016d3d3840659d2b649bce792843"; //devlc
            url = "https://api.instagram.com/v1/users/self/media/recent/?access_token="
            + ACCESS_TOKEN;

            var req = {
                method : 'GET',
                url :url
            }

            $http(req)
            .success(function(response) {                
                callback(response);
            })
            .error(function(error) {
                callback(error);
            });
            
        }

        function saveGallery(avatar, title, callback) {
            var req = {
                method: 'POST',
                url: $filter('translate')('apilink') + 'api/City/',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                data: 'action=' + 'insert_gallery' +
                    '&idcity=1' +
                    '&title=' + title +
                    '&avatar=' + avatar
            }

            $http(req)
                .success(function(response) {
                    callback(response);
                })
                .error(function() {
                    callback(false);
                });
        }

        function getSearchGallery(name,callback) {
            var req = {
                method: 'GET',
                url: $filter('translate')('apilink') + 'api/City/?action=listgalleryfilterbyname&pagesize=30&pagenumber=1&idcity=1&keyword=%25' + name + '%25'
            }
            console.log(req);
            $http(req)
                .success(function(response) {
                    callback(response);
                })
                .error(function() {
                    callback(false);
                });
        }
    }