angular
    .module('livein')
    .service('Version', Version)

    function Version($http, $localStorage, $filter, $ionicLoading) {
        var service = {};
        service.GetVersion = GetVersion;
        return service; 

        function GetVersion(callback){
             var req = {
                    method: 'GET',
                    url: $filter('translate')('apilink') + 'api/Application/?action=retrieve_get&idapplication=1'
                }

            $http(req)
                .success(function(response) {
                    if($localStorage.Version == null){
                        $localStorage.Version = response[0].iosversion;    
                    }
                    else{
                        console.log('iki version: '+$localStorage.Version);
                        if($localStorage.Version != response[0].iosversion){
                            $localStorage.Version = response[0].iosversion;
                            $ionicLoading.show({ 
                                template: $filter('translate')('version_uptodate'), 
                                duration: 2000 
                            });
                        }
                    }
                    //console.log(response[0].iosversion);
                    callback(response[0].iosversion);
                })
                .error(function() {
                    callback(false);
                });
        }

        function countNotif(callback) {
            var req = {
                    method: 'GET',
                    url: $filter('translate')('apilink') + 'api/Notif/?action=count_notif&idaccount='+$localStorage.currentUser.data[0].idaccount
                }
     
            $http(req)
                .success(function(response) {
                    if ($localStorage.notifBefore != null) {
                        // console.log('Ntf response : ' + response[0].total);
                        // console.log('Ntf localstr : ' + $localStorage.notifBefore.sum);
                        var count = response[0].total - $localStorage.notifBefore.sum;
                        // console.log('Ntf count : ' + count);

                        $localStorage.notifBefore = { sum : response[0].total };
                        callback(count);
                    }
                    else {
                        $localStorage.notifBefore = { sum : response[0].total };
                        $localStorage.notifPush = { 'status' : true, 'sound' : true };
                    }
                })
                .error(function() {
                    callback(false);
                });
        }     
         

    }       
