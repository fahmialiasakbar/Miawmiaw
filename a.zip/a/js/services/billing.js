angular
    .module('livein')
    .service('billingServices', billingServices);

function billingServices($http, $filter, $localStorage) {
    var service = {};

    service.loginBillingServices = loginBillingServices;
    service.getbilling = getbilling;
    service.getbillingmultiside = getbillingmultiside;
    service.ovopaymet_service = ovopayment;
    service.getPaymentType = getPaymentType;
    service.midtransPayment = midtransPayment;
    service.midtransPaymentCreditCard = midtransPaymentCreditCard;
    service.getTokenMidtransPaymentCreditCard = getTokenMidtransPaymentCreditCard;
    service.detailhistory = detailhistory;
    service.paymentHistory = paymentHistory;
    service.detailPaymentHistory = detailPaymentHistory;
    service.downloadDetail = downloadDetail;
    service.downloadList = downloadList;
    return service;

    function loginBillingServices(email, callback) {
        console.log(email);
        var lang = localStorage.getItem('NG_TRANSLATE_LANG_KEY');
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'validatelogin',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "orgID": "1",
                "Email": email,
                "lang": lang
            }
        }
        $http(req)
            .success(function (response) {
                callback(response);
                console.log('sukses');
                // alert(JSON.stringify(response));
            })
            .error(function (response) {
                callback(response);
                // alert('gagal: '+response)
            });
    }


    function getbilling(email, siteId, callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'getbilling',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "orgID": "1",
                "siteID": siteId,
                "Email": email
            }
        }

        $http(req)
            .success(function (response) {
                console.log(response)
                console.log(response.status)
                callback(response);

            })
            .error(function (response) {
                console.log('false')
                callback(false);
            });

    }

    function getbillingmultiside(email, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'getbillingmultisite?Email='+email+'&orgID=1'
        }

        $http(req)
            .success(function (response) {
                callback(response);

            })
            .error(function (response) {
                callback(false);
            });

    }

    function ovopayment(name, email, siteId, amount, ovoid, callback) {

        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'payment',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "name": name,
                "email": email,
                "siteid": siteId,
                "orgid": 1,
                "paymenttype": 3,
                "amount": amount,
                "ovoid": ovoid,
            }
        }


        console.log(JSON.stringify(req));
        $http(req)
            .success(function (response) {
                console.log(response)
                console.log(response.status)
                callback(response);

            })
            .error(function (response) {

                console.log('false')
                callback(false);
            });
    }

    function midtransPayment(name, email, siteId, amount, charge_payment_type, callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'payment',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "name": name,
                "email": email,
                "siteid": siteId,
                "orgid": 1,
                "paymenttype": 4,
                "amount": amount,
                "charge": charge_payment_type,
            }
        }

        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(response);
            });
    }


    function detailhistory(order_id, callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'detailhistory',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "merchanttransactionid": order_id,
            }
        }

        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(response);
            });
    }

    function midtransPaymentCreditCard(card_token, name, phone, email, siteId, amount, payment_type, charge_payment_type, callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'payment',
            headers: {
                'Content-Type': 'application/json'
            },
            data: {
                "card_token": card_token,
                "name": name,
                "phone": phone,
                "email": email,
                "siteid": siteId,
                "orgid": 1,
                "paymenttype": payment_type,
                "amount": amount,
                "charge": charge_payment_type,
                "3ds": true,
            }
        }

        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(false);
            });
    }

    function getTokenMidtransPaymentCreditCard(amount, card_number, card_exp_month, card_exp_year, card_cvv, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'creditcardtoken?' +
                'amount=' + amount +
                '&card_number=' + card_number +
                '&card_exp_month=' + card_exp_month +
                '&card_exp_year=' + card_exp_year +
                '&card_cvv=' + card_cvv
        }

        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(response);
            });
    }


    function getPaymentType(callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'paymenttype?action=get_payment_type'
        }
        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(false);
            });
    }

    function paymentHistory(email, payment_method = '', start_number_of_unit = '', end_number_of_unit = '', start_date = '', end_date = '', pagenumber = 1,  callback) {
        var req = {
            method: 'POST',
            url: $filter('translate')('apilinkpayment') + 'paymenthistory',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: "orgid=1" +
                "&email=" + email +
                "&payment_method=" + payment_method +
                "&start_number_of_unit=" + start_number_of_unit +
                "&end_number_of_unit=" + end_number_of_unit +
                "&start_date=" + start_date +
                "&end_date=" + end_date+
                "&pagesize=10&pagenumber=" + pagenumber
        }
        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(response);
            });
    }

    function detailPaymentHistory(merchanttransactionid, callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'detailhistory?merchanttransactionid='+merchanttransactionid
        }
        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(response);
            });
    }

    function downloadDetail(merchanttransactionid,callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'download?merchanttransactionid='+merchanttransactionid
        }
        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(false);
            });
    }

    
    function downloadList(payment = "", start_date = "", end_date = "", callback) {
        var req = {
            method: 'GET',
            url: $filter('translate')('apilinkpayment') + 'downloadList?orgid=1&payment_method='+payment+'&start_date='+start_date+'&end_date='+end_date+'&email='+$localStorage.currentUser.data[0].email
        }
        $http(req)
            .success(function (response) {
                callback(response);
            })
            .error(function (response) {
                callback(false);
            });
    }
}